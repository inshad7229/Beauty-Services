webpackJsonp(["faq.module"],{

/***/ "../../../../../src/app/header-two-layout/faq/faq-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FaqRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__faq_component__ = __webpack_require__("../../../../../src/app/header-two-layout/faq/faq.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__faq_component__["a" /* FaqComponent */]
    }
];
var FaqRoutingModule = (function () {
    function FaqRoutingModule() {
    }
    FaqRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], FaqRoutingModule);
    return FaqRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/faq/faq.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"loader-box\" *ngIf=\"waitLoader==true\">\n    <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\n</div>\n<section class=\"faq-main\">\n    <div class=\"about-top-head\">\n        <div class=\"about-heading\">\n            <h2> FAQ </h2>\n        </div>\n    </div>\n    <div class=\"faq-content\">\n        <mat-accordion *ngFor=\"let faq of faqList;let i=index\">\n\t\t\t<mat-expansion-panel>\n\t\t\t    <mat-expansion-panel-header>\n\t\t\t     \t<span >{{i+1}}. {{faq.questions}} </span>\n\t\t\t    </mat-expansion-panel-header>\n\t\t\t\t\t<span>\n                        {{faq.answers}}\n                    </span>\n\t\t\t</mat-expansion-panel>\n\t\t</mat-accordion>\n    </div>\n</section>\n"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/faq/faq.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/faq/faq.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FaqComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var FaqComponent = (function () {
    function FaqComponent(commonService) {
        this.commonService = commonService;
        this.waitLoader = false;
    }
    FaqComponent.prototype.ngOnInit = function () {
        this.getFaqList();
    };
    FaqComponent.prototype.getFaqList = function () {
        var _this = this;
        this.waitLoader = true;
        this.commonService.faqList().subscribe(function (data) {
            _this.waitLoader = false;
            if (data.success = true) {
                _this.faqList = data.faqData;
            }
        }, function (err) {
        });
    };
    FaqComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-faq',
            template: __webpack_require__("../../../../../src/app/header-two-layout/faq/faq.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/faq/faq.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__providers_common_service__["a" /* CommonService */]])
    ], FaqComponent);
    return FaqComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/faq/faq.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FaqModule", function() { return FaqModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__faq_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/faq/faq-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__faq_component__ = __webpack_require__("../../../../../src/app/header-two-layout/faq/faq.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_material_expansion__ = __webpack_require__("../../../material/esm5/expansion.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var FaqModule = (function () {
    function FaqModule() {
    }
    FaqModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2__faq_routing_module__["a" /* FaqRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_4__angular_material_expansion__["a" /* MatExpansionModule */]
            ],
            providers: [__WEBPACK_IMPORTED_MODULE_5__providers_common_service__["a" /* CommonService */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__faq_component__["a" /* FaqComponent */]]
        })
    ], FaqModule);
    return FaqModule;
}());



/***/ })

});
//# sourceMappingURL=faq.module.chunk.js.map