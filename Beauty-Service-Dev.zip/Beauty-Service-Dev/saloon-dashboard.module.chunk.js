webpackJsonp(["saloon-dashboard.module"],{

/***/ "../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaloonDashboardRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__saloon_dashboard_component__ = __webpack_require__("../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__saloon_dashboard_component__["a" /* SaloonDashboardComponent */]
    }
];
var SaloonDashboardRoutingModule = (function () {
    function SaloonDashboardRoutingModule() {
    }
    SaloonDashboardRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], SaloonDashboardRoutingModule);
    return SaloonDashboardRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n    <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n</div>\r\n              <!-- \r\n                 <?php\r\n                    require('include/dashboard-sidebar.php');\r\n                ?> -->\r\n            <!-- END SIDEBAR -->\r\n            <!-- BEGIN CONTENT -->\r\n            <div class=\"page-content-wrapper\">\r\n                <div class=\"page-content\">\r\n                    <ul class=\"page-breadcrumb breadcrumb hide\">\r\n                        <li>\r\n                            <a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n                        </li>\r\n                        <li class=\"active\">\r\n                             Dashboard\r\n                        </li>\r\n                    </ul>\r\n                    <!-- BEGIN PAGE CONTENT INNER -->\r\n                    <div class=\"page-wrap margin-top-10\">\r\n                        <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12 p-0\">\r\n                            <div class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n                                <div class=\"dashboard-stat2 bordered\">\r\n                                    <div class=\"display\">\r\n                                        <div class=\"number\">\r\n                                            <h3 class=\"font-green-sharp\">{{countDown | async  }}\r\n                                                <!-- <small class=\"font-green-sharp\">$</small> -->\r\n                                            </h3>\r\n                                            <small>TOTAL BOOKING</small>\r\n                                        </div>\r\n                                        <div class=\"icon\">\r\n                                            <i class=\"icon-calendar\"></i>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"progress-info\">\r\n                                            <!-- <span style=\"width: 76%;\" class=\"progress-bar progress-bar-success green-sharp\">\r\n                                                <span class=\"sr-only\">76% progress</span>\r\n                                            </span> -->\r\n                                          <!-- <section class=\"example-section\"> -->\r\n                                              <mat-progress-bar\r\n                                                  [color]=\"color\"\r\n                                                  [mode]=\"mode\"\r\n                                                  [value]=\"value\"\r\n                                                  [bufferValue]=\"bufferValue\">\r\n                                              </mat-progress-bar>\r\n                                           <!--  </section> -->\r\n\r\n                                        <div class=\"status\">\r\n                                            <div class=\"status-title\"> progress </div>\r\n                                            <div class=\"status-number\"> 100% </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n                                <div class=\"dashboard-stat2\">\r\n                                    <div class=\"display\" >\r\n                                        <div class=\"number\">\r\n                                            <h3 class=\"font-red-haze\"> {{countDownCurrent | async }}\r\n                                            </h3>\r\n                                            <small class=\"\">TODAY'S BOOKING</small>\r\n                                        </div>\r\n                                        <div class=\"icon\">\r\n                                            <i class=\"icon-calendar\"></i>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"progress-info\">\r\n                                        <div class=\"progress\">\r\n                                            <mat-progress-bar\r\n                                                  [color]=\"color\"\r\n                                                  [mode]=\"mode\"\r\n                                                  [value]=\"value\"\r\n                                                  [bufferValue]=\"bufferValue\">\r\n                                              </mat-progress-bar>\r\n                                        </div>\r\n                                        <div class=\"status\">\r\n                                            <div class=\"status-title\">\r\n                                                 change\r\n                                            </div>\r\n                                            <div class=\"status-number\">\r\n                                                 85%\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12 cus-p-l\">\r\n                            <div class=\"calender-section\">\r\n                                <div class=\"week-sec\">\r\n                                   \r\n\r\n                                    <ng-template #modalContent let-close=\"close\">\r\n                                      <div class=\"modal-header\">\r\n                                        <h5 class=\"modal-title\">Event action occurred</h5>\r\n                                        <button type=\"button\" class=\"close\" (click)=\"close()\">\r\n                                          <span aria-hidden=\"true\">&times;</span>\r\n                                        </button>\r\n                                      </div>\r\n                                      <div class=\"modal-body\">\r\n                                        <div>\r\n                                          Action:\r\n                                          <pre>{{ modalData?.action }}</pre>\r\n                                        </div>\r\n                                        <div>\r\n                                          Event:\r\n                                          <pre>{{ modalData?.event | json }}</pre>\r\n                                        </div>\r\n                                      </div>\r\n                                      <div class=\"modal-footer\">\r\n                                        <button type=\"button\" class=\"btn btn-outline-secondary\" (click)=\"close()\">OK</button>\r\n                                      </div>\r\n                                    </ng-template>\r\n                                    <div class=\"row text-center\">\r\n                                        <div class=\"col-md-12\">\r\n                                          <div class=\"btn-group\">\r\n                                            <div\r\n                                              class=\"btn cus-btn\"\r\n                                              mwlCalendarPreviousView\r\n                                              [view]=\"view\"\r\n                                              [(viewDate)]=\"viewDate\"\r\n                                              (viewDateChange)=\"activeDayIsOpen = false\">\r\n                                              Previous\r\n                                            </div>\r\n                                            <div\r\n                                              class=\"btn cus-btn\"\r\n                                              mwlCalendarToday\r\n                                              [(viewDate)]=\"viewDate\">\r\n                                              Today\r\n                                            </div>\r\n                                            <div\r\n                                              class=\"btn cus-btn\"\r\n                                              mwlCalendarNextView\r\n                                              [view]=\"view\"\r\n                                              [(viewDate)]=\"viewDate\"\r\n                                              (viewDateChange)=\"activeDayIsOpen = false\">\r\n                                              Next\r\n                                            </div>\r\n                                          </div>\r\n                                        </div>\r\n                                      </div>\r\n                                      <div class=\"row text-center\">\r\n                                        <div class=\"col-md-12 month-name\">\r\n                                          <h3>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h3>\r\n                                        </div>\r\n                                      </div>\r\n                                    <br>\r\n                                    <div [ngSwitch]=\"view\">\r\n                                        <mwl-calendar-month-view\r\n                                        *ngSwitchCase=\"'month'\"\r\n                                        [viewDate]=\"viewDate\"\r\n                                        [events]=\"events\"\r\n                                        [refresh]=\"refresh\"\r\n                                        (dayClicked)=\"dayClicked($event.day)\"\r\n                                        (eventClicked)=\"handleEvent('Clicked', $event.event)\"\r\n                                        (eventTimesChanged)=\"eventTimesChanged($event)\">\r\n                                      </mwl-calendar-month-view>\r\n                                    </div>\r\n\r\n\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"booking-table-sec\">\r\n                        <div class=\"col-md-12 col-sm-12\">\r\n                            <!-- BEGIN PORTLET-->\r\n                            <div class=\"booking-section\">\r\n                                <div class=\"portlet light\">\r\n                                    <div class=\"portlet-title\">\r\n                                        <div class=\"caption caption-md\">\r\n                                            <i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n                                            <span class=\"caption-subject theme-font-color bold uppercase\">Booking Calendar</span>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"portlet-body\">\r\n                                        <div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                            <div class=\"col-md-12 col-sm-12 col-xs-12 \">\r\n                                                <div class=\"booking-calender\">\r\n                                                     <div id=\"organizerContainer\" style=\"margin-left: 8px;\"></div>\r\n                                                    <div class=\"booking-table\">\r\n                                                        <div class=\"table-responsive\">\r\n                                                            <table class=\"table table-bordered\">\r\n                                                                <thead>\r\n                                                                    <tr>\r\n                                                                      <td colspan=\"7\">\r\n                                                                          <div class=\"cutome-th\">\r\n                                                                              <span class=\"pull-left\">\r\n                                                                                  <a (click)=\"onPreviousDate()\"><i class=\"fa fa-angle-left\"></i></a>\r\n                                                                              </span>\r\n                                                                                  {{filterDate}}\r\n                                                                              <span class=\"pull-right\">\r\n                                                                                  <a (click)=\"onForwardDate()\">\r\n                                                                                  <i class=\"fa fa-angle-right\"></i>\r\n                                                                                  </a>\r\n                                                                              </span>\r\n                                                                          </div>\r\n                                                                        </td>\r\n                                                                    </tr>\r\n                                                                    <tr>\r\n                                                                        <th>Time</th>\r\n                                                                        <th>Customer Name</th>\r\n                                                                        <th>Employee Details</th>\r\n                                                                        <th>Service Details</th>\r\n                                                                        <th>Contact Details</th>\r\n                                                                        <th>Status</th>\r\n                                                                    </tr>\r\n                                                                </thead>\r\n                                                                <tbody>\r\n                                                                    <tr *ngFor='let appointment of this.appointMentList| paginate: { itemsPerPage: 3, currentPage: p }'>\r\n                                                                        <td>{{getHours(appointment.start_time)}} : {{getMin(appointment.start_time)}} {{getAmPm(appointment.start_time)}} - {{getHours(appointment.end_time)}} : {{getMin(appointment.end_time)}} {{getAmPm(appointment.end_time)}}</td>\r\n                                                                        <td><img *ngIf=\"appointment.customerRequestForAppointment.image\" class=\"user-view\" [src]=\"imagePath(appointment.customerRequestForAppointment.image)\">\r\n                                                                        <img *ngIf=\"!appointment.customerRequestForAppointment.image\" class=\"user-view\" src=\"assets/img/5.jpg\">\r\n                                                                        {{appointment.customerRequestForAppointment.first_name}}</td>\r\n                                                                        <td>{{appointment.employeeRequestedByCustomer.first_name}}</td>\r\n                                                                        <td>{{appointment.requestedServiceByCustomer.services_eng}}</td>\r\n                                                                        <td>{{appointment.customerRequestForAppointment.contact_number}}</td>\r\n                                                                        <td *ngIf=\"appointment.appointment_status==0\">Pending</td>\r\n                                                                        <td *ngIf=\"appointment.appointment_status==1\">Complete</td>\r\n                                                                        <td *ngIf=\"appointment.appointment_status==2\">Cancelled</td>\r\n                                                                    </tr>\r\n                                                                   <!--  <tr>\r\n                                                                        <td>12:30 PM - 1:00 PM</td>\r\n                                                                        <td><img class=\"user-view\" src=\"img/avatar9.jpg\">Smith</td>\r\n                                                                        <td>Manager</td>\r\n                                                                        <td>Hair Cutting</td>\r\n                                                                        <td>8009890712</td>\r\n                                                                        <td>Pending</td>\r\n                                                                    </tr>\r\n                                                                    <tr>\r\n                                                                        <td>1:00 PM - 1:30 PM</td>\r\n                                                                        <td><img class=\"user-view\" src=\"img/avatar9.jpg\">Smith</td>\r\n                                                                        <td>Manager</td>\r\n                                                                        <td>Hair Cutting</td>\r\n                                                                        <td>8009890712</td>\r\n                                                                        <td>Pending</td>\r\n                                                                    </tr>\r\n                                                                    <tr>\r\n                                                                        <td>1:30 PM - 2:00 PM</td>\r\n                                                                        <td><img class=\"user-view\" src=\"img/avatar9.jpg\">Smith</td>\r\n                                                                        <td>Manager</td>\r\n                                                                        <td>Hair Cutting</td>\r\n                                                                        <td>8009890712</td>\r\n                                                                        <td>Pending</td>\r\n                                                                    </tr> -->\r\n                                                                </tbody>\r\n                                                            </table>\r\n                                                          </div>\r\n                                                          <div class=\"table-pagination\">\r\n                                                              <div class=\"pagination\">\r\n                                                                <!-- <a href=\"#\"><i class=\"fa fa-angle-left\"></i></a>\r\n                                                                <a href=\"#\">1</a>\r\n                                                                <a href=\"#\" class=\"active\">2</a>\r\n                                                                <a href=\"#\">3</a>\r\n                                                                <a href=\"#\"><i class=\"fa fa-angle-right\"></i></a> -->\r\n                                                                <pagination-controls (pageChange)=\"p = $event\"  previousLabel=\"\"  nextLabel=\"\" ></pagination-controls>\r\n                                                              </div>\r\n                                                          </div>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                            <!-- END PORTLET-->\r\n                        </div>\r\n                    </div>\r\n                    <!-- END PAGE CONTENT INNER -->\r\n                </div>\r\n            </div>\r\n            <!-- END CONTENT -->\r\n\r\n"

/***/ }),

/***/ "../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".btn.cus-btn {\n  background-color: #d5275a;\n  border-radius: unset;\n  color: #fff;\n  margin-right: 11px;\n  min-width: 130px; }\n\n.month-name h3 {\n  color: #d5275a; }\n\n.week-sec .cal-month-view .cal-day-cell {\n  min-height: 70px; }\n\n.example-h2 {\n  margin: 10px; }\n\n.example-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-line-pack: center;\n      align-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 60px; }\n\n.example-margin {\n  margin: 0 10px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaloonDashboardComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_date_fns__ = __webpack_require__("../../../../date-fns/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_date_fns___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_date_fns__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_rxjs_Subject__ = __webpack_require__("../../../../rxjs/_esm5/Subject.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_rxjs_Observable__ = __webpack_require__("../../../../rxjs/_esm5/Observable.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_rxjs_add_observable_timer__ = __webpack_require__("../../../../rxjs/_esm5/add/observable/timer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_rxjs_add_operator_map__ = __webpack_require__("../../../../rxjs/_esm5/add/operator/map.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_rxjs_add_operator_take__ = __webpack_require__("../../../../rxjs/_esm5/add/operator/take.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var colors = {
    red: {
        primary: '#ad2121',
        secondary: '#FAE3E3'
    },
    blue: {
        primary: '#1e90ff',
        secondary: '#D1E8FF'
    },
    yellow: {
        primary: '#e3bc08',
        secondary: '#FDF1BA'
    }
};
var SaloonDashboardComponent = (function () {
    function SaloonDashboardComponent(saloonService) {
        this.saloonService = saloonService;
        this.view = 'month';
        this.viewDate = new Date();
        // actions: CalendarEventAction[] = [
        //   {
        //     label: '<i class="fa fa-fw fa-pencil"></i>',
        //     onClick: ({ event }: { event: CalendarEvent }): void => {
        //       this.handleEvent('Edited', event);
        //     }
        //   },
        //   {
        //     label: '<i class="fa fa-fw fa-times"></i>',
        //     onClick: ({ event }: { event: CalendarEvent }): void => {
        //       this.events = this.events.filter(iEvent => iEvent !== event);
        //       this.handleEvent('Deleted', event);
        //     }
        //   }
        // ];
        this.refresh = new __WEBPACK_IMPORTED_MODULE_2_rxjs_Subject__["Subject"]();
        this.events = [];
        this.activeDayIsOpen = true;
        this.userDetail = JSON.parse(localStorage['userdetails']);
        this.p = 1;
        this.currentDate = new Date();
        this.previousDate = new Date();
        this.forwardDate = new Date();
        this.tick = .5;
        this.color = 'primary';
        this.mode = 'determinate';
        this.value = 50;
        this.bufferValue = 75;
        this.waitLoader = false;
        this.saloonId = this.userDetail.id;
        this.totalAppointments = 180;
    }
    SaloonDashboardComponent.prototype.ngOnInit = function () {
        jQuery(document).ready(function ($) {
            $('.count').counterUp({
                delay: 10,
                time: 1000
            });
        });
        this.getAppointMentList();
    };
    // ngAfterViewInit(){
    //   this.getAppointMentList()
    // }
    SaloonDashboardComponent.prototype.dayClicked = function (_a) {
        var date = _a.date, events = _a.events;
        if (Object(__WEBPACK_IMPORTED_MODULE_1_date_fns__["isSameMonth"])(date, this.viewDate)) {
            if ((Object(__WEBPACK_IMPORTED_MODULE_1_date_fns__["isSameDay"])(this.viewDate, date) && this.activeDayIsOpen === true) ||
                events.length === 0) {
                this.activeDayIsOpen = false;
            }
            else {
                this.activeDayIsOpen = true;
                this.viewDate = date;
            }
        }
    };
    // eventTimesChanged({
    //   event,
    //   newStart,
    //   newEnd
    // }: CalendarEventTimesChangedEvent): void {
    //   event.start = newStart;
    //   event.end = newEnd;
    //   this.handleEvent('Dropped or resized', event);
    //   this.refresh.next();
    // }
    // handleEvent(action: string, event: CalendarEvent): void {
    //   this.modalData = { event, action };
    //   this.modal.open(this.modalContent, { size: 'lg' });
    // }
    SaloonDashboardComponent.prototype.addEvent = function () {
        this.events.push({
            title: 'New event',
            start: Object(__WEBPACK_IMPORTED_MODULE_1_date_fns__["startOfDay"])(new Date()),
            end: Object(__WEBPACK_IMPORTED_MODULE_1_date_fns__["endOfDay"])(new Date()),
            color: colors.red,
            draggable: true,
            resizable: {
                beforeStart: true,
                afterEnd: true
            }
        });
        this.refresh.next();
    };
    SaloonDashboardComponent.prototype.getAppointMentList = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonService.getAppointmentDetailsForSaloon(this.saloonId).subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response == true) {
                _this.appointmentDataToBeFiltered = data.data;
                _this.appointMentList = data.data;
                _this.totalAppointments = _this.appointmentDataToBeFiltered.length;
                _this.getBookingCount(_this.totalAppointments);
                // document.getElementById("totalappointments").setAttribute("value-data", this.totalAppointments)
                _this.filterFunction();
                _this.currentDateAppointment();
                console.log(JSON.stringify(_this.appointMentList));
                // code...
            }
        }, function (err) {
            console.log(err);
        });
    };
    SaloonDashboardComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.221.208.210/public/beauty-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    SaloonDashboardComponent.prototype.getHours = function (value) {
        // console.log(value);
        var value2 = value.split(':');
        var value3 = parseInt(value2[0]);
        if (value3 > 12) {
            var a = value3 - 12;
            return '0' + a;
        }
        else {
            if (value3 < 10) {
                return '0' + value3;
            }
            else {
                return value3;
            }
        }
    };
    SaloonDashboardComponent.prototype.getMin = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[1]);
        if (value3 < 10) {
            return '0' + value3;
        }
        else {
            return value3;
        }
    };
    SaloonDashboardComponent.prototype.getAmPm = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[0]);
        if (value3 > 11) {
            return 'Pm';
        }
        else {
            return 'Am';
        }
    };
    SaloonDashboardComponent.prototype.onPreviousDate = function () {
        this.appointMentList = this.appointmentDataToBeFiltered;
        console.log(this.appointMentList);
        var d = new Date(this.currentDate);
        // alert(d.getDate() - 1)
        var newDate = new Date(d.getTime() - 24 * 60 * 60 * 1000);
        this.previousDate = newDate;
        this.currentDate = this.previousDate;
        console.log("currentDate" + this.currentDate);
        console.log("previousDate" + this.previousDate);
        this.filterFunction();
    };
    SaloonDashboardComponent.prototype.onForwardDate = function () {
        this.appointMentList = this.appointmentDataToBeFiltered;
        var d = new Date(this.currentDate);
        var newDate = new Date(d.getTime() + 24 * 60 * 60 * 1000);
        this.forwardDate = newDate;
        this.currentDate = this.forwardDate;
        console.log("currentDate" + this.currentDate);
        console.log("forwardDate" + this.forwardDate);
        this.filterFunction();
    };
    SaloonDashboardComponent.prototype.filterFunction = function () {
        var _this = this;
        var c = new Date(this.currentDate);
        var selecteddate = c.getDate();
        var selectedMonth = c.getMonth() + 1;
        var selectedyear = c.getFullYear();
        var date1;
        var month1;
        if (selecteddate < 10) {
            date1 = '0' + selecteddate;
        }
        else {
            date1 = selecteddate;
        }
        if (selectedMonth < 10) {
            month1 = '0' + selectedMonth;
        }
        else {
            month1 = selectedMonth;
        }
        this.filterDate = selectedyear + '-' + month1 + '-' + date1;
        console.log(this.filterDate);
        this.appointMentList = this.appointMentList.filter(function (f) { return (f.date == _this.filterDate); });
    };
    SaloonDashboardComponent.prototype.currentDateAppointment = function () {
        var c = new Date(this.currentDate);
        var selecteddate = c.getDate();
        var selectedMonth = c.getMonth() + 1;
        var selectedyear = c.getFullYear();
        var date1;
        var month1;
        if (selecteddate < 10) {
            date1 = '0' + selecteddate;
        }
        else {
            date1 = selecteddate;
        }
        if (selectedMonth < 10) {
            month1 = '0' + selectedMonth;
        }
        else {
            month1 = selectedMonth;
        }
        var final = selectedyear + '-' + month1 + '-' + date1;
        console.log(this.filterDate);
        var appointMentList = this.appointMentList.filter(function (f) { return (f.date == final); });
        this.getCurrentBookingCount(appointMentList.length);
    };
    SaloonDashboardComponent.prototype.getBookingCount = function (data) {
        var totalSec = 0;
        this.countDown = __WEBPACK_IMPORTED_MODULE_4_rxjs_Observable__["a" /* Observable */].timer(0, this.tick)
            .take(data)
            .map(function () { return ++totalSec; });
        console.log(this.countDown);
    };
    SaloonDashboardComponent.prototype.getCurrentBookingCount = function (data) {
        var totalSec = 0;
        this.countDownCurrent = __WEBPACK_IMPORTED_MODULE_4_rxjs_Observable__["a" /* Observable */].timer(0, this.tick)
            .take(data)
            .map(function () { return ++totalSec; });
        // console.log(this.countDown)
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('modalContent'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["TemplateRef"])
    ], SaloonDashboardComponent.prototype, "modalContent", void 0);
    SaloonDashboardComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-saloon-dashboard',
            template: __webpack_require__("../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_3__providers_saloon_service__["a" /* SaloonService */]])
    ], SaloonDashboardComponent);
    return SaloonDashboardComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaloonDashboardModule", function() { return SaloonDashboardModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_angular_calendar__ = __webpack_require__("../../../../angular-calendar/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__ng_bootstrap_ng_bootstrap__ = __webpack_require__("../../../../@ng-bootstrap/ng-bootstrap/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__saloon_dashboard_routing_module__ = __webpack_require__("../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__saloon_dashboard_component__ = __webpack_require__("../../../../../src/app/header-three-layout/saloon-dashboard/saloon-dashboard.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__angular_material_progress_bar__ = __webpack_require__("../../../material/esm5/progress-bar.es5.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var SaloonDashboardModule = (function () {
    function SaloonDashboardModule() {
    }
    SaloonDashboardModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_9_ngx_pagination__["a" /* NgxPaginationModule */], __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_4__angular_forms__["e" /* FormsModule */], __WEBPACK_IMPORTED_MODULE_10__angular_material_progress_bar__["a" /* MatProgressBarModule */], __WEBPACK_IMPORTED_MODULE_6__saloon_dashboard_routing_module__["a" /* SaloonDashboardRoutingModule */], __WEBPACK_IMPORTED_MODULE_2_angular_calendar__["a" /* CalendarModule */].forRoot(), __WEBPACK_IMPORTED_MODULE_5__angular_common_http__["b" /* HttpClientModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_7__saloon_dashboard_component__["a" /* SaloonDashboardComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_8__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_3__ng_bootstrap_ng_bootstrap__["a" /* NgbModalModule */]]
        })
    ], SaloonDashboardModule);
    return SaloonDashboardModule;
}());



/***/ })

});
//# sourceMappingURL=saloon-dashboard.module.chunk.js.map