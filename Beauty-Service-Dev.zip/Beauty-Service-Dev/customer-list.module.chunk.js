webpackJsonp(["customer-list.module"],{

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerListRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__customer_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__customer_list_component__["a" /* CustomerListComponent */]
    }
];
var CustomerListRoutingModule = (function () {
    function CustomerListRoutingModule() {
    }
    CustomerListRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], CustomerListRoutingModule);
    return CustomerListRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n    <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n</div>\r\n<div class=\"page-content-wrapper\">\r\n\t<div class=\"page-content\">\r\n\t\t<ul class=\"page-breadcrumb breadcrumb hide\">\r\n\t\t\t<li>\r\n\t\t\t\t<a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n\t\t\t</li>\r\n\t\t\t<li class=\"active\">\r\n\t\t\t\t Dashboard\r\n\t\t\t</li>\r\n\t\t</ul>\r\n\t\t<!-- BEGIN PAGE CONTENT INNER -->\r\n\t\t<div class=\"emp-list-sec\">\r\n\t\t\t<div class=\"col-md-12 col-sm-12 p-0\">\r\n\t\t\t\t<!-- BEGIN PORTLET-->\r\n\t\t\t\t<div class=\"booking-section\">\r\n\t\t\t\t\t<div class=\"portlet light\">\r\n\t\t\t\t\t\t<div class=\"portlet-title\">\r\n\t\t\t\t\t\t\t<div class=\"caption caption-md\">\r\n\t\t\t\t\t\t\t\t<i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n\t\t\t\t\t\t\t\t<span class=\"caption-subject theme-font-color bold uppercase\">Customer List</span>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"portlet-body\">\r\n\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n\t\t\t\t\t\t\t\t<div class=\"send-token-main\">\r\n\t\t\t\t\t\t\t\t\t<button class=\"btn cus-btn token-btn\" data-toggle=\"modal\" data-target=\"#couponlist\" [disabled]=\"ids.length<=0\">Send Coupon</button>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"add-emp-form\">\r\n\t\t\t\t\t            \t<div class=\"table-responsive\">\r\n\t\t                                <table class=\"table table-bordered\">\r\n\t\t                                    <thead>\r\n\t\t                                    \t<tr>\r\n\t\t                                    \t\t<td colspan=\"8\">\r\n\t\t                                    \t\t\t<div class=\"cutome-th\" style=\"background-color:rgba(194, 24, 91, 0.698)\">\r\n\t\t\t                                    \t\t\t<span class=\"pull-left position1\">\r\n\t\t\t\t                                    \t\t\t<a href=\"#\"><i class=\"fa fa-angle-left\"></i></a>\r\n\t\t\t\t                                    \t\t</span>\r\n\t\t\t\t                                    \t\t\tNovember 10, 2017\r\n\t\t\t                                    \t\t\t<span class=\"pull-right position2\">\r\n\t\t\t\t                                    \t\t\t<a href=\"#\">\r\n\t\t\t\t                                    \t\t\t<i class=\"fa fa-angle-right\"></i>\r\n\t\t\t\t                                    \t\t\t</a>\r\n\t\t\t\t                                    \t\t</span>\r\n\t\t\t                                    \t\t</div>\r\n\t\t                                    \t\t</td>\r\n\t\t                                    \t</tr>\r\n\t\t                                        <tr>\r\n\t\t                                        \t<th>Select</th>\r\n\t\t                                        \t<th>Sr No</th>\r\n\t\t                                            <th>Customer Name</th>\r\n\t\t                                            <th>Email Address</th>\r\n\t\t                                            <th>Contact Number</th>\r\n\t\t                                           \t<th>Action</th>\r\n\t\t                                        </tr>\r\n\t\t                                    </thead>\r\n\t\t                                    <tbody>\r\n\t\t                                        <tr *ngFor=\"let customer of customersList | paginate: { itemsPerPage: 3, currentPage: p };let i=index\">\r\n\t\t                                        \t<td>\r\n\t\t                                        \t\t<ul class=\"select-check\">\r\n\t\t                                        \t\t\t<li>\r\n\t\t                                        \t\t\t\t<label class=\"remember-me\">\r\n\t\t\t                                                        <input type=\"checkbox\" (change)=\"onCustomerCheckbox(customer.customerRequestForAppointment.id)\">\r\n\t\t\t                                                        <span></span>\r\n\t\t\t                                                    </label>\r\n\t\t                                        \t\t\t</li>\r\n\t\t                                        \t\t</ul>\r\n\t\t                                        \t</td>\r\n\t\t                                        \t<td>{{i+1}}</td>\r\n\t\t                                            <td><img class=\"user-view\" [src]=\"imagePath(customer.customerRequestForAppointment.image)\">{{customer.customerRequestForAppointment.first_name}}</td>\r\n\t\t                                            <td>{{customer.customerRequestForAppointment.email}}</td>\r\n\t\t                                            <td>{{customer.customerRequestForAppointment.contact_number}}</td>\r\n\t\t                                            <td>\r\n\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t                                                    <li class=\"view-ic\">\r\n\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#view-bookinglist\" title=\"View\"  (click)=\"onView(customer)\">\r\n\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t                                                        </a>\r\n\t\t                                                    </li>\r\n\t\t                                                    <li class=\"close-ic\">\r\n\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t                                                        </a>\r\n\t\t                                                    </li>\r\n\t\t                                                </ul>\r\n\t\t                                            </td>\r\n\t\t                                        </tr>\r\n\t\t                                    </tbody>\r\n\t\t                                </table>\t\t\t\t\t                                \r\n\t\t                            </div>\r\n\t\t                            <div class=\"table-pagination\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"pagination\">\r\n\t\t\t\t\t\t\t\t\t\t  <!-- <a href=\"#\"><i class=\"fa fa-angle-left\"></i></a>\r\n\t\t\t\t\t\t\t\t\t\t  <a href=\"#\">1</a>\r\n\t\t\t\t\t\t\t\t\t\t  <a href=\"#\" class=\"active\">2</a>\r\n\t\t\t\t\t\t\t\t\t\t  <a href=\"#\">3</a>\r\n\t\t\t\t\t\t\t\t\t\t  <a href=\"#\"><i class=\"fa fa-angle-right\"></i></a> -->\r\n\t\t\t\t\t\t\t\t\t\t   <pagination-controls (pageChange)=\"p = $event\"  previousLabel=\"\"  nextLabel=\"\" ></pagination-controls>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t            </div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<!-- END PORTLET-->\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<!-- END PAGE CONTENT INNER -->\r\n\t</div>\r\n</div>\r\n\r\n\r\n<div class=\"modal fade custom-modal\" id=\"view-bookinglist\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" *ngIf=\"appointMentData\">\r\n\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t    <div class=\"modal-content\">\r\n\t        <div class=\"modal-header\">\r\n\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t                <span aria-hidden=\"true\">&times;</span>\r\n\t            </button>\r\n\t            <h4 class=\"modal-title\" id=\"myModalLabel\">View Customer</h4>\r\n\t        </div>\r\n\t        <div class=\"modal-body\">\r\n\t            <div class=\"add-emp-form\">\r\n\t                <form class=\"img-responsive\">\r\n\t                    <div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t                        <div class=\"row\">\r\n\t                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                <label>Customer Name <small class=\"manidatory\">*</small></label>\r\n\t                                <input disabled=\"\" type=\"text\" [value]=\"appointMentData.customerRequestForAppointment.first_name\" class=\"form-control\">\r\n\t                            </div>\r\n\t                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                <label>Customer Number<small class=\"manidatory\">*</small></label>\r\n\t                                <input disabled=\"\" type=\"text\" [value]=\"appointMentData.customerRequestForAppointment.contact_number\" class=\"form-control\">\r\n\t                            </div>\r\n\t                        </div>\r\n\t                        <div class=\"row\">\r\n\t                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                <label>Employee Name<small class=\"manidatory\">*</small></label>\r\n\t                                <div class=\"custom-select\">\r\n\t                                    <select disabled=\"\" class=\"form-control\" placeholder=\"Select Employee\">\r\n\t                                        <option disabled=\"\">Select Employee</option>\r\n\t                                        <option name=\"nsw\" selected=\"selected\">James</option>\r\n\t                                        <option name=\"vic\">Mary</option>\r\n\t                                        <option name=\"qld\" selected=\"selected\">Robert</option>\r\n\t                                        <option name=\"qld\">Jennifer</option>\r\n\t                                        <option name=\"qld\">Patricia</option>\r\n\t                                    </select>\r\n\t                                    <span class=\"caret\"></span>\r\n\t                                </div>\r\n\t                            </div>\r\n\t                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                <label>Employee Email <small class=\"manidatory\">*</small></label>\r\n\t                                <input disabled=\"\" type=\"email\" [value]=\"appointMentData.customerRequestForAppointment.email\" class=\"form-control\">\r\n\t                            </div>\r\n\t                        </div>\r\n\t                        <div class=\"row\">\r\n\t                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                <label>Select Gender<small class=\"manidatory\">*</small></label>\r\n\t                                <div class=\"custom-radio\">\r\n\t                                    <div class=\"radio-inline\">\r\n\t                                        <input checked=\"checked\" type=\"radio\" id=\"radio01\" name=\"radio\" />\r\n\t                                        <label for=\"radio01\">\r\n\t                                            <span><span></span></span>Male\r\n\t                                        </label>\r\n\t                                    </div>\r\n\t                                    <div class=\"radio-inline\">\r\n\t                                        <input type=\"radio\" id=\"radio02\" name=\"radio\" />\r\n\t                                        <label for=\"radio02\">\r\n\t                                            <span><span></span></span>Female\r\n\t                                        </label>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                            </div>\r\n\t                             <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                <label>Select Employee Services<small class=\"manidatory\">*</small></label>\r\n\t                                <div class=\"custom-select\">\r\n\t                                    <input disabled=\"\" type=\"text\" [value]=\"appointMentData.requestedServiceByCustomer.services_eng\" class=\"form-control\">\r\n\t                                </div>\r\n\t                            </div>\r\n\t                        </div>\r\n\t                        <div class=\"row\">\r\n\t                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                <label>Date <small class=\"manidatory\">*</small></label>\r\n\t                                <input disabled=\"\" class=\"form-control input-medium date-picker\" size=\"16\" type=\"text\" [value]=\"appointMentData.date\"/>\r\n\t                            </div>\r\n\t                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                <label>Change Time<small class=\"manidatory\">*</small></label>\r\n\t                                <div class=\"input-icon\">\r\n\t                                    <i class=\"fa fa-clock-o\"></i>\r\n\t                                    <input disabled=\"\" type=\"text\" class=\"form-control timepicker timepicker-24\">\r\n\t                                </div>\r\n\t                            </div>\r\n\t                        </div>\r\n\t                    </div>\r\n\t                    <div class=\"modal-footerbtn\">\r\n\t                        <span class=\"save-bt\">\r\n\t                            <button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t                             Confirm\r\n\t                            </button>\r\n\t                        </span>\r\n\t                    </div>\r\n\t                </form>\r\n\t            </div>\r\n\t        </div>\r\n\t    </div>\r\n\t</div>\r\n</div>\r\n\r\n\r\n<div class=\"modal fade custom-modal\" id=\"couponlist\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" *ngIf=\"couponCodes\">\r\n\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t    <div class=\"modal-content\">\r\n\t        <div class=\"modal-header\">\r\n\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t                <span aria-hidden=\"true\">&times;</span>\r\n\t            </button>\r\n\t            <h4 class=\"modal-title\" id=\"myModalLabel\">Select Coupon</h4>\r\n\t        </div>\r\n\t        <div class=\"modal-body\">\r\n\t            <div class=\"add-emp-form\">\r\n\t                <table class=\"table table-bordered\">\r\n\t                \t <thead>\r\n                            <tr>\r\n                            \t<th>Select</th>\r\n                            \t<th>Sr No</th>\r\n                                <th>Coupon Code</th>\r\n                                <th>Discount</th>\r\n                                <th>Discount Price</th>\r\n                            </tr>\r\n                        </thead>\r\n                        <tbody>\r\n\t\t                        <tr *ngFor=\"let coupon of couponCodes;let i=index\">\r\n\t\t                        \t<td>\r\n\t\t                        \t\t<mat-radio-button value=\"1\" (change)=\"onCouponCheckbox(coupon.id)\"></mat-radio-button>\r\n\t\t                        \t\t<!-- <ul class=\"select-check\">\r\n\t\t                        \t\t\t<li>\r\n\t\t                        \t\t\t\t<label class=\"remember-me\">\r\n\t\t                                            <input type=\"radio\" (change)=\"onCouponCheckbox(coupon.id)\" >\r\n\t\t                                            <span></span>\r\n\t\t                                        </label>\r\n\t\t                        \t\t\t</li>\r\n\t\t                        \t\t</ul>  -->\t                        \t\t<!-- <div class=\"custom-radio\">\r\n\t\t                        \t\t<div class=\"radio-inline\">\r\n\t                                            <input type=\"radio\" [value]=\"coupon.id\"  name=\"radio\" (change)=\"onCouponCheckbox(coupon.id)\" >\r\n\t                                            <label for=\"radio01\">\r\n\t                                                <span><span></span></span>Male\r\n\t                                            </label>\r\n\t                                        </div>\r\n\t                                    </div> -->\r\n\t\t                        \t</td>\r\n\t\t                        \t<td>{{i+1}}</td>\r\n\t\t                            <td>{{coupon.coupon_code}}</td>\r\n\t\t                            <td>{{coupon.discount_percent}}</td>\r\n\t\t                            <td>{{coupon.discount_price}}</td>\r\n\t\t                        </tr>\r\n                    \t</tbody>\r\n\t                </table>\r\n\t                <div class=\"modal-footerbtn\">\r\n                        <span class=\"save-bt\">\r\n                            <button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\" aria-label=\"Close\" (click)=\"onSendCoupon()\" [disabled]=\"!couponId\">\r\n                             Send\r\n                            </button>\r\n                        </span>\r\n\t                </div>\r\n\t            </div>\r\n\t        </div>\r\n\t    </div>\r\n\t</div>\r\n</div>"

/***/ }),

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var CustomerListComponent = (function () {
    function CustomerListComponent(router, commonService, saloonService, vcr, toastr) {
        this.router = router;
        this.commonService = commonService;
        this.saloonService = saloonService;
        this.toastr = toastr;
        this.customersList = [];
        this.ids = [];
        this.p = 1;
        this.waitLoader = false;
        this.saloonDetails = JSON.parse(localStorage['userdetails']);
        this.saloonId = this.saloonDetails.id;
        this.toastr.setRootViewContainerRef(vcr);
    }
    CustomerListComponent.prototype.ngOnInit = function () {
        this.getAppointMentList();
        this.getCoupons();
    };
    CustomerListComponent.prototype.getAppointMentList = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonService.getAppointmentDetailsForSaloon(this.saloonId).subscribe(function (data) {
            _this.waitLoader = false;
            _this.appointMents = data.data;
            _this.setCustomersList();
        }, function (err) {
        });
    };
    CustomerListComponent.prototype.imagePath = function (path) {
        if (path != null) {
            // code...
            if (path.indexOf('base64') == -1) {
                return 'http://18.221.208.210/public/beauty-service/' + path;
                // code...
            }
            else {
                return path;
            }
        }
        else {
            return "http://placehold.it/300x300";
        }
    };
    CustomerListComponent.prototype.getHours = function (value) {
        console.log(value);
        var value2 = value.split(':');
        var value3 = parseInt(value2[0]);
        if (value3 > 12) {
            var a = value3 - 12;
            return '0' + a;
        }
        else {
            if (value3 < 10) {
                return '0' + value3;
            }
            else {
                return value3;
            }
        }
    };
    CustomerListComponent.prototype.getMin = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[1]);
        if (value3 < 10) {
            return '0' + value3;
        }
        else {
            return value3;
        }
    };
    CustomerListComponent.prototype.getAmPm = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[0]);
        if (value3 > 11) {
            return 'Pm';
        }
        else {
            return 'Am';
        }
    };
    CustomerListComponent.prototype.onView = function (appointment) {
        this.appointMentData = appointment;
    };
    CustomerListComponent.prototype.setCustomersList = function () {
        for (var i = 0; i < this.appointMents.length; i++) {
            if (this.customersList.map(function (img) { return img.customer_id; }).indexOf(this.appointMents[i].customer_id) == -1) {
                this.customersList.push(this.appointMents[i]);
            }
        }
        console.log(this.customersList.length, "customer");
        console.log(this.appointMents.length, "appp");
    };
    CustomerListComponent.prototype.getCoupons = function () {
        var _this = this;
        this.commonService.couponList().subscribe(function (data) {
            if (data.success == true) {
                _this.couponCodes = data.couponCodesData;
            }
        }, function (err) {
            console.log(err);
        });
    };
    CustomerListComponent.prototype.onCustomerCheckbox = function (id) {
        // alert(id)
        if (this.ids.indexOf(id) == -1) {
            console.log("new id");
            this.ids.push(id);
            console.log(this.ids);
        }
        else {
            console.log("id exit");
            var index = this.ids.indexOf(id);
            console.log(index);
            var a = this.ids.splice(index, 1);
            console.log(this.ids);
        }
    };
    CustomerListComponent.prototype.onCouponCheckbox = function (couponId) {
        this.couponId = couponId;
        // alert(this.couponId)
    };
    CustomerListComponent.prototype.onSendCoupon = function () {
        var _this = this;
        var sendCouponsData = {
            ids: this.ids,
            coupon_id: this.couponId
        };
        this.commonService.sendCoupon(sendCouponsData).subscribe(function (data) {
            if (data.success == true) {
                _this.toastr.success("coupon code successfully sent", 'Coupon codes', { toastLife: 1000, showCloseButton: true });
                _this.router.navigate(['/header-three-layout']);
            }
            else {
                _this.toastr.error("Error while sending coupon code please try after some time", 'Coupon codes', { toastLife: 1000, showCloseButton: true });
            }
        }, function (err) {
            console.log(err);
        });
    };
    CustomerListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-customer-list',
            template: __webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_4__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_2__providers_common_service__["a" /* CommonService */], __WEBPACK_IMPORTED_MODULE_1__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"], __WEBPACK_IMPORTED_MODULE_3_ng2_toastr__["ToastsManager"]])
    ], CustomerListComponent);
    return CustomerListComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerListModule", function() { return CustomerListModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__customer_list_routing_module__ = __webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__customer_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__angular_material_radio__ = __webpack_require__("../../../material/esm5/radio.es5.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var CustomerListModule = (function () {
    function CustomerListModule() {
    }
    CustomerListModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_8__angular_material_radio__["a" /* MatRadioModule */], __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__customer_list_routing_module__["a" /* CustomerListRoutingModule */], __WEBPACK_IMPORTED_MODULE_4_ngx_pagination__["a" /* NgxPaginationModule */], __WEBPACK_IMPORTED_MODULE_7_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__customer_list_component__["a" /* CustomerListComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_5__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_6__providers_common_service__["a" /* CommonService */]],
        })
    ], CustomerListModule);
    return CustomerListModule;
}());



/***/ })

});
//# sourceMappingURL=customer-list.module.chunk.js.map