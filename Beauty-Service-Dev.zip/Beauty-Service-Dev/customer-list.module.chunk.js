webpackJsonp(["customer-list.module"],{

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerListRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__customer_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__customer_list_component__["a" /* CustomerListComponent */]
    }
];
var CustomerListRoutingModule = (function () {
    function CustomerListRoutingModule() {
    }
    CustomerListRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], CustomerListRoutingModule);
    return CustomerListRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list.component.html":
/***/ (function(module, exports) {

module.exports = "<!-- BEGIN CONTENT -->\r\n\t\t\t<div class=\"page-content-wrapper\">\r\n\t\t\t\t<div class=\"page-content\">\r\n\t\t\t\t\t<ul class=\"page-breadcrumb breadcrumb hide\">\r\n\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t<a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<li class=\"active\">\r\n\t\t\t\t\t\t\t Dashboard\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t\t<!-- BEGIN PAGE CONTENT INNER -->\r\n\t\t\t\t\t<div class=\"emp-list-sec\">\r\n\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 p-0\">\r\n\t\t\t\t\t\t\t<!-- BEGIN PORTLET-->\r\n\t\t\t\t\t\t\t<div class=\"booking-section\">\r\n\t\t\t\t\t\t\t\t<div class=\"portlet light\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-title\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"caption caption-md\">\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"caption-subject theme-font-color bold uppercase\">Customer List</span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-body\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"add-emp-form\">\r\n\t\t\t\t\t\t\t\t            \t<div class=\"table-responsive\">\r\n\t\t\t\t\t                                <table class=\"table table-bordered\">\r\n\t\t\t\t\t                                    <thead>\r\n\t\t\t\t\t                                    \t<tr>\r\n\t\t\t\t\t                                    \t\t<div class=\"cutome-th\" style=\"background-color:rgba(194, 24, 91, 0.698)\">\r\n\t\t\t\t\t                                    \t\t\t<span class=\"pull-left\">\r\n\t\t\t\t\t\t                                    \t\t\t<a href=\"#\"><i class=\"fa fa-angle-left\"></i></a>\r\n\t\t\t\t\t\t                                    \t\t</span>\r\n\t\t\t\t\t\t                                    \t\t\tNovember 10, 2017\r\n\t\t\t\t\t                                    \t\t\t<span class=\"pull-right\">\r\n\t\t\t\t\t\t                                    \t\t\t<a href=\"#\">\r\n\t\t\t\t\t\t                                    \t\t\t<i class=\"fa fa-angle-right\"></i>\r\n\t\t\t\t\t\t                                    \t\t\t</a>\r\n\t\t\t\t\t\t                                    \t\t</span>\r\n\t\t\t\t\t                                    \t\t</div>\r\n\t\t\t\t\t                                    \t</tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                        \t<th>Sr No</th>\r\n\t\t\t\t\t                                            <th>Customer Name</th>\r\n\t\t\t\t\t                                            <th>Email Address</th>\r\n\t\t\t\t\t                                            <th>Contact Number</th>\r\n\t\t\t\t\t                                            <th>Service</th>\r\n\t\t\t\t\t                                            <th>Time</th>\r\n\t\t\t\t\t                                            <th>Status</th>\r\n\t\t\t\t\t                                            <th>Action</th>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                    </thead>\r\n\t\t\t\t\t                                    <tbody>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                        \t<td>1</td>\r\n\t\t\t\t\t                                            <td><img class=\"user-view\" src=\"img/avatar9.jpg\">Smith</td>\r\n\t\t\t\t\t                                            <td>smith@gmail.com</td>\r\n\t\t\t\t\t                                            <td>+919907234590</td>\r\n\t\t\t\t\t                                            <td>Hair Cutting,Hair Color</td>\r\n\t\t\t\t\t                                            <td>12:00 PM - 12:30 PM</td>\r\n\t\t\t\t\t                                            <td>Completed</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" title=\"View\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                            <td>2</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<img class=\"user-view\" src=\"img/user-pro-2.jpg\">Jennifer\r\n\t\t\t\t\t                                           \t</td>\r\n\t\t\t\t\t                                            <td>jennifer@gmail.com</td>\t\r\n\t\t\t\t\t                                            <td>+919907234590</td>\r\n\t\t\t\t\t                                            <td>Nail Treatment,Skin</td>\r\n\t\t\t\t\t                                            <td>12:30 PM - 1:00 PM</td>\r\n\t\t\t\t\t                                            <td>Pending</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" title=\"View\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                            <td>3</td>\r\n\t\t\t\t\t                                            <td><img class=\"user-view\" src=\"img/user-pro-1.jpg\">Robert</td>\r\n\t\t\t\t\t                                            <td>robert@gmail.com</td>\r\n\t\t\t\t\t                                            <td>+919807234590</td>\r\n\t\t\t\t\t                                            <td>Nail Treatment</td>\r\n\t\t\t\t\t                                            <td>12:30 PM - 1:00 PM</td>\r\n\t\t\t\t\t                                            <td>Working</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" title=\"View\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                            <td>4</td>\r\n\t\t\t\t\t                                            <td><img class=\"user-view\" src=\"img/user-pro-3.jpg\">John</td>\r\n\t\t\t\t\t                                            <td>john@gmail.com</td>\r\n\t\t\t\t\t                                            <td>+919565234590</td>\r\n\t\t\t\t\t                                            <td>Massage</td>\r\n\t\t\t\t\t                                            <td>12:30 PM - 1:00 PM</td>\r\n\t\t\t\t\t                                            <td>Completed</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <!-- <li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-bookinglist\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li> -->\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" title=\"View\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                    </tbody>\r\n\t\t\t\t\t                                </table>\r\n\t\t\t\t\t                                <div class=\"table-pagination\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"pagination\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\"><i class=\"fa fa-angle-left\"></i></a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\">1</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\" class=\"active\">2</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\">3</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\"><i class=\"fa fa-angle-right\"></i></a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t                            </div>\r\n\t\t\t\t\t\t\t\t            </div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<!-- END PORTLET-->\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<!-- END PAGE CONTENT INNER -->\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<!-- END CONTENT -->"

/***/ }),

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CustomerListComponent = (function () {
    function CustomerListComponent() {
    }
    CustomerListComponent.prototype.ngOnInit = function () { };
    CustomerListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-customer-list',
            template: __webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], CustomerListComponent);
    return CustomerListComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/customer-list/customer-list.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerListModule", function() { return CustomerListModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__customer_list_routing_module__ = __webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__customer_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/customer-list/customer-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var CustomerListModule = (function () {
    function CustomerListModule() {
    }
    CustomerListModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__customer_list_routing_module__["a" /* CustomerListRoutingModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__customer_list_component__["a" /* CustomerListComponent */]]
        })
    ], CustomerListModule);
    return CustomerListModule;
}());



/***/ })

});
//# sourceMappingURL=customer-list.module.chunk.js.map