webpackJsonp(["add-service.module"],{

/***/ "../../../../../src/app/header-three-layout/add-service/add-service-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AddServiceRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__add_service_component__ = __webpack_require__("../../../../../src/app/header-three-layout/add-service/add-service.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__add_service_component__["a" /* AddServiceComponent */]
    }
];
var AddServiceRoutingModule = (function () {
    function AddServiceRoutingModule() {
    }
    AddServiceRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], AddServiceRoutingModule);
    return AddServiceRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/add-service/add-service.component.html":
/***/ (function(module, exports) {

module.exports = "\t\t\t <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n               <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n            </div>\r\n\t\t\t<!-- BEGIN CONTENT -->\r\n\t\t\t<div class=\"page-content-wrapper\">\r\n\t\t\t\t<div class=\"page-content\">\r\n\t\t\t\t\t<ul class=\"page-breadcrumb breadcrumb hide\">\r\n\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t<a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<li class=\"active\">\r\n\t\t\t\t\t\t\t Dashboard\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t\t<!-- BEGIN PAGE CONTENT INNER -->\r\n\t\t\t\t\t<div class=\"emp-list-sec\">\r\n\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 p-0\">\r\n\t\t\t\t\t\t\t<!-- BEGIN PORTLET-->\r\n\t\t\t\t\t\t\t<div class=\"booking-section\">\r\n\t\t\t\t\t\t\t\t<div class=\"portlet light\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-title\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"caption caption-md\">\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"caption-subject theme-font-color bold uppercase\">Add Services</span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"back-icon pull-right\">\r\n\t\t\t\t\t\t\t\t\t\t\t<a routerLink=\"/header-three-layout/service-list\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-angle-left\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t</a>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-body\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"add-emp-form\">\r\n\t\t\t\t\t\t\t\t            \t<form class=\"services-addform\" [formGroup]=\"addServicesForm\">\r\n\t\t\t\t\t\t\t            \t\t\t<div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t\t\t\t\t\t\t            \t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t                                                  \t<label>Select Category</label>\r\n\t\t\t                                                    <div class=\"custom-select\">\r\n\t\t\t                                                        <!-- <ss-multiselect-dropdown [options]=\"myOptions\" [(ngModel)]=\"optionsModel\" (ngModelChange)=\"onChange($event)\" [formControl]=\"addServicesForm.controls['category']\" ></ss-multiselect-dropdown> -->\r\n\t\t\t                                                        <select class=\"form-control\" placeholder=\"Select Category\" [formControl]=\"addServicesForm.controls['category']\"  [(ngModel)]=\"addServicesModel.category_id\">\r\n\t\t\t                                                            <option disabled=\"\">Select Time</option>\r\n\t\t\t                                                            <option *ngFor=\"let cat of categoryList\" [value]=\"cat.id\"><span>{{cat.category_eng}}</span></option>\r\n\t\t\t                                                        </select>\r\n\t\t\t                                                        <span class=\"caret\"></span>\r\n\t\t\t                                                        <p  *ngIf=\"addServicesForm.controls['category'].hasError('required') && addServicesForm.controls['category'].touched\">\r\n\t\t\t\t\t                                                     Category is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['category'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['category'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t                                                    </div>\r\n\t\t\t                                                </div>\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                    \t<label>Select Time</label>\r\n\t\t\t                                                    <div class=\"custom-select\">\r\n\t\t\t                                                        <select class=\"form-control\" placeholder=\"Select Category\" [formControl]=\"addServicesForm.controls['time']\"  [(ngModel)]=\"addServicesModel.time\">\r\n\t\t\t                                                            <option disabled=\"\">Select Time</option>\r\n\t\t\t                                                            <option value=\"15\">15 Min</option>\r\n\t\t\t                                                            <option value=\"30\">30 Min</option>\r\n\t\t\t                                                            <option value=\"45\">45 Min</option>\r\n\t\t\t                                                            <option value=\"60\">1 Hr</option>\r\n\t\t\t                                                            <option value=\"75\">1 Hr 15 Min</option>\r\n\t\t\t                                                            <option value=\"90\">1 Hr 30 Min</option>\r\n\t\t\t                                                            <option value=\"105\">1 Hr 45 Min</option>\r\n\t\t\t                                                            <option value=\"120\">2 Hr</option>\r\n\t\t\t                                                            <option value=\"135\">2 Hr 15 Min</option>\r\n\t\t\t                                                            <option value=\"150\">2 Hr 30 Min</option>\r\n\t\t\t                                                            <option value=\"165\">2 Hr 45 Min</option>\r\n\t\t\t                                                            <option value=\"180\">3 Hr</option>\r\n\t\t\t                                                        </select>\r\n\t\t\t                                                        <span class=\"caret\"></span>\r\n\t\t\t                                                        <p  *ngIf=\"addServicesForm.controls['time'].hasError('required') && addServicesForm.controls['time'].touched\">\r\n\t\t\t\t\t                                                     Time is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['time'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['time'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t                                                    </div>\r\n\t\t\t\t\t\t                                       \r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t                                                  \t  <label>Select Services<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <!-- <input type=\"text\" placeholder=\"Service Name In English\" [formControl]=\"addServicesForm.controls['serviceName_eng'] \" [(ngModel)]=\"addServicesModel.name_eng\"  class=\"form-control\"> -->\r\n\t\t\t\t\t\t                                        <div class=\"custom-select\">\r\n\t\t\t\t\t\t                                        <select class=\"form-control\" placeholder=\"Select Category\" [formControl]=\"addServicesForm.controls['serviceName_eng']\"  [(ngModel)]=\"addServicesModel.service_id\">\r\n\t\t\t                                                            <option disabled=\"\">Select service</option>\r\n\t\t\t                                                            <option *ngFor=\"let serv of getServiceOption()\" [value]=\"serv.id\"><span>{{serv.services_eng}}</span></option>\r\n\t\t\t                                                            <!-- <option value=\"30\">30 Min</option>\r\n\t\t\t                                                            <option value=\"45\">45 Min</option>\r\n\t\t\t                                                            <option value=\"60\">1 Hr</option>\r\n\t\t\t                                                            <option value=\"75\">1 Hr 15 Min</option>\r\n\t\t\t                                                            <option value=\"90\">1 Hr 30 Min</option>\r\n\t\t\t                                                            <option value=\"105\">1 Hr 45 Min</option>\r\n\t\t\t                                                            <option value=\"120\">2 Hr</option>\r\n\t\t\t                                                            <option value=\"135\">2 Hr 15 Min</option>\r\n\t\t\t                                                            <option value=\"150\">2 Hr 30 Min</option>\r\n\t\t\t                                                            <option value=\"165\">2 Hr 45 Min</option>\r\n\t\t\t                                                            <option value=\"180\">3 Hr</option> -->\r\n\t\t\t                                                        </select>\r\n\t\t\t                                                        <span class=\"caret\"></span>\r\n\t\t\t\t\t\t                                          <p  *ngIf=\"addServicesForm.controls['serviceName_eng'].hasError('required') && addServicesForm.controls['serviceName_eng'].touched\">\r\n\t\t\t\t\t                                                     Service Name in english  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceName_eng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceName_eng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                            </div>\r\n\t\t\t                                                </div>\r\n\t\t\t\t\t\t                                    <!-- <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                          <label>Service Name In Arabic<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Service Name In Arabic\" [formControl]=\"addServicesForm.controls['serviceName_arb']\" class=\"form-control\" [(ngModel)]=\"addServicesModel.name_arb\">\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addServicesForm.controls['serviceName_arb'].hasError('required') && addServicesForm.controls['serviceName_arb'].touched\">\r\n\t\t\t\t\t                                                     Service Name In Arabic  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceName_arb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceName_arb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div> -->\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                       \r\n\t\t\t\t\t\t                                        <label>Service Cost In English<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Service Cost In English\" [formControl]=\"addServicesForm.controls['serviceCost_eng']\" class=\"form-control\" [(ngModel)]=\"addServicesModel.cost_eng\" >\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addServicesForm.controls['serviceCost_eng'].hasError('required') && addServicesForm.controls['serviceCost_eng'].touched\">\r\n\t\t\t\t\t                                                     Service Cost In English  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceCost_eng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceCost_eng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                       <label>Service Cost In Arabic<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Service Cost In Arabic\" [formControl]=\"addServicesForm.controls['serviceCost_arb']\" class=\"form-control\" [(ngModel)]=\"addServicesModel.cost_arb\" >\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addServicesForm.controls['serviceCost_arb'].hasError('required') && addServicesForm.controls['serviceCost_arb'].touched\">\r\n\t\t\t\t\t                                                     Service Cost In Arabic  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceCost_arb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceCost_arb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>\r\n\t\t\t\t\t\t                                        \tService Description In English<small class=\"manidatory\">*</small>\r\n\t\t\t\t\t\t                                        </label>\r\n\t\t\t\t\t\t                                        <textarea class=\"cus-textarea form-control\" col=\"8\" rows=\"10\" placeholder=\"Service Description In English\" [formControl]=\"addServicesForm.controls['serviceDes_eng']\" [(ngModel)]=\"addServicesModel.description_eng\" ></textarea>\r\n\t\t\t\t\t\t                                         <p  *ngIf=\"addServicesForm.controls['serviceDes_eng'].hasError('required') && addServicesForm.controls['serviceDes_eng'].touched\">\r\n\t\t\t\t\t                                                     Service Description In English  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceDes_eng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceDes_eng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 500\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>\r\n\t\t\t\t\t\t                                        \tService Description In Arabic<small class=\"manidatory\">*</small>\r\n\t\t\t\t\t\t                                        </label>\r\n\t\t\t\t\t\t                                        <textarea class=\"cus-textarea form-control\" col=\"8\" rows=\"10\" placeholder=\"Service Description In Arabic\" [formControl]=\"addServicesForm.controls['serviceDes_arb']\" [(ngModel)]=\"addServicesModel.description_arb\" ></textarea>\r\n\t\t\t\t\t\t                                         <p  *ngIf=\"addServicesForm.controls['serviceDes_arb'].hasError('required') && addServicesForm.controls['serviceDes_arb'].touched\">\r\n\t\t\t\t\t                                                     Service Description In Arabic  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceDes_arb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceDes_arb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 500\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"modal-footerbtn\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t<span class=\"save-bt\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t\t<button class=\"btn cut-btn\" [disabled]=\"!addServicesForm.valid\" (click)=\"onAddService()\">Submit</button>\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t</span>\r\n\t\t\t\t\t\t\t\t\t\t\t          \t</div>\r\n\t\t\t\t\t\t\t            \t\t\t</div>\r\n\t\t\t\t\t\t\t\t            \t</form>\r\n\t\t\t\t\t\t\t\t            </div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<!-- END PORTLET-->\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<!-- END PAGE CONTENT INNER -->\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<!-- END CONTENT -->"

/***/ }),

/***/ "../../../../../src/app/header-three-layout/add-service/add-service.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-three-layout/add-service/add-service.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AddServiceComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__models_services__ = __webpack_require__("../../../../../src/app/models/services.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_rxjs_observable_forkJoin__ = __webpack_require__("../../../../rxjs/_esm5/observable/forkJoin.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var AddServiceComponent = (function () {
    function AddServiceComponent(router, fb, vcr, toastr, translate, saloonServices, commonServices) {
        this.router = router;
        this.fb = fb;
        this.toastr = toastr;
        this.translate = translate;
        this.saloonServices = saloonServices;
        this.commonServices = commonServices;
        this.addServicesModel = new __WEBPACK_IMPORTED_MODULE_7__models_services__["a" /* AddServices */]();
        this.userDetail = JSON.parse(localStorage['userdetails']);
        this.categoryList = [];
        this.serviceList = [];
        this.toastr.setRootViewContainerRef(vcr);
        this.addServicesForm = fb.group({
            'category': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'time': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'serviceName_eng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            //'serviceName_arb': [null, Validators.compose([Validators.required,Validators.maxLength(100)])],
            'serviceCost_eng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'serviceCost_arb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'serviceDes_eng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(500)])],
            'serviceDes_arb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(500)])],
        });
    }
    AddServiceComponent.prototype.ngOnInit = function () {
        this.myOptions = [
            { id: 1, name: 'Option 1' },
            { id: 2, name: 'Option 2' },
            { id: 3, name: 'Option 3' },
            { id: 4, name: 'Option 4' },
            { id: 5, name: 'Option 5' },
            { id: 6, name: 'Option 6' },
        ];
        this.getCategory();
    };
    AddServiceComponent.prototype.onChange = function () {
        console.log(this.optionsModel);
    };
    AddServiceComponent.prototype.getCategory = function () {
        var _this = this;
        this.waitLoader = true;
        Object(__WEBPACK_IMPORTED_MODULE_8_rxjs_observable_forkJoin__["a" /* forkJoin */])([this.commonServices.getCategory(), this.commonServices.getServices()])
            .subscribe(function (results) {
            var list = [];
            _this.waitLoader = false;
            console.log(results);
            if (results) {
                _this.categoryList = results[0].data;
                _this.serviceList = results[1].data;
                for (var i = 0; i < _this.categoryList.length; ++i) {
                    list.push({ id: _this.categoryList[i].id, name: _this.categoryList[i].category_eng });
                }
                _this.myOptions = list;
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    AddServiceComponent.prototype.onAddService = function () {
        var _this = this;
        this.waitLoader = true;
        //let a=this.optionsModel.slice(0)
        this.addServicesModel.saloon_id = this.userDetail.id;
        //this.addServicesModel.category=a.toString()
        this.saloonServices.Addservices(this.addServicesModel)
            .subscribe(function (data) {
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.toastr.success(data.message, 'Services Added successfully ', { toastLife: 1000, showCloseButton: true });
                _this.router.navigate(['/header-three-layout/service-list']);
            }
            else if (data.message == 'This Services already added with same saloon') {
                _this.toastr.error('This Services already added with same saloon', 'Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    AddServiceComponent.prototype.getServiceOption = function () {
        var _this = this;
        if (this.addServicesModel.category_id) {
            // code...
            var data = this.serviceList.filter(function (arg) { return arg.category_id == _this.addServicesModel.category_id; });
            return data;
        }
        else {
            return [];
        }
    };
    AddServiceComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-add-service',
            template: __webpack_require__("../../../../../src/app/header-three-layout/add-service/add-service.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-three-layout/add-service/add-service.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["b" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__["c" /* TranslateService */],
            __WEBPACK_IMPORTED_MODULE_5__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_6__providers_common_service__["a" /* CommonService */]])
    ], AddServiceComponent);
    return AddServiceComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/add-service/add-service.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddServiceModule", function() { return AddServiceModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_angular_2_dropdown_multiselect__ = __webpack_require__("../../../../angular-2-dropdown-multiselect/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__add_service_routing_module__ = __webpack_require__("../../../../../src/app/header-three-layout/add-service/add-service-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__add_service_component__ = __webpack_require__("../../../../../src/app/header-three-layout/add-service/add-service.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var AddServiceModule = (function () {
    function AddServiceModule() {
    }
    AddServiceModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_7__add_service_routing_module__["a" /* AddServiceRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["e" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["j" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_5_angular_2_dropdown_multiselect__["a" /* MultiselectDropdownModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_common_http__["b" /* HttpClientModule */],
                __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__["b" /* TranslateModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_8__add_service_component__["a" /* AddServiceComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_9__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_10__providers_common_service__["a" /* CommonService */]]
        })
    ], AddServiceModule);
    return AddServiceModule;
}());



/***/ })

});
//# sourceMappingURL=add-service.module.chunk.js.map