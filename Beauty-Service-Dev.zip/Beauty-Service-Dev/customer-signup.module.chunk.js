webpackJsonp(["customer-signup.module"],{

/***/ "../../../../../src/app/header-two-layout/customer-signup/customer-signup-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerSignupRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__customer_signup_component__ = __webpack_require__("../../../../../src/app/header-two-layout/customer-signup/customer-signup.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__customer_signup_component__["a" /* CustomerSignupComponent */]
    }
];
var CustomerSignupRoutingModule = (function () {
    function CustomerSignupRoutingModule() {
    }
    CustomerSignupRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], CustomerSignupRoutingModule);
    return CustomerSignupRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/customer-signup/customer-signup.component.html":
/***/ (function(module, exports) {

module.exports = "\r\n        <section class=\"login-section\">\r\n            <div class=\"container\">\r\n                <div class=\"login-inner\">\r\n                    <form class=\"signup-form common-form\" [formGroup]=\"customerSignupForm\">\r\n                        <h3 class=\"form-h after-line\">{{ 'customerSignup.SignUp' | translate }}</h3>\r\n                        <p class=\"title-d customer-sign\">{{ 'customerSignup.message1' | translate }}</p>\r\n                        <div class=\"saloon-wrap\">\r\n                            <div class=\"tab-on-form\">\r\n                                <ul class=\"nav nav-pills nav-stacked\">\r\n                                    <li class=\"active step-li\">\r\n                                       <button href=\"#tab_a\" data-toggle=\"pill\" [disabled]=\"currentTab!='tab1'\">\r\n                                           1\r\n                                       </button>\r\n                                       <p>{{ 'customerSignup.accountCreation' | translate }}</p> \r\n                                    </li>\r\n                                    <li class=\"\">\r\n                                       <button href=\"#tab_b\" data-toggle=\"pill\" [disabled]=\"currentTab!='tab2'\">\r\n                                          2\r\n                                       </button>\r\n                                       <p>{{ 'customerSignup.verificationDetails' | translate }}</p> \r\n                                    </li>\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"form-wrap\">\r\n                                <div class=\"tab-content\">\r\n                                    <div class=\"saloon-form tab-pane {{tab1}}\" id=\"tab_a\" *ngIf=\"currentTab=='tab1'\">\r\n                                        <div class=\"row\">\r\n                                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                <label>{{ 'customerSignup.enterFirstName' | translate }}</label>\r\n                                                <input type=\"text\" placeholder=\"{{ 'customerSignup.enterFirstName' | translate }}\" class=\"form-control\" [formControl]=\"customerSignupForm.controls['first_name']\" [(ngModel)]=\"customerSignUpModel.first_name\">\r\n                                                 <p  *ngIf=\"customerSignupForm.controls['first_name'].hasError('required') && customerSignupForm.controls['first_name'].touched\">\r\n                                                      First Name is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['first_name'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['first_name'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p> \r\n                                            </div>\r\n                                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                <label>{{ 'customerSignup.enterLastName' | translate }}</label>\r\n                                                <input type=\"text\" placeholder=\"{{ 'customerSignup.enterLastName' | translate }}\" class=\"form-control\" [formControl]=\"customerSignupForm.controls['last_name']\" [(ngModel)]=\"customerSignUpModel.last_name\">\r\n                                                 <p  *ngIf=\"customerSignupForm.controls['last_name'].hasError('required') && customerSignupForm.controls['last_name'].touched\">\r\n                                                       Last Name is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['last_name'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['last_name'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"row\">\r\n                                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                <label>{{ 'customerSignup.enterEmail' | translate }}</label>\r\n                                                <input type=\"text\" placeholder=\"{{ 'customerSignup.enterEmail' | translate }}\" class=\"form-control\" [formControl]=\"customerSignupForm.controls['email']\" [(ngModel)]=\"customerSignUpModel.email\">\r\n                                                 <p  *ngIf=\"customerSignupForm.controls['email'].hasError('required') && customerSignupForm.controls['email'].touched\">\r\n                                                       Email is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['email'].hasError('pattern')\">\r\n                                                           Enter valid email id\r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['email'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p>\r\n                                            </div>\r\n                                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                <label>{{ 'customerSignup.enterContactNumber' | translate }}</label>\r\n                                                <input type=\"text\" placeholder=\"{{ 'customerSignup.enterContactNumber' | translate }}\" class=\"form-control\" [formControl]=\"customerSignupForm.controls['contact_number']\" [(ngModel)]=\"customerSignUpModel.contact_number\">\r\n                                                <p  *ngIf=\"customerSignupForm.controls['contact_number'].hasError('required') && customerSignupForm.controls['contact_number'].touched\">\r\n                                                       Contact Number is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['contact_number'].hasError('pattern')\">\r\n                                                           Enter valid Contact Number (Only Digit) id\r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['contact_number'].hasError('maxlength')\">\r\n                                                           max length is 12\r\n                                                </p>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"row\">\r\n                                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                <label>{{ 'customerSignup.enterPassword' | translate }}</label>\r\n                                                <input type=\"password\" placeholder=\"{{ 'customerSignup.enterPassword' | translate }}\" class=\"form-control\" [formControl]=\"customerSignupForm.controls['password']\" [(ngModel)]=\"customerSignUpModel.password\">\r\n                                                <p  *ngIf=\"customerSignupForm.controls['password'].hasError('required') && customerSignupForm.controls['password'].touched\">\r\n                                                       Password is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['password'].hasError('pattern')\">\r\n                                                           Enter valid Contact Number (Only Digit) id\r\n                                                </p>\r\n                                                <p  *ngIf=\"customerSignupForm.controls['password'].hasError('maxlength')\">\r\n                                                           max length is 12\r\n                                                </p>\r\n                                            </div>\r\n                                            <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                <label>{{ 'customerSignup.selectGender' | translate }}</label>\r\n                                                <div class=\"custom-select\">\r\n                                                    <select class=\"form-control\"  [formControl]=\"customerSignupForm.controls['gender']\" [(ngModel)]=\"customerSignUpModel.gender\">\r\n                                                        <option disabled=\"\">Select Gender</option>\r\n                                                        <option name=\"Male\">Male</option>\r\n                                                        <option name=\"Female\">Female</option>\r\n                                                    </select>\r\n                                                    <span class=\"caret\"></span>\r\n                                                    <p  *ngIf=\"customerSignupForm.controls['gender'].hasError('required') && customerSignupForm.controls['gender'].touched\">\r\n                                                       Gender is <strong>required</strong>\r\n                                                        </p>\r\n                                                        <p  *ngIf=\"customerSignupForm.controls['gender'].hasError('pattern')\">\r\n                                                                   Enter valid Contact Number (Only Digit) id\r\n                                                        </p>\r\n                                                        <p  *ngIf=\"customerSignupForm.controls['gender'].hasError('maxlength')\">\r\n                                                                   max length is 12\r\n                                                        </p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"row\">\r\n                                            <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                <label>{{ 'customerSignup.enterYourCity' | translate }}</label>\r\n                                                <div class=\"custom-select\">\r\n                                                    <select class=\"form-control\"  [formControl]=\"customerSignupForm.controls['city']\" [(ngModel)]=\"customerSignUpModel.city\">\r\n                                                        <option disabled=\"\">Select City</option>\r\n                                                        <option name=\"Dubai\">Dubai</option>\r\n                                                        <option name=\"Abu Dhabi\">Abu Dhabi</option>\r\n                                                    </select>\r\n                                                    <span class=\"caret\"></span>\r\n                                                     <p  *ngIf=\"customerSignupForm.controls['city'].hasError('required') && customerSignupForm.controls['city'].touched\">\r\n                                                       City is <strong>required</strong>\r\n                                                        </p>\r\n                                                        <p  *ngIf=\"customerSignupForm.controls['city'].hasError('pattern')\">\r\n                                                                   Enter valid Contact Number (Only Digit) id\r\n                                                        </p>\r\n                                                        <p  *ngIf=\"customerSignupForm.controls['city'].hasError('maxlength')\">\r\n                                                                   max length is 12\r\n                                                        </p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"row\">\r\n                                            <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                <label class=\"remember-me\">\r\n                                                    <input type=\"checkbox\" checked=\"checked\" [formControl]=\"customerSignupForm.controls['termCondition']\" [(ngModel)]=\"customerSignUpModel.termCondition\"> {{ 'customerSignup.message4' | translate }} <a href=\"javascript:void(0);\">{{ 'customerSignup.message5' | translate }}</a>   {{ 'customerSignup.message6' | translate }} <a href=\"javascript:void(0);\">{{ 'customerSignup.message7' | translate }}</a>\r\n                                                    <span></span>\r\n                                                </label>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                            <div class=\"continue-btn saloon-btn\">\r\n                                                <button  [disabled]=\"!customerSignupForm.valid || customerSignUpModel.termCondition!=true \" class=\"btn cut-btn\" data-toggle=\"pill\" (click)=\"onContinue()\">{{ 'customerSignup.continue' | translate }}</button>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"saloon-form tab-pane {{tab2}}\" id=\"tab_b\" *ngIf=\"currentTab=='tab2'\">\r\n                                        <div class=\"varification-form\">\r\n                                            <h4>{{ 'customerSignup.otpmessage' | translate }}</h4>\r\n                                            <div class=\"varification-tab\">\r\n                                                <div class=\"col-md-offset-3 col-sm-6 col-md-6 col-xs-12\">\r\n                                                    <input type=\"text\" placeholder=\"{{ 'customerSignup.enterCode' | translate }}\" class=\"form-control\" [formControl]=\"OtpForm.controls['otp']\" [(ngModel)]=\"otp\">\r\n                                                </div>\r\n                                                <a href=\"javascript:void(0);\" class=\"opt-link\">{{ 'customerSignup.resendOTP' | translate }}</a>\r\n                                            </div>\r\n                                            <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                                <div class=\"continue-btn saloon-btn vari\">\r\n                                                    <span class=\"varify\">\r\n                                                        <a href=\"#tab_a\" class=\"btn cut-btn\" data-toggle=\"pill\">{{ 'customerSignup.back' | translate }}</a>\r\n                                                    </span>\r\n                                                    <span class=\"varify\">\r\n                                                        <button [disabled]=\"!OtpForm.valid\" class=\"btn cut-btn\" data-toggle=\"pill\" (click)=\"onVerify()\">{{ 'customerSignup.verify' | translate }}</button>\r\n                                                    </span>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/customer-signup/customer-signup.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/customer-signup/customer-signup.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerSignupComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__models_customer_modal__ = __webpack_require__("../../../../../src/app/models/customer.modal.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_customer_service__ = __webpack_require__("../../../../../src/app/providers/customer.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var CustomerSignupComponent = (function () {
    function CustomerSignupComponent(router, fb, vcr, toastr, customerService, translate) {
        this.router = router;
        this.fb = fb;
        this.toastr = toastr;
        this.customerService = customerService;
        this.translate = translate;
        this.customerSignUpModel = new __WEBPACK_IMPORTED_MODULE_5__models_customer_modal__["a" /* CustomerSignUpModel */]();
        this.currentTab = 'tab1';
        this.tab1 = 'active';
        this.tab2 = '';
        this.toastr.setRootViewContainerRef(vcr);
        this.customerSignupForm = fb.group({
            'first_name': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'last_name': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'email': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].pattern(EMAIL_REGEX)])],
            'contact_number': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(12), __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].pattern('[0-9]*')])],
            'password': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(12)])],
            'gender': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(30)])],
            'city': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(30)])],
            'termCondition': [false, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required])]
        });
        this.OtpForm = fb.group({
            'otp': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(8)])]
        });
    }
    CustomerSignupComponent.prototype.ngOnInit = function () { };
    CustomerSignupComponent.prototype.onContinue = function () {
        var _this = this;
        this.customerService.CustomerSignup(this.customerSignUpModel)
            .subscribe(function (data) {
            console.log(data);
            if (data.response) {
                _this.currentData = data;
                _this.currentTab = 'tab2';
                _this.tab1 = '';
                _this.tab2 = 'active';
                _this.toastr.success(data.message, 'Account Craetion', { toastLife: 1000, showCloseButton: true });
                // setTimeout(()=>{
                //  //this.router.navigate(['/login']);
                // },1000)
                //    alert(data.message)
            }
            else if (data.message == 'email Id already register with us') {
                _this.toastr.error('Email Id already register with us', 'Authentication Failed ', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Authentication Failed ', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    CustomerSignupComponent.prototype.onVerify = function () {
        if (this.otp == this.currentData.otp) {
            this.router.navigate(['/header-two-layout/login']);
        }
        else {
            this.toastr.error('Enter currect OTP ', 'Authentication Failed ', { toastLife: 3000, showCloseButton: true });
        }
    };
    CustomerSignupComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-customer-signup',
            template: __webpack_require__("../../../../../src/app/header-two-layout/customer-signup/customer-signup.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/customer-signup/customer-signup.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["a" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_6__providers_customer_service__["a" /* CustomerService */],
            __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__["c" /* TranslateService */]])
    ], CustomerSignupComponent);
    return CustomerSignupComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/customer-signup/customer-signup.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerSignupModule", function() { return CustomerSignupModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_material_select__ = __webpack_require__("../../../material/esm5/select.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__customer_signup_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/customer-signup/customer-signup-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__customer_signup_component__ = __webpack_require__("../../../../../src/app/header-two-layout/customer-signup/customer-signup.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__providers_customer_service__ = __webpack_require__("../../../../../src/app/providers/customer.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var CustomerSignupModule = (function () {
    function CustomerSignupModule() {
    }
    CustomerSignupModule.prototype.ngOnInit = function () {
    };
    CustomerSignupModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_7__customer_signup_routing_module__["a" /* CustomerSignupRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["c" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["h" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_material_select__["a" /* MatSelectModule */],
                __WEBPACK_IMPORTED_MODULE_4__angular_common_http__["b" /* HttpClientModule */], __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__["b" /* TranslateModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_8__customer_signup_component__["a" /* CustomerSignupComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_9__providers_customer_service__["a" /* CustomerService */]]
        })
    ], CustomerSignupModule);
    return CustomerSignupModule;
}());



/***/ }),

/***/ "../../../../../src/app/models/customer.modal.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerSignUpModel; });
var CustomerSignUpModel = (function () {
    function CustomerSignUpModel() {
    }
    return CustomerSignUpModel;
}());



/***/ })

});
//# sourceMappingURL=customer-signup.module.chunk.js.map