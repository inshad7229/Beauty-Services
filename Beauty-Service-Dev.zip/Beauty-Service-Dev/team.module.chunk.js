webpackJsonp(["team.module"],{

/***/ "../../../../../src/app/header-two-layout/team/team-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeamRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__team_component__ = __webpack_require__("../../../../../src/app/header-two-layout/team/team.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__team_component__["a" /* TeamComponent */]
    }
];
var TeamRoutingModule = (function () {
    function TeamRoutingModule() {
    }
    TeamRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], TeamRoutingModule);
    return TeamRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/team/team.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"about-main\">\n            <div class=\"about-top-head\">\n                <div class=\"about-heading\">\n                    <h2> Our Team </h2>\n                </div>\n            </div>\n\n            <div class=\"team-main\">\n                <div class=\"container\">\n                    <div class=\"tema-cntnt sc_team_style_team-2 \">\n                        <div class=\"col-md-6 col-sm-6 col-xs-12\">\n                            <div class=\"column-1_2 column_padding_bottom\">          \n                                <div class=\"sc_team_item sc_team_item_1 odd first columns_wrap\" id=\"sc_team_1619354517_1\">\n                                    <div class=\"sc_team_item_avatar column-1_2\">\n                                        <div class=\"image_hover_wrap\"><img width=\"300\" height=\"300\" src=\"assets/img/team1.jpg\" alt=\"Susan Lee\" class=\"wp-post-image img-responsive\" />                 \n                                            <a class=\"sc_team_item_hover\" href=\"javascript:void(0)\"></a>\n                                        </div>\n                                    </div>\n                                    <div class=\"sc_team_item_info column-1_2\">\n                                        <h5 class=\"sc_team_item_title\"><a href=\"javascript:void(0)\">Susan Lee</a></h5>\n                                        <div class=\"sc_team_item_position\">Makeup Artist</div>\n                                        <div class=\"sc_team_item_description\">\n                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat...\n                                        </div>\n                                        <div class=\"sc_socials\">\n                                            <ul>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-facebook fa-fw\"></i></a>\n                                                </li>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-twitter fa-fw\"></i></a>\n                                                </li>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-linkedin fa-fw\"></i></a>\n                                                </li>\n                                            </ul>\n                                        </div>           \n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n                        <div class=\"col-md-6 col-sm-6 col-xs-12\">\n                            <div class=\"column-1_2 column_padding_bottom\">          \n                                <div class=\"sc_team_item sc_team_item_1 odd first columns_wrap\" id=\"sc_team_1619354517_1\">\n                                    <div class=\"sc_team_item_avatar column-1_2\">\n                                        <div class=\"image_hover_wrap\"><img width=\"300\" height=\"300\" src=\"assets/img/team4.jpg\" alt=\"Susan Lee\" class=\"wp-post-image img-responsive\" />                 \n                                            <a class=\"sc_team_item_hover\" href=\"javascript:void(0)\"></a>\n                                        </div>\n                                    </div>\n                                    <div class=\"sc_team_item_info column-1_2\">\n                                        <h5 class=\"sc_team_item_title\"><a href=\"javascript:void(0)\">Elena Jones</a></h5>\n                                        <div class=\"sc_team_item_position\">Hairdresser</div>\n                                        <div class=\"sc_team_item_description\">\n                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat...\n                                        </div>\n                                        <div class=\"sc_socials\">\n                                            <ul>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-facebook fa-fw\"></i></a>\n                                                </li>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-twitter fa-fw\"></i></a>\n                                                </li>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-linkedin fa-fw\"></i></a>\n                                                </li>\n                                            </ul>\n                                        </div>           \n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n                        <div class=\"col-md-6 col-sm-6 col-xs-12\">\n                            <div class=\"column-1_2 column_padding_bottom\">          \n                                <div class=\"sc_team_item sc_team_item_1 odd first columns_wrap\" id=\"sc_team_1619354517_1\">\n                                    <div class=\"sc_team_item_avatar column-1_2\">\n                                        <div class=\"image_hover_wrap\"><img width=\"300\" height=\"300\" src=\"assets/img/team3.jpg\" alt=\"Susan Lee\" class=\"wp-post-image img-responsive\" />                 \n                                            <a class=\"sc_team_item_hover\" href=\"javascript:void(0)\"></a>\n                                        </div>\n                                    </div>\n                                    <div class=\"sc_team_item_info column-1_2\">\n                                        <h5 class=\"sc_team_item_title\"><a href=\"javascript:void(0)\">Lana Fox</a></h5>\n                                        <div class=\"sc_team_item_position\">Hairdresser</div>\n                                        <div class=\"sc_team_item_description\">\n                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat...\n                                        </div>\n                                        <div class=\"sc_socials\">\n                                            <ul>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-facebook fa-fw\"></i></a>\n                                                </li>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-twitter fa-fw\"></i></a>\n                                                </li>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-linkedin fa-fw\"></i></a>\n                                                </li>\n                                            </ul>\n                                        </div>           \n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n                        <div class=\"col-md-6 col-sm-6 col-xs-12\">\n                            <div class=\"column-1_2 column_padding_bottom\">          \n                                <div class=\"sc_team_item sc_team_item_1 odd first columns_wrap\" id=\"sc_team_1619354517_1\">\n                                    <div class=\"sc_team_item_avatar column-1_2\">\n                                        <div class=\"image_hover_wrap\"><img width=\"300\" height=\"300\" src=\"assets/img/team2.jpg\" alt=\"Susan Lee\" class=\"wp-post-image img-responsive\" />                 \n                                            <a class=\"sc_team_item_hover\" href=\"javascript:void(0)\"></a>\n                                        </div>\n                                    </div>\n                                    <div class=\"sc_team_item_info column-1_2\">\n                                        <h5 class=\"sc_team_item_title\"><a href=\"javascript:void(0)\">Tina Jackson</a></h5>\n                                        <div class=\"sc_team_item_position\">Stylist</div>\n                                        <div class=\"sc_team_item_description\">\n                                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat...\n                                        </div>\n                                        <div class=\"sc_socials\">\n                                            <ul>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-facebook fa-fw\"></i></a>\n                                                </li>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-twitter fa-fw\"></i></a>\n                                                </li>\n                                                <li>\n                                                    <a href=\"javascript:;\"> <i class=\"fa fa-linkedin fa-fw\"></i></a>\n                                                </li>\n                                            </ul>\n                                        </div>           \n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n\n                    </div>\n                </div>\n            </div>\n                \n            \n        </section>\n"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/team/team.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/team/team.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeamComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var TeamComponent = (function () {
    function TeamComponent() {
    }
    TeamComponent.prototype.ngOnInit = function () {
    };
    TeamComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-team',
            template: __webpack_require__("../../../../../src/app/header-two-layout/team/team.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/team/team.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], TeamComponent);
    return TeamComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/team/team.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamModule", function() { return TeamModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__team_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/team/team-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__team_component__ = __webpack_require__("../../../../../src/app/header-two-layout/team/team.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var TeamModule = (function () {
    function TeamModule() {
    }
    TeamModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2__team_routing_module__["a" /* TeamRoutingModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__team_component__["a" /* TeamComponent */]]
        })
    ], TeamModule);
    return TeamModule;
}());



/***/ })

});
//# sourceMappingURL=team.module.chunk.js.map