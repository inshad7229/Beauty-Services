webpackJsonp(["saloon-signup.module"],{

/***/ "../../../../../src/app/header-two-layout/saloon-signup/saloon-signup-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaloonSignupRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__saloon_signup_component__ = __webpack_require__("../../../../../src/app/header-two-layout/saloon-signup/saloon-signup.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__saloon_signup_component__["a" /* SaloonSignupComponent */]
    }
];
var SaloonSignupRoutingModule = (function () {
    function SaloonSignupRoutingModule() {
    }
    SaloonSignupRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], SaloonSignupRoutingModule);
    return SaloonSignupRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/saloon-signup/saloon-signup.component.html":
/***/ (function(module, exports) {

module.exports = "   <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n                 <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n   </div>\r\n<section class=\"login-section\">\r\n            <div class=\"container\">\r\n                <div class=\"login-inner\">\r\n                    <div class=\"signup-form common-form\">\r\n                        <h3 class=\"form-h after-line\">{{ 'saloonSignup.SignUp' | translate }}</h3>\r\n                        <p class=\"title-d\">{{ 'saloonSignup.message1' | translate }}</p>\r\n                        <div class=\"saloon-wrap\">\r\n                            <div class=\"tab-on-form\">\r\n                                <ul class=\"nav nav-pills nav-stacked\">\r\n                                    <li class=\"{{tab1}} step-li\">\r\n                                       <button href=\"#tab_a\" data-toggle=\"pill\" type=\"button\" [disabled]=\"currentTab!='tab1'\">\r\n                                           1\r\n                                       </button>\r\n                                       <p>{{ 'saloonSignup.accountCreation' | translate }}</p> \r\n                                    </li>\r\n                                    <li class=\"{{tab2}} step-li\">\r\n                                       <button href=\"#tab_b\" data-toggle=\"pill\" [disabled]=\"currentTab!='tab2'\">\r\n                                          2\r\n                                       </button>\r\n                                       <p>{{ 'saloonSignup.verificationDetails' | translate }}</p> \r\n                                    </li>\r\n                                    <li class=\"{{tab3}}\">\r\n                                       <button href=\"#tab_c\" data-toggle=\"pill\" [disabled]=\"currentTab!='tab3'\">\r\n                                          3\r\n                                       </button> \r\n                                       <p>{{ 'saloonSignup.updateSaloonDetails' | translate }}</p> \r\n                                    </li>\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"form-wrap\">\r\n                                <div class=\"tab-content\">\r\n                                        </div>\r\n                                    <div *ngIf=\"currentTab=='tab1'\" class=\"saloon-form tab-pane {{tab1}}\" id=\"tab_a\">\r\n                                         <form [formGroup]=\"accountCreationForm\">\r\n                                              <p class=\"info-text\">{{ 'saloonSignup.message2' | translate }}<a href=\"javascript:void(0);\">{{ 'saloonSignup.message3' | translate }}</a></p>\r\n                                            <div class=\"row\">\r\n\r\n\r\n\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>{{ 'saloonSignup.enterSaloonName' | translate }}</label>\r\n                                                    <input type=\"text\" placeholder=\"{{ 'saloonSignup.enterSaloonName' | translate }}\"  [formControl]=\"accountCreationForm.controls['saloonName']\" class=\"form-control\" [(ngModel)]=\"accountCreationModel.saloon_name\">\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['saloonName'].hasError('required') && accountCreationForm.controls['saloonName'].touched\">\r\n                                                       Name of Saloon Name is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['saloonName'].hasError('pattern')\">\r\n                                                               only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['saloonName'].hasError('maxlength')\">\r\n                                                               max length is 150\r\n                                                    </p> \r\n                                                </div>\r\n                                            </div>\r\n                                             \r\n                                            <div class=\"row\">\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>{{ 'saloonSignup.enterName' | translate }}</label>\r\n                                                    <input type=\"text\" placeholder=\"{{ 'saloonSignup.enterName' | translate }}\" [formControl]=\"accountCreationForm.controls['name']\" class=\"form-control\" [(ngModel)]=\"accountCreationModel.name\">\r\n                                                     <p  *ngIf=\"accountCreationForm.controls['name'].hasError('required') && accountCreationForm.controls['name'].touched\">\r\n                                                     Name is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['name'].hasError('pattern')\">\r\n                                                               only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['name'].hasError('maxlength')\">\r\n                                                               max length is 100\r\n                                                    </p>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"row\">\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>{{ 'saloonSignup.enterEmail' | translate }}</label>\r\n                                                    <input type=\"text\" placeholder=\"{{ 'saloonSignup.enterEmail' | translate }}\" [formControl]=\"accountCreationForm.controls['email']\" class=\"form-control\" [(ngModel)]=\"accountCreationModel.email\">\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['email'].hasError('required') && accountCreationForm.controls['email'].touched\">\r\n                                                     Email is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['email'].hasError('pattern')\">\r\n                                                               Please enter valid email address !!\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['email'].hasError('maxlength')\">\r\n                                                               max length is 30\r\n                                                    </p>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"row\">\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>{{ 'saloonSignup.enterContactNumber' | translate }}</label>\r\n                                                    <input type=\"text\" placeholder=\"{{ 'saloonSignup.enterContactNumber' | translate }}\" [formControl]=\"accountCreationForm.controls['contactNumber']\" class=\"form-control\" [(ngModel)]=\"accountCreationModel.contact_number\">\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['contactNumber'].hasError('required') && accountCreationForm.controls['contactNumber'].touched\">\r\n                                                     Contact Number is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['contactNumber'].hasError('pattern')\">\r\n                                                               only Numeric Value are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['contactNumber'].hasError('maxlength')\">\r\n                                                               max length is 12\r\n                                                    </p>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"row\">\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>{{ 'saloonSignup.enterPassword' | translate }}</label>\r\n                                                    <input type=\"password\" placeholder=\"{{ 'saloonSignup.enterPassword' | translate }}\" [formControl]=\"accountCreationForm.controls['password']\" class=\"form-control\" [(ngModel)]=\"accountCreationModel.password\" (input)=\"pass_confirm()\">\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['password'].hasError('required') && accountCreationForm.controls['password'].touched\">\r\n                                                     Password is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['password'].hasError('pattern')\">\r\n                                                               only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['password'].hasError('maxlength')\">\r\n                                                               max length is 12\r\n                                                    </p>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"row\">\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>{{ 'saloonSignup.enterConfirmPassword' | translate }}</label>\r\n                                                    <input type=\"password\" placeholder=\"{{ 'saloonSignup.enterPassword' | translate }}\"  [formControl]=\"accountCreationForm.controls['confirmPassword']\" class=\"form-control\" [(ngModel)]=\"accountCreationModel.confirmPassword\" (input)=\"confirm()\">\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['confirmPassword'].hasError('required') && accountCreationForm.controls['confirmPassword'].touched\">\r\n                                                     Confirm Password is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['confirmPassword'].hasError('pattern')\">\r\n                                                               only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['confirmPassword'].hasError('maxlength')\">\r\n                                                               max length is 12\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"message\">\r\n                                                               Password and confirm password must be same !!\r\n                                                    </p>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"row\">\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>{{ 'saloonSignup.enterYourCity' | translate }}</label>\r\n                                                    <!-- <input type=\"text\" placeholder=\"{{ 'saloonSignup.enterYourCity' | translate }}\" [formControl]=\"accountCreationForm.controls['city']\" class=\"form-control\" [(ngModel)]=\"accountCreationModel.city\"> -->\r\n                                                <input placeholder=\"{{ 'saloonSignup.enterYourCity' | translate }}\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"off\" type=\"text\" [formControl]=\"accountCreationForm.controls['city']\" class=\"form-control\" [(ngModel)]=\"accountCreationModel.city\"  #search>\r\n                                                <p  *ngIf=\"accountCreationForm.controls['city'].hasError('required') && accountCreationForm.controls['city'].touched\">\r\n                                                     City is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"accountCreationForm.controls['city'].hasError('pattern')\">\r\n                                                           Only alphabets are acceptable \r\n                                                </p>  \r\n                                                <p  *ngIf=\"accountCreationForm.controls['city'].hasError('maxlength')\">\r\n                                                           Max length is 300\r\n                                                </p>\r\n                                              <agm-map [latitude]=\"accountCreationModel.latitude\" [longitude]=\"accountCreationModel.longitude\" [scrollwheel]=\"false\" [zoom]=\"zoom\">\r\n                                                <agm-marker [latitude]=\"accountCreationModel.latitude\" [longitude]=\"accountCreationModel.longitude\"></agm-marker>\r\n                                              </agm-map>\r\n                                                    \r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"row\">\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\" checked=\"checked\" [formControl]=\"accountCreationForm.controls['termCondition']\" [(ngModel)]=\"accountCreationModel.term\"> {{ 'saloonSignup.message4' | translate }} <a href=\"javascript:void(0);\">{{ 'saloonSignup.message5' | translate }}</a>   {{ 'saloonSignup.message6' | translate }} <a href=\"javascript:void(0);\">{{ 'saloonSignup.message7' | translate }}</a>\r\n                                                        <span></span>\r\n                                                        <p  *ngIf=\"accountCreationForm.controls['termCondition'].hasError('required') && accountCreationForm.controls['termCondition'].touched\">\r\n                                                     Please accept   <strong>Term's & conditions</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['termCondition'].hasError('pattern')\">\r\n                                                               Only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"accountCreationForm.controls['termCondition'].hasError('maxlength')\">\r\n                                                               Max length is 30\r\n                                                    </p>\r\n                                                    </label>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                                <div class=\"continue-btn saloon-btn\">\r\n                                                    <button [disabled]=\"!accountCreationForm.valid || message || accountCreationModel.term==false\" class=\"btn cut-btn\" data-toggle=\"pill\" (click)=\"onContinue()\">{{ 'saloonSignup.continue' | translate }}</button>\r\n                                                </div>\r\n                                            </div>\r\n                                         </form>\r\n                                           \r\n                                    </div>\r\n                                    <div *ngIf=\"currentTab=='tab2'\" class=\"saloon-form tab-pane {{tab2}}\" id=\"tab_b\">\r\n                                        <div class=\"varification-form\">\r\n                                             <form [formGroup]=\"verifiactionForm\">\r\n                                                <h4>{{ 'saloonSignup.otpmessage' | translate }}</h4>\r\n                                                <div class=\"varification-tab\">\r\n                                                    <div class=\"col-md-offset-3 col-sm-6 col-md-6 col-xs-12\">\r\n                                                        <input type=\"text\" placeholder=\"{{ 'saloonSignup.enterCode' | translate }}\" [formControl]=\"verifiactionForm.controls['otp']\" [(ngModel)]=\"verifiactionModel.otp\" class=\"form-control\">\r\n                                                    <p *ngIf=\"verifiactionForm.controls['otp'].hasError('required') && verifiactionForm.controls['otp'].touched\">\r\n                                                     otp is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"verifiactionForm.controls['otp'].hasError('pattern')\">\r\n                                                               Only alphabets are acceptable \r\n                                                    </p>  \r\n                                                    <p  *ngIf=\"verifiactionForm.controls['otp'].hasError('maxlength')\">\r\n                                                               Max length is 30\r\n                                                    </p>\r\n                                                    </div>\r\n                                                    <a href=\"javascript:void(0);\" class=\"opt-link\">{{ 'saloonSignup.resendOTP' | translate }}</a>\r\n                                                </div>\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                                    <div class=\"continue-btn saloon-btn vari\">\r\n                                                        <span class=\"varify\">\r\n                                                            <a href=\"javascript:void(0)\" class=\"btn cut-btn\" data-toggle=\"pill\">{{ 'saloonSignup.back' | translate }}</a>\r\n                                                        </span>\r\n                                                        <span class=\"varify\">\r\n                                                            <button [disabled]=\"!verifiactionForm.valid\"  class=\"btn cut-btn\" data-toggle=\"pill\" (click)=\"onVerifyOtp()\">{{ 'saloonSignup.verify' | translate }}</button>\r\n                                                        </span>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </form>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div *ngIf=\"currentTab=='tab3'\" class=\"saloon-form tab-pane {{tab3}}\" id=\"tab_c\">\r\n                                        <div class=\"saloon-details\">\r\n                                            <form [formGroup]=\"saloonDetailsForm\">\r\n                                                <div class=\"row\">\r\n                                                    <div class=\"col-md-offset-3 col-md-6 col-sm-6  col-xs-12\">\r\n                                                        <!-- <label>Upload Saloon Logo</label> -->\r\n                                                        <div class=\"form-group custom-upload\">\r\n                                                            <div class=\"file-previewimg\">\r\n                                                                <img *ngIf=\"!saloonDetailsModel.image\" src=\"assets/img/no-img.png\" class=\"img-responsive\" alt=\"NO-IMAGES\">\r\n                                                                 <img *ngIf=\"saloonDetailsModel.image\" [src]=\"saloonDetailsModel.image\" class=\"img-responsive\" alt=\"NO-IMAGES\">\r\n                                                            </div>\r\n                                                            <div class=\"profile-upload\">\r\n                                                                <div class=\"input-btn\">\r\n                                                                    <input type=\"file\"  (change)=\"imageUploadEvent($event)\" accept=\"image/gif, image/jpeg, image/png\" />\r\n                                                                    <button class=\"btn cus-btn\"> \r\n                                                                    <i class=\"fa fa-file-image-o\"></i>{{ 'saloonSignup.saloonLogo' | translate }}</button>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- <div class=\"row\">\r\n                                                    <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>{{ 'saloonSignup.selectCategory' | translate }}</label>\r\n                                                    <div class=\"custom-select\">\r\n                                                       <ss-multiselect-dropdown [formControl]=\"saloonDetailsForm.controls['selectCategory']\"  [options]=\"myOptions\" [(ngModel)]=\"optionsModel\" (ngModelChange)=\"onChange($event)\"></ss-multiselect-dropdown>\r\n                                                    </div>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <div class=\"row\">\r\n                                                    <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                      <label>{{ 'saloonSignup.selectService' | translate }}</label>\r\n                                                        <div class=\"custom-select\">\r\n                                                             <ss-multiselect-dropdown [formControl]=\"saloonDetailsForm.controls['selectService']\" [options]=\"myOptions2\" [(ngModel)]=\"optionsModel2\" (ngModelChange)=\"onChange2($event)\" ></ss-multiselect-dropdown>\r\n                                                        </div>\r\n                                                    </div>\r\n                                                </div> -->\r\n\r\n                                             <div class=\"row\">\r\n                                               \r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>Opening Time</label>\r\n                                                    <ngb-timepicker [(ngModel)]=\"time1\" [meridian]=\"true\" [spinners]=\"false\" [formControl]=\"saloonDetailsForm.controls['time1']\" ></ngb-timepicker>\r\n                                                     <p  *ngIf=\"saloonDetailsForm.controls['time1'].hasError('required') && saloonDetailsForm.controls['time1'].touched\">\r\n                                                     time is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"saloonDetailsForm.controls['time1'].hasError('pattern')\">\r\n                                                               only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"saloonDetailsForm.controls['time1'].hasError('maxlength')\">\r\n                                                               max length is 100\r\n                                                    </p>\r\n                                            </div>\r\n                                         </div>\r\n\r\n                                            <div class=\"row\">\r\n                                               \r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <label>Closing Time</label>\r\n                                                    <ngb-timepicker [(ngModel)]=\"time2\" [meridian]=\"true\" [spinners]=\"false\" [formControl]=\"saloonDetailsForm.controls['time2']\" ></ngb-timepicker>\r\n                                                     <p  *ngIf=\"saloonDetailsForm.controls['time2'].hasError('required') && saloonDetailsForm.controls['time2'].touched\">\r\n                                                     time is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"saloonDetailsForm.controls['time2'].hasError('pattern')\">\r\n                                                               only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"saloonDetailsForm.controls['time2'].hasError('maxlength')\">\r\n                                                               max length is 100\r\n                                                    </p>\r\n                                            </div>\r\n                                           </div>\r\n                                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                                    <div class=\"continue-btn saloon-btn vari\">\r\n                                                        <span class=\"varify\">\r\n                                                            <a href=\"javascript:void(0);\" class=\"btn cut-btn\" data-toggle=\"pill\">{{ 'saloonSignup.cancel' | translate }}</a>\r\n                                                        </span>\r\n                                                        <span class=\"varify\">\r\n                                                            <button href=\"javascript:void(0)\" [disabled]=\"!saloonDetailsForm.valid\" class=\"btn cut-btn\" (click)=\"onSubmit()\">{{ 'saloonSignup.Submit' | translate }}</button>\r\n                                                        </span>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </form>\r\n\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/saloon-signup/saloon-signup.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "agm-map {\n  height: 300px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/saloon-signup/saloon-signup.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaloonSignupComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__agm_core__ = __webpack_require__("../../../../@agm/core/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__models_saloon_modal__ = __webpack_require__("../../../../../src/app/models/saloon.modal.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var SaloonSignupComponent = (function () {
    function SaloonSignupComponent(router, fb, saloonServices, vcr, toastr, translate, mapsAPILoader, ngZone) {
        this.router = router;
        this.fb = fb;
        this.saloonServices = saloonServices;
        this.toastr = toastr;
        this.translate = translate;
        this.mapsAPILoader = mapsAPILoader;
        this.ngZone = ngZone;
        this.saloonDetailsModel = new __WEBPACK_IMPORTED_MODULE_7__models_saloon_modal__["b" /* SaloonDetailsModel */]();
        this.accountCreationModel = new __WEBPACK_IMPORTED_MODULE_7__models_saloon_modal__["a" /* AccountCreationModel */]();
        this.verifiactionModel = new __WEBPACK_IMPORTED_MODULE_7__models_saloon_modal__["c" /* VerifiactionModel */]();
        this.currentTab = 'tab1';
        this.message = false;
        this.otpStatus = true;
        this.tab1 = 'active';
        this.tab2 = '';
        this.tab3 = '';
        this.meridian = true;
        this.waitLoader = false;
        this.time1 = {};
        this.time2 = {};
        this.time1.hour = 9;
        this.time1.minute = 30;
        this.time2.hour = 20;
        this.time2.minute = 30;
        this.toastr.setRootViewContainerRef(vcr);
        this.accountCreationForm = fb.group({
            'saloonName': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(150)])],
            'name': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'email': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].pattern(EMAIL_REGEX)])],
            'contactNumber': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(12), __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].pattern('[0-9]*')])],
            'password': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(12)])],
            'confirmPassword': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(12)])],
            'city': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(300)])],
            'termCondition': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required])]
        });
        this.verifiactionForm = fb.group({
            'otp': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required])]
        });
        this.saloonDetailsForm = fb.group({
            // 'selectCategory': [null, Validators.compose([Validators.required])],
            // 'selectService': [null, Validators.compose([Validators.required])],
            'time1': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required])],
            'time2': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required])]
        });
    }
    SaloonSignupComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.myOptions = [
            { id: 1, name: 'Option 1' },
            { id: 2, name: 'Option 2' },
            { id: 3, name: 'Option 3' },
            { id: 4, name: 'Option 4' },
            { id: 5, name: 'Option 5' },
            { id: 6, name: 'Option 6' },
        ];
        this.myOptions2 = [
            { id: 1, name: 'Option 1' },
            { id: 2, name: 'Option 2' },
            { id: 3, name: 'Option 3' },
            { id: 4, name: 'Option 4' },
            { id: 5, name: 'Option 5' },
            { id: 6, name: 'Option 6' },
        ];
        //set google maps defaults
        this.zoom = 4;
        this.accountCreationModel.latitude = 39.8282;
        this.accountCreationModel.longitude = -98.5795;
        //create search FormControl
        //set current position
        this.setCurrentPosition();
        //load Places Autocomplete
        this.mapsAPILoader.load().then(function () {
            var autocomplete = new google.maps.places.Autocomplete(_this.searchElementRef.nativeElement, {
                types: ["address"]
            });
            autocomplete.addListener("place_changed", function () {
                _this.ngZone.run(function () {
                    //get the place result
                    var place = autocomplete.getPlace();
                    // alert(place.formatted_address)
                    //verify result
                    if (place.geometry === undefined || place.geometry === null) {
                        return;
                    }
                    //set latitude, longitude and zoom
                    _this.accountCreationModel.city = place.formatted_address;
                    _this.accountCreationModel.latitude = place.geometry.location.lat();
                    _this.accountCreationModel.longitude = place.geometry.location.lng();
                    _this.zoom = 12;
                });
            });
        });
    };
    SaloonSignupComponent.prototype.setCurrentPosition = function () {
        var _this = this;
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(function (position) {
                _this.accountCreationModel.latitude = position.coords.latitude;
                _this.accountCreationModel.longitude = position.coords.longitude;
                _this.zoom = 12;
            });
        }
    };
    SaloonSignupComponent.prototype.toggleMeridian = function () {
        this.meridian = !this.meridian;
    };
    SaloonSignupComponent.prototype.onChange = function () {
        console.log(this.optionsModel);
    };
    SaloonSignupComponent.prototype.onChange2 = function () {
        console.log(this.optionsModel2);
    };
    SaloonSignupComponent.prototype.confirm = function () {
        if (this.accountCreationModel.password == this.accountCreationModel.confirmPassword) {
            this.message = false;
        }
        else {
            this.message = true;
        }
    };
    SaloonSignupComponent.prototype.pass_confirm = function () {
        if (this.accountCreationModel.confirmPassword) {
            // code...
            if (this.accountCreationModel.password == this.accountCreationModel.confirmPassword) {
                this.message = false;
            }
            else {
                this.message = true;
            }
        }
    };
    SaloonSignupComponent.prototype.onContinue = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonServices.SaloonSignup(this.accountCreationModel)
            .subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response) {
                _this.currentData = data;
                _this.currentTab = 'tab2';
                _this.tab1 = '';
                _this.tab2 = 'active';
                _this.tab3 = '';
                _this.toastr.success(data.message, 'Account Craetion', { toastLife: 1000, showCloseButton: true });
                // setTimeout(()=>{
                //  //this.router.navigate(['/login']);
                // },1000)
                //    alert(data.message)
            }
            else if (data.message == 'email Id already register with us') {
                _this.toastr.error('Email Id already register with us', 'Authentication Failed ', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Authentication Failed ', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    SaloonSignupComponent.prototype.imageUploadEvent = function (evt) {
        var _this = this;
        if (!evt.target) {
            return;
        }
        if (!evt.target.files) {
            return;
        }
        if (evt.target.files.length !== 1) {
            return;
        }
        var file = evt.target.files[0];
        if (file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif' && file.type !== 'image/jpg') {
            return;
        }
        var fr = new FileReader();
        fr.onloadend = function (loadEvent) {
            _this.saloonDetailsModel.image = fr.result;
            console.log(_this.saloonDetailsModel.image);
        };
        fr.readAsDataURL(file);
    };
    SaloonSignupComponent.prototype.onSubmit = function () {
        var _this = this;
        this.waitLoader = true;
        //let a=this.optionsModel2.slice(0)
        // let b=this.optionsModel.slice(0)
        this.saloonDetailsModel.saloonId = this.currentData.result.id;
        // this.saloonDetailsModel.services=a.toString()
        //this.saloonDetailsModel.category=b.toString()
        this.saloonDetailsModel.opening_time = this.time1.hour + ':' + this.time1.minute;
        this.saloonDetailsModel.closing_time = this.time2.hour + ':' + this.time2.minute;
        // this.saloonDetailsModel.opening_time=JSON.stringify(this.time1)
        // this.saloonDetailsModel.closing_time=JSON.stringify(this.time2)
        this.saloonDetailsModel.status = 1;
        this.saloonServices.SaloonUpdate(this.saloonDetailsModel)
            .subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response) {
                _this.toastr.success(data.message, 'Account Craetion', { toastLife: 3000, showCloseButton: true });
                // setTimeout(()=>{
                _this.router.navigate(['/header-two-layout/login']);
                // },3000)
                //    alert(data.message)
            }
            else if (data.message == 'email Id already register with us') {
                _this.toastr.error('Email Id already register with us', 'Authentication Failed ', { toastLife: 3000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Authentication Failed ', { toastLife: 3000, showCloseButton: true });
            }
        });
    };
    SaloonSignupComponent.prototype.onVerifyOtp = function () {
        if (this.verifiactionModel.otp == this.currentData.otp) {
            this.currentTab = 'tab3';
            this.tab1 = '';
            this.tab2 = '';
            this.tab3 = 'active';
        }
        else {
            this.toastr.error('Enter currect OTP ', 'Authentication Failed ', { toastLife: 3000, showCloseButton: true });
        }
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])("search"),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SaloonSignupComponent.prototype, "searchElementRef", void 0);
    SaloonSignupComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-saloon-signup',
            template: __webpack_require__("../../../../../src/app/header-two-layout/saloon-signup/saloon-signup.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/saloon-signup/saloon-signup.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["b" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_6__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__["c" /* TranslateService */],
            __WEBPACK_IMPORTED_MODULE_5__agm_core__["b" /* MapsAPILoader */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["NgZone"]])
    ], SaloonSignupComponent);
    return SaloonSignupComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/saloon-signup/saloon-signup.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaloonSignupModule", function() { return SaloonSignupModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_material_select__ = __webpack_require__("../../../material/esm5/select.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_angular_2_dropdown_multiselect__ = __webpack_require__("../../../../angular-2-dropdown-multiselect/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__agm_core__ = __webpack_require__("../../../../@agm/core/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__ng_bootstrap_ng_bootstrap__ = __webpack_require__("../../../../@ng-bootstrap/ng-bootstrap/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__saloon_signup_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/saloon-signup/saloon-signup-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__saloon_signup_component__ = __webpack_require__("../../../../../src/app/header-two-layout/saloon-signup/saloon-signup.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};













var SaloonSignupModule = (function () {
    function SaloonSignupModule() {
    }
    SaloonSignupModule.prototype.ngOnInit = function () {
        $('.multiselect').multiselect();
    };
    SaloonSignupModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_10__saloon_signup_routing_module__["a" /* SaloonSignupRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["e" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["j" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_material_select__["a" /* MatSelectModule */],
                __WEBPACK_IMPORTED_MODULE_6_angular_2_dropdown_multiselect__["a" /* MultiselectDropdownModule */],
                __WEBPACK_IMPORTED_MODULE_4__angular_common_http__["b" /* HttpClientModule */],
                __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_7__ngx_translate_core__["b" /* TranslateModule */],
                __WEBPACK_IMPORTED_MODULE_9__ng_bootstrap_ng_bootstrap__["b" /* NgbModule */].forRoot(),
                __WEBPACK_IMPORTED_MODULE_8__agm_core__["a" /* AgmCoreModule */].forRoot({
                    apiKey: "AIzaSyCSqtRTdfc2DOAYpOut4KEwS1xL5or4ekI",
                    libraries: ["places"]
                }),
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_11__saloon_signup_component__["a" /* SaloonSignupComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_12__providers_saloon_service__["a" /* SaloonService */]]
        })
    ], SaloonSignupModule);
    return SaloonSignupModule;
}());



/***/ })

});
//# sourceMappingURL=saloon-signup.module.chunk.js.map