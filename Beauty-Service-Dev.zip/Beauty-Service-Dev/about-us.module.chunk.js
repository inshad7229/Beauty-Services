webpackJsonp(["about-us.module"],{

/***/ "../../../../../src/app/header-two-layout/about-us/about-us-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AboutUsRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__about_us_component__ = __webpack_require__("../../../../../src/app/header-two-layout/about-us/about-us.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__about_us_component__["a" /* AboutUsComponent */]
    }
];
var AboutUsRoutingModule = (function () {
    function AboutUsRoutingModule() {
    }
    AboutUsRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], AboutUsRoutingModule);
    return AboutUsRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/about-us/about-us.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"about-main\">\n    <div class=\"about-top-head\">\n        <div class=\"about-heading\">\n            <h2> About Us </h2>\n        </div>\n    </div>\n    <div class=\"about-cntnt-main\">\n        <!-- <div class=\"smll-desc\">\n            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\n            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\n            consequat.Excepteur sint occaecat cupidatat non\n            proident sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n        </div> -->\n        <div class=\"row\">\n            <div class=\"col-md-6 col-sm-6 col-xs-12\">\n                <div class=\"about-img\">\n                    <img src=\"assets/img/aboutimg.jpg\" class=\"img-responsive\" />\n                </div>\n            </div>\n            <div class=\"col-md-6 col-sm-6 col-xs-12\">\n                <div class=\"about-sumry\">\n                    <div class=\"section-title text-left\">\n                        <h2>Our <span class=\"pink\">Company</span></h2>\n                    </div>\n                    <p *ngIf=\"aboutUsContent\">{{aboutUsContent.aboutUsData[0].about}}</p>\n                    <!-- <ul>\n                        <li>Lorem ipsum dolor sit amet sed do eiusmod\n                        tempor incididunt ut labore et dolore magna aliqua.</li>\n                        <li>Duis aute irure dolor in reprehenderit in voluptate velit esse\n                        cillum dolore eu fugiat nulla pariatur.</li>\n                        <li>Lorem ipsum dolor sit amet sed do eiusmod\n                        tempor incididunt ut labore et dolore magna aliqua.</li>\n                        <li>Duis aute irure dolor in reprehenderit in voluptate velit esse\n                        cillum dolore eu fugiat nulla pariatur.</li>\n                        <li>Lorem ipsum dolor sit amet sed do eiusmod\n                        tempor incididunt ut labore et dolore magna aliqua.</li>\n                        <li>Duis aute irure dolor in reprehenderit in voluptate velit esse\n                        cillum dolore eu fugiat nulla pariatur.</li>\n                    </ul> -->\n                </div>\n            </div>\n        </div>\n    </div>\n</section>\n<section class=\"our-services\">\n    <div id=\"services\" class=\"services item\">\n        <div class=\"section-title text-center\">\n            <h2>Our <span class=\"pink\">Services</span></h2>\n        </div>\n        <div class=\"container\">\n            <div class=\"col-md-12 col-sm-12 col-xs-12\">\n                <div class=\"row\">\n                    <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\" *ngFor=\"let service of serviceList;let i=index\">\n                        <div class=\"service\" >\n                            <a href=\"#\">\n                                <img alt=\"...\" src=\"http://18.221.208.210/public/beauty-service/{{service.image}}\">\n                                <div class=\"img-content\">\n                                    {{service.services_eng}} <i class=\"fa fa-angle-right\"></i>\n                                </div>\n                            </a>\n                        </div>\n                    </div>\n                </div>\n                <!-- <div class=\"row\">\n                    <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\n                        <div class=\"service\">\n                            <a href=\"#\">\n                                <img alt=\"...\" src=\"assets/img/massage-therapy.jpg\">\n                                <div class=\"img-content\">\n                                    Massage Treatments <i class=\"fa fa-angle-right\"></i>\n                                </div>\n                            </a>\n                        </div>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\n                        <div class=\"service\">\n                            <a href=\"#\">\n                                <img alt=\"...\" src=\"assets/img/facials.jpg\">\n                                <div class=\"img-content\">\n                                    Top Facial Treatments <i class=\"fa fa-angle-right\"></i>\n                                </div>\n                            </a>\n\n                        </div>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\n                        <div class=\"service\">\n                            <a href=\"#\">\n                                <img alt=\"...\" src=\"assets/img/img-7.png\">\n                                <div class=\"img-content\">\n                                    Elite Hair Wash <i class=\"fa fa-angle-right\"></i>\n                                </div>\n                            </a>\n\n                        </div>\n                    </div>\n                </div>\n                <div class=\"row\">\n                    <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\n                        <div class=\"service\">\n\n                            <a href=\"#\">\n                                <img alt=\"...\" src=\"assets/img/img-1.png\">\n                                <div class=\"img-content\">\n                                    Nail Treatment <i class=\"fa fa-angle-right\"></i>\n                                </div>\n                            </a>\n\n                        </div>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\n                        <div class=\"service\">\n                            <a href=\"#\">\n                                <img alt=\"...\" src=\"assets/img/color.png\">\n                                <div class=\"img-content\">\n                                    Top Hair Color Salons<i class=\"fa fa-angle-right\"></i>\n                                </div>\n                            </a>\n\n                        </div>\n                    </div>\n                    <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\n                        <div class=\"service\">\n                            <a href=\"#\">\n                                <img alt=\"...\" src=\"assets/img/img-4.png\">\n                                <div class=\"img-content\">\n                                    Top Hair Cut Salons<i class=\"fa fa-angle-right\"></i>\n                                </div>\n                            </a>\n                        </div>\n                    </div>\n                </div> -->\n            </div>\n        </div>\n    </div>\n</section>\n"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/about-us/about-us.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/about-us/about-us.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AboutUsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_rxjs_Observable__ = __webpack_require__("../../../../rxjs/_esm5/Observable.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs_add_observable_timer__ = __webpack_require__("../../../../rxjs/_esm5/add/observable/timer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_rxjs_add_operator_map__ = __webpack_require__("../../../../rxjs/_esm5/add/operator/map.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_rxjs_add_operator_take__ = __webpack_require__("../../../../rxjs/_esm5/add/operator/take.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_rxjs_add_observable_forkJoin__ = __webpack_require__("../../../../rxjs/_esm5/add/observable/forkJoin.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var AboutUsComponent = (function () {
    function AboutUsComponent(commonServices) {
        this.commonServices = commonServices;
    }
    AboutUsComponent.prototype.ngOnInit = function () {
        this.getAboutUsData();
    };
    AboutUsComponent.prototype.getAboutUsData = function () {
        var _this = this;
        __WEBPACK_IMPORTED_MODULE_2_rxjs_Observable__["a" /* Observable */].forkJoin([this.commonServices.homePageContent(), this.commonServices.getServices()]).subscribe(function (results) {
            if (results[0].response == true) {
                _this.aboutUsContent = results[0];
                console.log(_this.aboutUsContent);
            }
            if (results[1].response == true) {
                _this.serviceList = results[1].data.slice(0, 6);
            }
        }, function (error) {
            console.log(error);
        });
    };
    AboutUsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-about-us',
            template: __webpack_require__("../../../../../src/app/header-two-layout/about-us/about-us.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/about-us/about-us.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__providers_common_service__["a" /* CommonService */]])
    ], AboutUsComponent);
    return AboutUsComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/about-us/about-us.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutUsModule", function() { return AboutUsModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__about_us_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/about-us/about-us-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__about_us_component__ = __webpack_require__("../../../../../src/app/header-two-layout/about-us/about-us.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var AboutUsModule = (function () {
    function AboutUsModule() {
    }
    AboutUsModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2__about_us_routing_module__["a" /* AboutUsRoutingModule */]
            ],
            providers: [__WEBPACK_IMPORTED_MODULE_4__providers_common_service__["a" /* CommonService */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__about_us_component__["a" /* AboutUsComponent */]]
        })
    ], AboutUsModule);
    return AboutUsModule;
}());



/***/ })

});
//# sourceMappingURL=about-us.module.chunk.js.map