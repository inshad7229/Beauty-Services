webpackJsonp(["service-list.module"],{

/***/ "../../../../../src/app/header-three-layout/service-list/service-list-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ServiceListRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__service_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/service-list/service-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__service_list_component__["a" /* ServiceListComponent */]
    }
];
var ServiceListRoutingModule = (function () {
    function ServiceListRoutingModule() {
    }
    ServiceListRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], ServiceListRoutingModule);
    return ServiceListRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/service-list/service-list.component.html":
/***/ (function(module, exports) {

module.exports = "\t <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n         <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n </div>\r\n\t<!-- BEGIN CONTENT -->\r\n\t\t\t<div class=\"page-content-wrapper\">\r\n\t\t\t\t<div class=\"page-content\">\r\n\t\t\t\t\t<ul class=\"page-breadcrumb breadcrumb hide\">\r\n\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t<a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<li class=\"active\">\r\n\t\t\t\t\t\t\t Dashboard\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t\t<!-- BEGIN PAGE CONTENT INNER -->\r\n\t\t\t\t\t<div class=\"emp-list-sec\">\r\n\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 p-0\">\r\n\t\t\t\t\t\t\t<!-- BEGIN PORTLET-->\r\n\t\t\t\t\t\t\t<div class=\"booking-section\">\r\n\t\t\t\t\t\t\t\t<div class=\"portlet light\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-title\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"caption caption-md\">\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"caption-subject theme-font-color bold uppercase\">Services List</span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-body services-list\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"add-emp-form\">\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"add-employee\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<a routerLink=\"/header-three-layout/add-service\" class=\"btn cus-btn\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-plus\"></i> Add Services\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t            \t<div class=\"table-responsive\">\r\n\t\t\t\t\t                                <table class=\"table table-bordered\">\r\n\t\t\t\t\t                                    <thead>\r\n\t\t\t\t\t                                        <tr class=\"emp-tr\">\r\n\t\t\t\t\t                                        \t<th>Sr No</th>\r\n\t\t\t\t\t                                            <th>Service Name</th>\r\n\t\t\t\t\t                                            <th>Time</th>\r\n\t\t\t\t\t                                            <th>Cost</th>\r\n\t\t\t\t\t                                            <!-- <th>Employee Name</th> -->\r\n\t\t\t\t\t                                            <th>Action</th>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                    </thead>\r\n\t\t\t\t\t                                    <tbody *ngIf=\"saloonServiceList && serviceList\">\r\n\t\t\t\t\t                                        <tr *ngFor=\"let data of saloonServiceList| paginate: { itemsPerPage: 3, currentPage: p }; let i=index  \">\r\n\t\t\t\t\t                                        \t<td>{{i+1}}</td>\r\n\t\t\t\t\t                                            <td><span>{{getServiceName(data.service_id)}}</span><span></span></td>\r\n\t\t\t\t\t                                            <td><span>{{getTime(data.time)}}</span><span></span></td>\r\n\t\t\t\t\t                                            <td><span>{{data.cost_eng}}</span><span></span></td>\r\n\t\t\t\t\t                                            <!-- <td><img class=\"user-view\" src=\"img/avatar9.jpg\">Smith</td> -->\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon service-list\">\r\n\t\t\t\t\t                                            \t\t<li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-servicelist\"  (click)=\"onEdit(data)\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-target=\"#view-service\" data-toggle=\"modal\"   (click)=\"onview(data)\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-target=\"#conformation-modal\" data-toggle=\"modal\"  (click)=\"ondelete(data)\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                       <!--  <tr>\r\n\t\t\t\t\t                                            <td>2</td>\r\n\t\t\t\t\t                                            <td>Nail Treatment</td>\r\n\t\t\t\t\t                                            <td>45 Min</td>\r\n\t\t\t\t\t                                            <td>$30</td>\t\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<img class=\"user-view\" src=\"img/user-pro-2.jpg\">Jennifer\r\n\t\t\t\t\t                                           \t</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon service-list\">\r\n\t\t\t\t\t                                            \t\t<li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-servicelist\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" title=\"View\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                            <td>3</td>\r\n\t\t\t\t\t                                            <td>Facial Treatment</td>\r\n\t\t\t\t\t                                            <td>2 hr 30 Min</td>\r\n\t\t\t\t\t                                            <td>$500</td>\r\n\t\t\t\t\t                                            <td><img class=\"user-view\" src=\"img/user-pro-1.jpg\">Robert</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon service-list\">\r\n\t\t\t\t\t                                            \t\t<li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-servicelist\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" title=\"View\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                            <td>4</td>\r\n\t\t\t\t\t                                            <td>Massage Treatments</td>\r\n\t\t\t\t\t                                            <td>3 Hr </td>\r\n\t\t\t\t\t                                            <td>$1000</td>\r\n\t\t\t\t\t                                            <td><img class=\"user-view\" src=\"img/user-pro-3.jpg\">John</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon service-list\">\r\n\t\t\t\t\t                                                    <li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-servicelist\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" title=\"View\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr> -->\r\n\t\t\t\t\t                                    </tbody>\r\n\t\t\t\t\t                                </table>\r\n\t\t\t\t\t                                <div class=\"table-pagination\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"pagination\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t <!--  <a href=\"#\"><i class=\"fa fa-angle-left\"></i></a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\">1</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\" class=\"active\">2</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\">3</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\"><i class=\"fa fa-angle-right\"></i></a> -->\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t  <pagination-controls (pageChange)=\"p = $event\"  previousLabel=\"\"  nextLabel=\"\" ></pagination-controls>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t                            </div>\r\n\t\t\t\t\t\t\t\t            </div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<!-- END PORTLET-->\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<!-- END PAGE CONTENT INNER -->\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<!-- END CONTENT -->\r\n\t\t\r\n\t\t<div class=\"modal fade custom-modal\" id=\"edit-servicelist\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n\t\t\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t\t\t    <div class=\"modal-content\">\r\n\t\t\t        <div class=\"modal-header\">\r\n\t\t\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t            \t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t            </button>\r\n\t\t\t            <h4 class=\"modal-title\" id=\"myModalLabel\">Edit Service List</h4>\r\n\t\t\t        </div>\r\n\t\t\t        <div class=\"modal-body\">\r\n\t\t\t            <div class=\"add-emp-form\">\r\n\t\t\t            \t<form class=\"services-addform\" [formGroup]=\"addServicesForm\">\r\n\t\t\t\t\t\t\t            \t\t\t<div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t\t\t\t\t\t\t            \t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t                                                  \t<label>Select Category</label>\r\n\t\t\t                                                    <div class=\"custom-select\">\r\n\t\t\t                                                       <select class=\"form-control\" placeholder=\"Select Category\" [formControl]=\"addServicesForm.controls['category']\"  [(ngModel)]=\"addServicesModel.category_id\">\r\n\t\t\t                                                            <option disabled=\"\">Select Category</option>\r\n\t\t\t                                                            <option *ngFor=\"let cat of categoryList\" [value]=\"cat.id\"><span>{{cat.category_eng}}</span></option>\r\n\t\t\t                                                        </select>\r\n\t\t\t                                                        <span class=\"caret\"></span>\r\n\t\t\t                                                        <p  *ngIf=\"addServicesForm.controls['category'].hasError('required') && addServicesForm.controls['category'].touched\">\r\n\t\t\t\t\t                                                     Category is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['category'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['category'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t                                                    </div>\r\n\t\t\t                                                </div>\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                    \t<label>Select Time</label>\r\n\t\t\t                                                    <div class=\"custom-select\">\r\n\t\t\t                                                        <select class=\"form-control\" placeholder=\"Select Category\" [formControl]=\"addServicesForm.controls['time']\"  [(ngModel)]=\"addServicesModel.time\">\r\n\t\t\t                                                            <option disabled=\"\">Select Time</option>\r\n\t\t\t                                                            <option value=\"15\">15 Min</option>\r\n\t\t\t                                                            <option value=\"30\">30 Min</option>\r\n\t\t\t                                                            <option value=\"45\">45 Min</option>\r\n\t\t\t                                                            <option value=\"60\">1 Hr</option>\r\n\t\t\t                                                            <option value=\"75\">1 Hr 15 Min</option>\r\n\t\t\t                                                            <option value=\"90\">1 Hr 30 Min</option>\r\n\t\t\t                                                            <option value=\"105\">1 Hr 45 Min</option>\r\n\t\t\t                                                            <option value=\"120\">2 Hr</option>\r\n\t\t\t                                                            <option value=\"135\">2 Hr 15 Min</option>\r\n\t\t\t                                                            <option value=\"150\">2 Hr 30 Min</option>\r\n\t\t\t                                                            <option value=\"165\">2 Hr 45 Min</option>\r\n\t\t\t                                                            <option value=\"180\">3 Hr</option>\r\n\t\t\t                                                        </select>\r\n\t\t\t                                                        <span class=\"caret\"></span>\r\n\t\t\t                                                        <p  *ngIf=\"addServicesForm.controls['time'].hasError('required') && addServicesForm.controls['time'].touched\">\r\n\t\t\t\t\t                                                     Time is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['time'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['time'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t                                                    </div>\r\n\t\t\t\t\t\t                                       \r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t                                                  \t  <label>Service Name In English<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                       <!--  <input type=\"text\" placeholder=\"Service Name In English\" [formControl]=\"addServicesForm.controls['serviceName_eng'] \" [(ngModel)]=\"addServicesModel.name_eng\"  class=\"form-control\"> -->\r\n\t\t\t\t\t\t                                       <div class=\"custom-select\">\r\n\t\t\t\t\t\t                                        <select class=\"form-control\" placeholder=\"Select Category\" [formControl]=\"addServicesForm.controls['serviceName_eng']\"  [(ngModel)]=\"addServicesModel.service_id\">\r\n\t\t\t                                                            <option disabled=\"\">Select service</option>\r\n\t\t\t                                                            <option *ngFor=\"let serv of getServiceOption()\" [value]=\"serv.id\"><span>{{serv.services_eng}}</span></option>\r\n\t\t\t                                                            <!-- <option value=\"30\">30 Min</option>\r\n\t\t\t                                                            <option value=\"45\">45 Min</option>\r\n\t\t\t                                                            <option value=\"60\">1 Hr</option>\r\n\t\t\t                                                            <option value=\"75\">1 Hr 15 Min</option>\r\n\t\t\t                                                            <option value=\"90\">1 Hr 30 Min</option>\r\n\t\t\t                                                            <option value=\"105\">1 Hr 45 Min</option>\r\n\t\t\t                                                            <option value=\"120\">2 Hr</option>\r\n\t\t\t                                                            <option value=\"135\">2 Hr 15 Min</option>\r\n\t\t\t                                                            <option value=\"150\">2 Hr 30 Min</option>\r\n\t\t\t                                                            <option value=\"165\">2 Hr 45 Min</option>\r\n\t\t\t                                                            <option value=\"180\">3 Hr</option> -->\r\n\t\t\t                                                        </select>\r\n\t\t\t                                                        <span class=\"caret\"></span>\r\n\t\t\t\t\t\t                                          <p  *ngIf=\"addServicesForm.controls['serviceName_eng'].hasError('required') && addServicesForm.controls['serviceName_eng'].touched\">\r\n\t\t\t\t\t                                                     Service Name in english  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceName_eng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceName_eng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                            </div>\r\n\t\t\t                                                </div>\r\n\t\t\t\t\t\t                                    <!-- <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                          <label>Service Name In Arabic<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Service Name In Arabic\" [formControl]=\"addServicesForm.controls['serviceName_arb']\" class=\"form-control\" [(ngModel)]=\"addServicesModel.name_arb\">\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addServicesForm.controls['serviceName_arb'].hasError('required') && addServicesForm.controls['serviceName_arb'].touched\">\r\n\t\t\t\t\t                                                     Service Name In Arabic  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceName_arb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceName_arb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div> -->\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                       \r\n\t\t\t\t\t\t                                        <label>Service Cost In English<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Service Cost In English\" [formControl]=\"addServicesForm.controls['serviceCost_eng']\" class=\"form-control\" [(ngModel)]=\"addServicesModel.cost_eng\" >\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addServicesForm.controls['serviceCost_eng'].hasError('required') && addServicesForm.controls['serviceCost_eng'].touched\">\r\n\t\t\t\t\t                                                     Service Cost In English  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceCost_eng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceCost_eng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                       <label>Service Cost In Arabic<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Service Cost In Arabic\" [formControl]=\"addServicesForm.controls['serviceCost_arb']\" class=\"form-control\" [(ngModel)]=\"addServicesModel.cost_arb\" >\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addServicesForm.controls['serviceCost_arb'].hasError('required') && addServicesForm.controls['serviceCost_arb'].touched\">\r\n\t\t\t\t\t                                                     Service Cost In Arabic  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceCost_arb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceCost_arb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>\r\n\t\t\t\t\t\t                                        \tService Description In English<small class=\"manidatory\">*</small>\r\n\t\t\t\t\t\t                                        </label>\r\n\t\t\t\t\t\t                                        <textarea class=\"cus-textarea form-control\" col=\"8\" rows=\"10\" placeholder=\"Service Description In English\" [formControl]=\"addServicesForm.controls['serviceDes_eng']\" [(ngModel)]=\"addServicesModel.description_eng\" ></textarea>\r\n\t\t\t\t\t\t                                         <p  *ngIf=\"addServicesForm.controls['serviceDes_eng'].hasError('required') && addServicesForm.controls['serviceDes_eng'].touched\">\r\n\t\t\t\t\t                                                     Service Description In English  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceDes_eng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceDes_eng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 500\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>\r\n\t\t\t\t\t\t                                        \tService Description In Arabic<small class=\"manidatory\">*</small>\r\n\t\t\t\t\t\t                                        </label>\r\n\t\t\t\t\t\t                                        <textarea class=\"cus-textarea form-control\" col=\"8\" rows=\"10\" placeholder=\"Service Description In Arabic\" [formControl]=\"addServicesForm.controls['serviceDes_arb']\" [(ngModel)]=\"addServicesModel.description_arb\" ></textarea>\r\n\t\t\t\t\t\t                                         <p  *ngIf=\"addServicesForm.controls['serviceDes_arb'].hasError('required') && addServicesForm.controls['serviceDes_arb'].touched\">\r\n\t\t\t\t\t                                                     Service Description In Arabic  is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceDes_arb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addServicesForm.controls['serviceDes_arb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 500\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"modal-footerbtn\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t<span class=\"save-bt\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t\t<button class=\"btn cut-btn\" data-dismiss=\"modal\" [disabled]=\"!addServicesForm.valid\" (click)=\"onUpdate()\">update</button>\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t</span>\r\n\t\t\t\t\t\t\t\t\t\t\t          \t</div>\r\n\t\t\t\t\t\t\t            \t\t\t</div>\r\n\t\t\t\t\t\t\t\t            \t</form>\r\n\t\t\t            </div>\r\n\t\t\t        </div>\r\n\t\t\t    </div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\r\n\t\t<!-- ========== view employe list details-->\r\n\t\t<div class=\"modal fade custom-modal\" id=\"view-service\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n\t\t\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t\t\t    <div class=\"modal-content\">\r\n\t\t\t        <div class=\"modal-header\">\r\n\t\t\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t            \t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t            </button>\r\n\t\t\t            <h4 class=\"modal-title\" id=\"myModalLabel\">Service Details</h4>\r\n\t\t\t        </div>\r\n\t\t\t        <div class=\"modal-body\">\r\n\t\t\t            <div class=\"view-emp-detail\">\r\n\t\t\t            \t<form class=\"img-responsive\">\r\n\t\t            \t\t\t<div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t\t            \t\t\t\t<!-- <div class=\"col-md-12 col-sm-12 col-xs-12 text-center\">\r\n\t\t            \t\t\t\t\t<div class=\"emp-viewimg\">\r\n\t\t            \t\t\t\t\t\t <img *ngIf=\"!addEmployee.employee_image || addEmployee.employee_image==null\" src=\"assets/img/user-pro-1.jpg\"  class=\"img-responsive\" alt=\"NO-IMAGES\">\r\n\t\t\t\t\t\t\t\t             <img  class=\"img-responsive\" *ngIf=\"addEmployee.employee_image\" [src]=\"imagePath(addEmployee.employee_image)\" >\r\n\t\t            \t\t\t\t\t</div>\r\n\t\t            \t\t\t\t</div> -->\r\n                                    <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                    \t<div class=\"employe-details\">\r\n\t                                    \t<div class=\"info-list service-details\">\r\n\r\n\r\n\r\n\r\n\r\n\r\n\t\t\t\t                          \t\t<dl class=\"dl-horizontal\" *ngIf=\"categoryList && serviceList\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Service Name In English:</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{getServicweNameEng(addServicesModel.service_id)}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Service Name In Arabic:</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{getServicweNameArb(addServicesModel.service_id)}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Category:</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd *ngIf=\"addServicesModel.category_id\"><!-- {{addServicesModel.category}} -->\r\n\t\t\t\t\t\t\t\t\t\t\t\t  \t<span >{{getCategoryName(addServicesModel.category_id)}}, </span>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  </dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Time:</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{getTime(addServicesModel.time)}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Service Cost In English:</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addServicesModel.cost_eng}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Service Cost In Arabic:</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addServicesModel.cost_arb}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Service Description In English:</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addServicesModel.description_eng}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Service Description In Arabic:</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addServicesModel.description_arb}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</dl>\r\n\t\t\t\t                          \t</div>\r\n\t                                    </div>\r\n                                    </div>\r\n\t\t            \t\t\t</div>\r\n\t\t\t\t\t          \t<div class=\"modal-footerbtn\">\r\n\t\t\t\t\t\t          \t<div class=\"col-md-12 col-sm-12 col-xs-12 text-center\">\r\n\t\t\t\t\t\t\t          \t\t<button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\" aria-label=\"Close\"> OK\r\n\t\t\t\t\t\t\t          \t\t</button>\r\n\t\t\t\t\t\t          \t</div>\r\n\t\t\t\t\t          \t</div>\r\n\t\t\t            \t</form>\r\n\t\t\t            </div>\r\n\t\t\t        </div>\r\n\t\t\t    </div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"modal fade custom-modal\" id=\"conformation-modal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n\t\t\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t\t\t    <div class=\"modal-content\">\r\n\t\t\t        <div class=\"modal-body\">\r\n\t\t\t            <div class=\"view-emp-detail\">\r\n\t\t\t            \t<div class=\"confirm-info\">\r\n\t\t\t            \t\t<h4>Are you sure you want to delete this service ?</h4>\r\n\t\t\t            \t\t<div class=\"btn-conformation\">\r\n\t\t\t            \t\t\t<span class=\"yes-confirm\">\r\n\t\t\t            \t\t\t\t<button type=\"button\" data-dismiss=\"modal\" class=\"cut-btn btn\" (click)=\"onYes()\">Yes</button>\r\n\t\t\t            \t\t\t</span>\r\n\t\t\t            \t\t\t<span class=\"confirm-no2\">\r\n\t\t\t            \t\t\t\t<button type=\"button\" data-dismiss=\"modal\" class=\"cut-btn btn\">No</button>\r\n\t\t\t            \t\t\t</span>\r\n\t\t\t            \t\t</div>\r\n\t\t\t            \t</div>\r\n\t\t\t            </div>\r\n\t\t\t        </div>\r\n\t\t\t    </div>\r\n\t\t\t</div>\r\n\t\t</div>"

/***/ }),

/***/ "../../../../../src/app/header-three-layout/service-list/service-list.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".service-details dt {\n  width: 250px; }\n\n.yes-confirm {\n  margin-right: 20px; }\n\n.btn-conformation {\n  margin-top: 50px; }\n\n.confirm-info h4 {\n  font-size: 18px;\n  margin: 10px 0; }\n\n.confirm-info {\n  float: left;\n  width: 100%;\n  padding: 50px 0 60px 0px;\n  text-align: center; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-three-layout/service-list/service-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ServiceListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__models_services__ = __webpack_require__("../../../../../src/app/models/services.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_rxjs_observable_forkJoin__ = __webpack_require__("../../../../rxjs/_esm5/observable/forkJoin.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var ServiceListComponent = (function () {
    function ServiceListComponent(router, fb, vcr, toastr, translate, saloonServices, commonServices) {
        this.router = router;
        this.fb = fb;
        this.toastr = toastr;
        this.translate = translate;
        this.saloonServices = saloonServices;
        this.commonServices = commonServices;
        this.addServicesModel = new __WEBPACK_IMPORTED_MODULE_7__models_services__["a" /* AddServices */]();
        this.userDetail = JSON.parse(localStorage['userdetails']);
        this.categoryList = [];
        this.toastr.setRootViewContainerRef(vcr);
        this.addServicesForm = fb.group({
            'category': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'time': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'serviceName_eng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            //'serviceName_arb': [null, Validators.compose([Validators.required,Validators.maxLength(100)])],
            'serviceCost_eng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'serviceCost_arb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'serviceDes_eng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(500)])],
            'serviceDes_arb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(500)])],
        });
    }
    ServiceListComponent.prototype.ngOnInit = function () {
        //this.appProvider.current.waitLoader=true
        this.getDetails();
        this.getCategory();
        this.myOptions = [
            { id: 1, name: 'Option 1' },
            { id: 2, name: 'Option 2' },
            { id: 3, name: 'Option 3' },
            { id: 4, name: 'Option 4' },
            { id: 5, name: 'Option 5' },
            { id: 6, name: 'Option 6' },
        ];
    };
    ServiceListComponent.prototype.getDetails = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonServices.getservicesById(this.userDetail.id)
            .subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response) {
                _this.toastr.success('All service list fetched successfully', 'Success', { toastLife: 1000, showCloseButton: true });
                _this.saloonServiceList = data.data;
                // this.router.navigate(['/header-three-layout/saloon-employee-list']);
            }
            else if (data.message == 'Employee not find') {
                _this.toastr.error('Employee not find', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Employee Registration Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    ServiceListComponent.prototype.getCategory = function () {
        var _this = this;
        this.waitLoader = true;
        Object(__WEBPACK_IMPORTED_MODULE_8_rxjs_observable_forkJoin__["a" /* forkJoin */])([this.commonServices.getCategory(), this.commonServices.getServices()])
            .subscribe(function (results) {
            var list = [];
            _this.waitLoader = false;
            console.log(results);
            if (results) {
                _this.categoryList = results[0].data;
                _this.serviceList = results[1].data;
                for (var i = 0; i < _this.categoryList.length; ++i) {
                    list.push({ id: _this.categoryList[i].id, name: _this.categoryList[i].category_eng });
                }
                _this.myOptions = list;
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    ServiceListComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.216.88.154/public/beauti-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    ServiceListComponent.prototype.onEdit = function (data) {
        // this.optionsModel=[]
        //     let b=data.category.split(',')
        //        //console.log('services',data.services)map(function (img) { return img.title; })
        //          for (var i = 0; i < b.length; ++i) {
        //                 if (+b[i]!=NaN) {
        //                   if (this.categoryList.map(function (img){return img.id}).indexOf(+b[i])!=-1) {
        //                      this.optionsModel.push(+b[i])
        //                     // code...
        //                   }
        //                     // code...
        //                 }
        //              // code...
        //          }
        this.addServicesModel = Object.assign({}, data);
        console.log(this.addServicesModel);
        // let a=Object.create(data);
    };
    ServiceListComponent.prototype.onview = function (data) {
        this.addServicesModel = data;
    };
    ServiceListComponent.prototype.ondelete = function (data) {
        this.addServicesModel = data;
    };
    ServiceListComponent.prototype.onChange = function () {
        console.log(this.optionsModel);
    };
    ServiceListComponent.prototype.onUpdate = function () {
        var _this = this;
        // console.log(this.addServicesModel)
        // this.addServicesModel=Object.assign(this.addServicesModel);
        this.waitLoader = true;
        delete (this.addServicesModel.created_at);
        delete (this.addServicesModel.updated_at);
        delete (this.addServicesModel.status);
        //let a=this.optionsModel.slice(0)
        // this.addServicesModel.category=a.toString()
        this.saloonServices.updateservices(this.addServicesModel)
            .subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response) {
                _this.getDetails();
                _this.waitLoader = false;
                _this.toastr.success('Employee details updated successfully', 'Success', { toastLife: 1000, showCloseButton: true });
                /// this.employeeList=data.data
                // this.router.navigate(['/header-three-layout/saloon-employee-list']);
            }
            else if (data.message == 'Employee not find') {
                _this.toastr.error('Employee not find', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Employee Registration Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    ServiceListComponent.prototype.onYes = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonServices.deleteservicesById(this.addServicesModel.id)
            .subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response) {
                _this.getDetails();
                _this.toastr.success('Employee deleted successfully', 'Success', { toastLife: 1000, showCloseButton: true });
                //this.employeeList=data.data
                // this.router.navigate(['/header-three-layout/saloon-employee-list']);
            }
            else if (data.message == 'Employee not find') {
                _this.toastr.error('Employee not find', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Employee Registration Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    ServiceListComponent.prototype.getCategoryName = function (a) {
        var data = this.categoryList.filter(function (arg) { return arg.id == a; });
        if (data.length > 0) {
            return data[0].category_eng;
        }
    };
    ServiceListComponent.prototype.getServiceName = function (ser_id) {
        var data = this.serviceList.filter(function (arg) { return arg.id == ser_id; });
        if (data.length > 0) {
            return data[0].services_eng;
            // code...
        }
    };
    ServiceListComponent.prototype.getServiceOption = function () {
        var _this = this;
        if (this.addServicesModel.category_id) {
            // code...
            var data = this.serviceList.filter(function (arg) { return arg.category_id == _this.addServicesModel.category_id; });
            return data;
        }
        else {
            return [];
        }
    };
    ServiceListComponent.prototype.getServicweNameEng = function (ser_id) {
        var data = this.serviceList.filter(function (arg) { return arg.id == ser_id; });
        if (data.length > 0) {
            return data[0].services_eng;
            // code...
        }
    };
    ServiceListComponent.prototype.getServicweNameArb = function (ser_id) {
        var data = this.serviceList.filter(function (arg) { return arg.id == ser_id; });
        if (data.length > 0) {
            return data[0].services_arb;
            // code...
        }
    };
    ServiceListComponent.prototype.getTime = function (time) {
        var a;
        switch (time) {
            case "15":
                a = '15 Min';
                //alert(a)
                return a;
            case "30":
                a = '30 Min';
                return a;
            case "45":
                a = '45 Min';
                return a;
            case "60":
                a = '1 Hr';
                return a;
            case "75":
                a = '1 Hr 15 Min';
                return a;
            case "90":
                a = '1 Hr 30 Min';
                return a;
            case "105":
                a = '1 Hr 45 Min';
                return a;
            case "120":
                a = '2 Hr';
                return a;
            case "135":
                a = '2 Hr 15 Mi';
                return a;
            case "150":
                a = '2 Hr 30 Min';
                return a;
            case "165":
                a = '2 Hr 45 Min';
                return a;
            case "180":
                a = '3 Hr';
                return a;
            default:
                0;
                // alert(a)
                return a;
        }
    };
    ServiceListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-service-list',
            template: __webpack_require__("../../../../../src/app/header-three-layout/service-list/service-list.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-three-layout/service-list/service-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["a" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__["c" /* TranslateService */],
            __WEBPACK_IMPORTED_MODULE_5__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_6__providers_common_service__["a" /* CommonService */]])
    ], ServiceListComponent);
    return ServiceListComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/service-list/service-list.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiceListModule", function() { return ServiceListModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_angular_2_dropdown_multiselect__ = __webpack_require__("../../../../angular-2-dropdown-multiselect/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__service_list_routing_module__ = __webpack_require__("../../../../../src/app/header-three-layout/service-list/service-list-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__service_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/service-list/service-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var ServiceListModule = (function () {
    function ServiceListModule() {
    }
    ServiceListModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_8__service_list_routing_module__["a" /* ServiceListRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["c" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["h" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_5_angular_2_dropdown_multiselect__["a" /* MultiselectDropdownModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_common_http__["b" /* HttpClientModule */],
                __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__["b" /* TranslateModule */],
                __WEBPACK_IMPORTED_MODULE_7_ngx_pagination__["a" /* NgxPaginationModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_9__service_list_component__["a" /* ServiceListComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_10__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_11__providers_common_service__["a" /* CommonService */]]
        })
    ], ServiceListModule);
    return ServiceListModule;
}());



/***/ })

});
//# sourceMappingURL=service-list.module.chunk.js.map