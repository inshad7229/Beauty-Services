webpackJsonp(["customer-profile.module"],{

/***/ "../../../../../src/app/header-four-layout/customer-profile/customer-profile-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerProfileRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__customer_profile_component__ = __webpack_require__("../../../../../src/app/header-four-layout/customer-profile/customer-profile.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__customer_profile_component__["a" /* CustomerProfileComponent */]
    }
];
var CustomerProfileRoutingModule = (function () {
    function CustomerProfileRoutingModule() {
    }
    CustomerProfileRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], CustomerProfileRoutingModule);
    return CustomerProfileRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-four-layout/customer-profile/customer-profile.component.html":
/***/ (function(module, exports) {

module.exports = "      <div class=\"page-content-wrapper\">\r\n        <div class=\"page-content\">\r\n          <ul class=\"page-breadcrumb breadcrumb hide\">\r\n            <li>\r\n              <a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n            </li>\r\n            <li class=\"active\">\r\n               Dashboard\r\n            </li>\r\n          </ul>\r\n          <!-- BEGIN PAGE CONTENT INNER -->\r\n          <div class=\"emp-list-sec\">\r\n            <div class=\"col-md-12 col-sm-12 p-0\">\r\n              <!-- BEGIN PORTLET-->\r\n              <div class=\"booking-section\"><!-- like that wrap class -->\r\n                <div class=\"portlet light\">\r\n                  <div class=\"portlet-title\">\r\n                    <div class=\"caption caption-md\">\r\n                      <i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n                      <span class=\"caption-subject theme-font-color bold uppercase\">Customer Profile</span>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"portlet-body services-list\">\r\n                    <div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                      <div class=\"otr-bg-dshbrd\">\r\n                                  <h4 class=\"title-form-head\" >Personal Details <a class=\"edit-btn\" href=\"javascript:;\" (click)=\"onClickDetailsEdit()\">\r\n                                  <span id=\"show1\" class=\"fa fa-pencil-square-o\" ></span>\r\n                                  </a></h4>\r\n                                 <form class=\"profile-form customer-profil\">\r\n                                    <div class=\"first-secwrap\">\r\n                                      <div id=\"row1\">\r\n                                        <div class=\"col-md-9 col-sm-9 col-xs-12 \">\r\n                                              <div class=\"info-list\">\r\n                                                <dl class=\"dl-horizontal\">\r\n                                    <dt>Name</dt>\r\n                                    <dd>{{userDetail.first_name}} {{userDetail.last_name}}</dd>\r\n                                    <dt>Email</dt>\r\n                                    <dd>{{userDetail.email}}</dd>\r\n                                    <dt>Contact Number</dt>\r\n                                    <dd>{{userDetail.contact_number}}</dd>\r\n                                    <dt>City</dt>\r\n                                    <dd>{{userDetail.city}}</dd>\r\n                                  </dl>\r\n                                              </div>\r\n                                        </div>\r\n                                          <div class=\"col-md-3 col-sm-3 col-xs-12\">\r\n                                            <div class=\"wrap-div outer-img\">\r\n                                                 <img *ngIf=\"!userDetail.image\" src=\"assets/img/saloon-user.png\" class=\"img-responsive\">\r\n                                                <img *ngIf=\"userDetail.image\" src=\"http://18.216.88.154/public/beauti-service/{{userDetail.image}}\" class=\"img-responsive\">\r\n                                            </div>\r\n                                          </div>\r\n                                      </div>\r\n                                      <div id=\"row2\">\r\n                                        <div class=\"col-md-9 col-md-9 col-xs-12\">\r\n                                          <div class=\"row\">\r\n                                                        <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                            <label>Enter First Name</label>\r\n                                                            <input type=\"text\" placeholder=\"Enter First Name\" class=\"form-control\" [formControl]=\"customerSignupForm.controls['first_name']\" [(ngModel)]=\"userDetail.first_name\">\r\n                                                           <p  *ngIf=\"customerSignupForm.controls['first_name'].hasError('required') && customerSignupForm.controls['first_name'].touched\">\r\n                                                                First Name is <strong>required</strong>\r\n                                                          </p>\r\n                                                          <p  *ngIf=\"customerSignupForm.controls['first_name'].hasError('pattern')\">\r\n                                                                     only alphabets are acceptable \r\n                                                          </p>\r\n                                                          <p  *ngIf=\"customerSignupForm.controls['first_name'].hasError('maxlength')\">\r\n                                                                     max length is 100\r\n                                                          </p> \r\n                                                        </div>\r\n                                                        <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                            <label>Enter Last Name</label>\r\n                                                            <input type=\"text\" placeholder=\"Enter Last Name\" class=\"form-control\" [formControl]=\"customerSignupForm.controls['last_name']\" [(ngModel)]=\"userDetail.last_name\">\r\n                                                           <p  *ngIf=\"customerSignupForm.controls['last_name'].hasError('required') && customerSignupForm.controls['last_name'].touched\">\r\n                                                                 Last Name is <strong>required</strong>\r\n                                                          </p>\r\n                                                          <p  *ngIf=\"customerSignupForm.controls['last_name'].hasError('pattern')\">\r\n                                                                     only alphabets are acceptable \r\n                                                          </p>\r\n                                                          <p  *ngIf=\"customerSignupForm.controls['last_name'].hasError('maxlength')\">\r\n                                                                     max length is 100\r\n                                                          </p>\r\n                                                        </div>\r\n                                                    </div>\r\n                                                    <div class=\"row\">\r\n                                                        <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                            <label>Enter Email</label>\r\n                                                            <input type=\"text\" placeholder=\"Enter Email\" class=\"form-control\"  [formControl]=\"customerSignupForm.controls['email']\" [(ngModel)]=\"userDetail.email\">\r\n                                                             <p  *ngIf=\"customerSignupForm.controls['email'].hasError('required') && customerSignupForm.controls['email'].touched\">\r\n                                                                   Email is <strong>required</strong>\r\n                                                            </p>\r\n                                                            <p  *ngIf=\"customerSignupForm.controls['email'].hasError('pattern')\">\r\n                                                                       Enter valid email id\r\n                                                            </p>\r\n                                                            <p  *ngIf=\"customerSignupForm.controls['email'].hasError('maxlength')\">\r\n                                                                       max length is 100\r\n                                                            </p>\r\n                                                        </div>\r\n                                                        <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                            <label>Enter Contact Number</label>\r\n                                                            <input type=\"text\" placeholder=\"Enter Contact Number\" class=\"form-control\"  [formControl]=\"customerSignupForm.controls['contact_number']\" [(ngModel)]=\"userDetail.contact_number\">\r\n                                                            <p  *ngIf=\"customerSignupForm.controls['contact_number'].hasError('required') && customerSignupForm.controls['contact_number'].touched\">\r\n                                                                   Contact Number is <strong>required</strong>\r\n                                                            </p>\r\n                                                            <p  *ngIf=\"customerSignupForm.controls['contact_number'].hasError('pattern')\">\r\n                                                                       Enter valid Contact Number (Only Digit) id\r\n                                                            </p>\r\n                                                            <p  *ngIf=\"customerSignupForm.controls['contact_number'].hasError('maxlength')\">\r\n                                                           max length is 12\r\n                                                           </p>\r\n                                                        </div>\r\n                                                    </div>\r\n                                                    <div class=\"row\">\r\n                                                        <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                            <label>Enter Your City</label>\r\n                                                            <input type=\"text\" placeholder=\"Enter Your City\" class=\"form-control\" [formControl]=\"customerSignupForm.controls['city']\" [(ngModel)]=\"userDetail.city\">\r\n                                                                 <p  *ngIf=\"customerSignupForm.controls['city'].hasError('required') && customerSignupForm.controls['city'].touched\">\r\n                                                               City is <strong>required</strong>\r\n                                                             </p>\r\n                                                            <p  *ngIf=\"customerSignupForm.controls['city'].hasError('pattern')\">\r\n                                                                       Enter valid Contact Number (Only Digit) id\r\n                                                            </p>\r\n                                                            <p  *ngIf=\"customerSignupForm.controls['city'].hasError('maxlength')\">\r\n                                                                       max length is 12\r\n                                                            </p>\r\n                                                        </div>\r\n                                                    </div>                                   \r\n                                            <div class=\"row\">\r\n                                                <ul class=\"update-form-ul\">\r\n                                                  <li>\r\n                                                    <button [disabled]=\"!customerSignupForm.valid\" id=\"update1\" type=\"button\" class=\"btn cut-btn\" (click)=\"onCustomerUpdate()\">Update</button>\r\n                                                  </li>\r\n                                                  <li>\r\n                                                    <a href=\"javascript:void(0);\" class=\"btn cut-btn\" (click)=\"onCancelDetailshow()\">Cancel</a>\r\n                                                  </li>\r\n                                                </ul>\r\n                                            </div>\r\n                                        </div>\r\n                                          <div class=\"col-md-3 col-sm-3 col-xs-12\">\r\n                                            <div class=\"wrap-div outer-img\">\r\n                                                <img *ngIf=\"!userDetail.image \" src=\"assets/img/saloon-user.png\" class=\"img-responsive\">\r\n                                                <img *ngIf=\"userDetail.image\" [src]=\"imagePath(userDetail.image)\" class=\"img-responsive\">\r\n                                                <span class=\"upload-img\">\r\n                                                <button class=\"btn cut-btn\" type=\"submit\">Change Profile</button>\r\n                                                <input class=\"profile-btn cut-btn\" name=\"image\" type=\"file\" (change)=\"imageUploadEvent($event)\" accept=\"image/gif, image/jpeg, image/png\" />\r\n                                              </span>\r\n                                            </div>\r\n                                        </div>\r\n                                     </div>\r\n                                    </div>\r\n                                   <h4 class=\"title-form-head\" id=\"change\">Change password<a class=\"edit-btn\" href=\"javascript:;\"  (click)=\"onClickPasswordEdit()\">\r\n                                    <span class=\"fa fa-pencil-square-o\" id=\"show3\"></span>\r\n                                    </a></h4>\r\n                                  <div id=\"row5\">\r\n                                        <div class=\"col-md-9\">\r\n                                           <span class=\"edited-value\">Click on edit icon to change your password.</span>\r\n                                        </div>\r\n                                  </div>\r\n                                    <div id=\"row6\">\r\n                                      <div class=\"col-md-9 col-sm-9 col-xs-12\">\r\n                                          <div class=\"row\">\r\n                                              <div class=\"form-group col-sm-9 col-md-9 col-xs-12\">\r\n                                                <label>Current Password</label>\r\n                                                  <input type=\"password\" placeholder=\"Current password\" class=\"form-control\" [formControl]=\"passwordForm.controls['currentPassword']\" [(ngModel)]=\"passwordModel.currentPassword\">\r\n                                                    <p  *ngIf=\"passwordForm.controls['currentPassword'].hasError('required') && passwordForm.controls['currentPassword'].touched\">\r\n                                                     Current password is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"passwordForm.controls['currentPassword'].hasError('pattern')\">\r\n                                                               only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"passwordForm.controls['currentPassword'].hasError('maxlength')\">\r\n                                                               max length is 12\r\n                                                    </p>\r\n                                                    <!-- <p  *ngIf=\"message\">\r\n                                                               Password and confirm password must be same !!\r\n                                                    </p> -->\r\n                                              </div>\r\n                                          </div>\r\n                                          <div class=\"row\">\r\n                                              <div class=\"form-group col-sm-9 col-md-9 col-xs-12\">\r\n                                                  <label>New Password</label>\r\n                                                    <input type=\"password\" placeholder=\"New password\" class=\"form-control\" [formControl]=\"passwordForm.controls['newPassword']\" [(ngModel)]=\"passwordModel.newPassword\" (input)=\"pass_confirm()\">\r\n                                                      <p  *ngIf=\"passwordForm.controls['newPassword'].hasError('required') && passwordForm.controls['newPassword'].touched\">\r\n                                                               New Password is <strong>required</strong>\r\n                                                    </p>\r\n                                                    <p  *ngIf=\"passwordForm.controls['newPassword'].hasError('pattern')\">\r\n                                                               only alphabets are acceptable \r\n                                                    </p>\r\n                                                    <p  *ngIf=\"passwordForm.controls['newPassword'].hasError('maxlength')\">\r\n                                                               max length is 12\r\n                                                    </p>                         \r\n                                          </div>\r\n                                          </div>\r\n                                          <div class=\"row\">\r\n                                              <div class=\"form-group col-sm-9 col-md-9 col-xs-12\">\r\n                                                  <label>Confirm Password</label>\r\n                                                    <input type=\"password\" placeholder=\"Confirm password\" class=\"form-control\"  [formControl]=\"passwordForm.controls['confirmPassword']\" [(ngModel)]=\"passwordModel.confirmPassword\" (input)=\"confirm()\"> \r\n                                                     <p  *ngIf=\"passwordForm.controls['confirmPassword'].hasError('required') && passwordForm.controls['confirmPassword'].touched\">\r\n                                                               Confirm Password is <strong>required</strong>\r\n                                                      </p>\r\n                                                      <p  *ngIf=\"passwordForm.controls['confirmPassword'].hasError('pattern')\">\r\n                                                                 only alphabets are acceptable \r\n                                                      </p>\r\n                                                      <p  *ngIf=\"passwordForm.controls['confirmPassword'].hasError('maxlength')\">\r\n                                                                 max length is 12\r\n                                                      </p>\r\n                                                      <p  *ngIf=\"message\">\r\n                                                                 New Password and confirm password must be same !!\r\n                                                      </p>                               \r\n                                              </div>\r\n                                          </div>\r\n                                          <div class=\"row\">\r\n                                            <div class=\"form-group col-sm-9 col-md-9 col-xs-12\">\r\n                                                <ul class=\"update-form-ul\">\r\n                                                  <li>\r\n                                                    <button type=\"button\" class=\"btn cut-btn\" [disabled]=\"!passwordForm.valid || message\" (click)=\"onUpdatePass()\">Update</button>\r\n                                                  </li>\r\n                                                  <li>\r\n                                                    <a href=\"javascript:void(0);\" class=\"btn cut-btn\" (click)=\"onCancelPasswordshow()\">Cancel</a>\r\n                                                  </li>\r\n                                                </ul>\r\n                                              </div>\r\n                                          </div>\r\n                                      </div>\r\n                                  </div>\r\n                                 </form>\r\n                            </div> \r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <!-- END PORTLET-->\r\n            </div>\r\n          </div>\r\n          <!-- END PAGE CONTENT INNER -->\r\n        </div>\r\n      </div>"

/***/ }),

/***/ "../../../../../src/app/header-four-layout/customer-profile/customer-profile.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".btn.cus-btn {\n  background-color: #d5275a;\n  border-radius: unset;\n  color: #fff;\n  margin-right: 11px;\n  min-width: 130px; }\n\n.month-name h3 {\n  color: #d5275a; }\n\n.week-sec .cal-month-view .cal-day-cell {\n  min-height: 70px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-four-layout/customer-profile/customer-profile.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerProfileComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_customer_service__ = __webpack_require__("../../../../../src/app/providers/customer.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var CustomerProfileComponent = (function () {
    function CustomerProfileComponent(router, fb, vcr, toastr, customerService) {
        this.router = router;
        this.fb = fb;
        this.toastr = toastr;
        this.customerService = customerService;
        this.userDetail = JSON.parse(localStorage['customerdetails']);
        this.editOne = false;
        this.editOne2 = false;
        this.passwordModel = {};
        this.tempImag = this.userDetail.image;
        this.toastr.setRootViewContainerRef(vcr);
        this.customerSignupForm = fb.group({
            'first_name': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'last_name': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'email': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].pattern(EMAIL_REGEX)])],
            'contact_number': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(12), __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].pattern('[0-9]*')])],
            'city': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(30)])]
        });
        this.passwordForm = fb.group({
            'currentPassword': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(12)])],
            'newPassword': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(12)])],
            'confirmPassword': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(12)])],
        });
        this.customerSignupForm.controls['email'].disable();
    }
    CustomerProfileComponent.prototype.ngOnInit = function () {
        $("#row2").hide();
        $("#row6").hide();
        //   	 $(document).ready(function() {
        //            $('.multiselect').multiselect();
        // 	        });
        // $("#row2").hide();
        // 		  	$(document).ready(function(){
        // 			    $("#show1").click(function(){
        // 			        $("#row1").hide(600);
        // 			        $("#row2").show(600);
        // 			    });
        // 			});
        //  $("#row6").hide();
        // 		  $(document).ready(function(){
        // 		    $("#show3").click(function(){
        // 		        $("#row5").hide(500);
        // 		        $("#row6").show(500);
        // 		    });
        // 		  });
        Metronic.init(); // init metronic core componets
        Layout.init(); // init layout
        Demo.init(); // init demo features 
        /*Index.init(); // init index page*/
        Tasks.initDashboardWidget(); // init tash dashboard widget  
    };
    CustomerProfileComponent.prototype.onClickDetailsEdit = function () {
        if (this.editOne == false) {
            $("#row1").hide(600);
            $("#row2").show(600);
            this.editOne = true;
        }
        else {
            this.editOne = false;
            $("#row1").show(600);
            $("#row2").hide(600);
        }
    };
    CustomerProfileComponent.prototype.onClickPasswordEdit = function () {
        if (this.editOne2 == false) {
            $("#row5").hide(500);
            $("#row6").show(500);
            this.editOne2 = true;
        }
        else {
            this.editOne2 = false;
            $("#row5").show(500);
            $("#row6").hide(500);
        }
    };
    CustomerProfileComponent.prototype.onCancelDetailshow = function () {
        this.editOne = false;
        this.userDetail.image = this.tempImag;
        $("#row1").show(600);
        $("#row2").hide(600);
    };
    CustomerProfileComponent.prototype.onCancelPasswordshow = function () {
        this.editOne2 = false;
        $("#row5").show(500);
        $("#row6").hide(500);
    };
    CustomerProfileComponent.prototype.confirm = function () {
        if (this.passwordModel.newPassword == this.passwordModel.confirmPassword) {
            this.message = false;
        }
        else {
            this.message = true;
        }
    };
    CustomerProfileComponent.prototype.pass_confirm = function () {
        if (this.passwordModel.confirmPassword) {
            // code...
            if (this.passwordModel.newPassword == this.passwordModel.confirmPassword) {
                this.message = false;
            }
            else {
                this.message = true;
            }
        }
    };
    CustomerProfileComponent.prototype.onCustomerUpdate = function () {
        var _this = this;
        this.userDetail.customerId = this.userDetail.id;
        delete (this.userDetail.password);
        delete (this.userDetail.updated_at);
        delete (this.userDetail.created_at);
        delete (this.userDetail.status);
        this.customerService.CustomerProfileUpdate(this.userDetail)
            .subscribe(function (data) {
            console.log(data);
            if (data.response) {
                _this.toastr.success(data.message, 'customer', { toastLife: 3000, showCloseButton: true });
                _this.editOne = false;
                $("#row1").show(600);
                $("#row2").hide(600);
                localStorage['customerdetails'] = JSON.stringify(data.data);
                _this.userDetail = JSON.parse(localStorage['customerdetails']);
                _this.tempImag = _this.userDetail.image;
                // setTimeout(()=>{
                // this.router.navigate(['/header-two-layout/login']);
                // },3000)
                //    alert(data.message)
            }
            else if (data.message == 'Unable to update customer') {
                _this.toastr.error('Unable to update customer', 'Updation Failed ', { toastLife: 3000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Updation Failed ', { toastLife: 3000, showCloseButton: true });
            }
        });
    };
    CustomerProfileComponent.prototype.onUpdatePass = function () {
        var _this = this;
        this.passwordModel.customerId = this.userDetail.id;
        this.customerService.CustomerPasswordUpdate(this.passwordModel)
            .subscribe(function (data) {
            console.log(data);
            if (data.response) {
                _this.toastr.success(data.message, 'Password Update', { toastLife: 1000, showCloseButton: true });
                _this.editOne2 = false;
                $("#row5").show(500);
                $("#row6").hide(500);
            }
            else if (data.message == 'Unable to update Password') {
                _this.toastr.error('Unable to update Password', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else if (data.message == 'current password is incorrect') {
                _this.toastr.error('current password is incorrect', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    CustomerProfileComponent.prototype.imageUploadEvent = function (evt) {
        var _this = this;
        if (!evt.target) {
            return;
        }
        if (!evt.target.files) {
            return;
        }
        if (evt.target.files.length !== 1) {
            return;
        }
        var file = evt.target.files[0];
        if (file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif' && file.type !== 'image/jpg') {
            return;
        }
        var fr = new FileReader();
        fr.onloadend = function (loadEvent) {
            _this.userDetail.image = fr.result;
            console.log(_this.userDetail.image);
        };
        fr.readAsDataURL(file);
    };
    CustomerProfileComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.216.88.154/public/beauti-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    CustomerProfileComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-customer-profile',
            template: __webpack_require__("../../../../../src/app/header-four-layout/customer-profile/customer-profile.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-four-layout/customer-profile/customer-profile.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["a" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_4__providers_customer_service__["a" /* CustomerService */]])
    ], CustomerProfileComponent);
    return CustomerProfileComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-four-layout/customer-profile/customer-profile.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerProfileModule", function() { return CustomerProfileModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_material_select__ = __webpack_require__("../../../material/esm5/select.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__customer_profile_routing_module__ = __webpack_require__("../../../../../src/app/header-four-layout/customer-profile/customer-profile-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__customer_profile_component__ = __webpack_require__("../../../../../src/app/header-four-layout/customer-profile/customer-profile.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__providers_customer_service__ = __webpack_require__("../../../../../src/app/providers/customer.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var CustomerProfileModule = (function () {
    function CustomerProfileModule() {
    }
    CustomerProfileModule.prototype.ngOnInit = function () {
    };
    CustomerProfileModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_6__customer_profile_routing_module__["a" /* CustomerProfileRoutingModule */], __WEBPACK_IMPORTED_MODULE_2__angular_forms__["c" /* FormsModule */], __WEBPACK_IMPORTED_MODULE_2__angular_forms__["h" /* ReactiveFormsModule */], __WEBPACK_IMPORTED_MODULE_3__angular_material_select__["a" /* MatSelectModule */], __WEBPACK_IMPORTED_MODULE_4__angular_common_http__["b" /* HttpClientModule */], __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__["ToastModule"].forRoot()],
            declarations: [__WEBPACK_IMPORTED_MODULE_7__customer_profile_component__["a" /* CustomerProfileComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_8__providers_customer_service__["a" /* CustomerService */]]
        })
    ], CustomerProfileModule);
    return CustomerProfileModule;
}());



/***/ })

});
//# sourceMappingURL=customer-profile.module.chunk.js.map