webpackJsonp(["payment-process.module"],{

/***/ "../../../../../src/app/payment-process/payment-process-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PaymentProcessRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__payment_process_component__ = __webpack_require__("../../../../../src/app/payment-process/payment-process.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__payment_process_component__["a" /* PaymentProcessComponent */]
    }
];
var PaymentProcessRoutingModule = (function () {
    function PaymentProcessRoutingModule() {
    }
    PaymentProcessRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], PaymentProcessRoutingModule);
    return PaymentProcessRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/payment-process/payment-process.component.html":
/***/ (function(module, exports) {

module.exports = " <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n         <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n </div>\r\n\r\n <section class=\"payment-process\">\r\n            <div class=\"payment-proces-header\">\r\n                <div class=\"payment-hcontent\">\r\n                    <a href=\"javascript:void(0);\"> \r\n                        <i class=\"fa fa-angle-left\"></i> Back\r\n                    </a>\r\n                    <span class=\"payment-logo\">\r\n                        <a href=\"javascript:void(0);\">\r\n                            <img src=\"assets/img/logo.png\" alt=\"beauty-logo\">\r\n                        </a>\r\n                    </span>\r\n                </div>\r\n            </div>\r\n            <div class=\"payment-processtab\">\r\n                <div class=\"container-fluid\">\r\n                    <div class=\"custom-row\">\r\n                        <div class=\"col-md-8 col-sm-8 col-xs-12 payment-1\">\r\n                            <div class=\"payment-sidediv\">\r\n                                <div class=\"saloon-wrap\">\r\n                                    <div class=\"tab-on-form payment-pro\">\r\n                                        <ul class=\"nav nav-pills nav-stacked\">\r\n                                            <li class=\"{{tab1}} step-li\" id=\"appoiment\">\r\n                                               <button href=\"#tab_a\" data-toggle=\"pill\" [disabled]=\"currentTab!='tab1'\">\r\n                                                   1\r\n                                               </button>\r\n                                               <p>Schedule appointment</p> \r\n                                            </li>\r\n                                            <li class=\"{{tab2}} step-li\" id=\"pay-book\">\r\n                                               <button href=\"#tab_b\" data-toggle=\"pill\" [disabled]=\"currentTab!='tab2'\">\r\n                                                  2\r\n                                               </button>\r\n                                               <p><i class=\"fa fa-credit-card\"></i>Pay And Book</p> \r\n                                            </li>\r\n                                            <li class=\"{{tab3}}\" id=\"confir-bok\">\r\n                                               <button href=\"#tab_c\" data-toggle=\"pill\" [disabled]=\"currentTab!='tab3'\">\r\n                                                  3\r\n                                               </button>\r\n                                               <p><i class=\"fa fa-check\"></i>Booking Confirmation</p> \r\n                                            </li>\r\n                                        </ul>\r\n                                    </div>\r\n                                    <div class=\"payment-content\">\r\n                                        <div class=\"tab-content\">\r\n                                            <div class=\"tab-pane {{tab1}}\" id=\"tab_a\">\r\n                                                <div class=\"schedule-sec\" *ngIf=\"saloonData\">\r\n                                                    <!-- <div class=\"any-professionl\">\r\n                                                        <span class=\"heading-profes\">\r\n                                                            <img src=\"assets/img/user-pay.svg\" alt=\"user-svg\">\r\n                                                            <p>Any Professional</p>\r\n                                                        </span>\r\n                                                        <span class=\"select-pro-type\">\r\n                                                            <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#professional-typ\">Select</a>\r\n                                                        </span>\r\n                                                    </div> -->\r\n                                                    <div class=\"service-listwrap\" *ngFor=\"let ser of selectedServices;let i=index\" >\r\n                                                            <a href=\"javascript:void(0)\" #ref (click)=\"openCategory(ref)\">\r\n                                                                <span class=\"right-icon\">\r\n                                                                    <i class=\"fa fa-angle-up\"></i>\r\n                                                                </span>\r\n                                                                <!-- {{cat.categoryData.category_eng}} ({{cat.categoryData.categoryServices.length}}) -->\r\n                                                                {{ser.services_eng}}\r\n                                                            </a>\r\n                                                            <div class=\"sub-menulist\" style=\"display: none\">\r\n                                                                <div class=\"list-content gray-line\" >\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <!-- <h4>{{ser.servicesData.services_eng}}</h4> -->\r\n                                                                        <!-- <small><a href=\"javascript:void(0)\">Show Details</a> <span>{{getTime(ser.time)}}</span></small> -->\r\n                                                                        <h4 class=\"select-categ\">{{ser.services_eng}}</h4><small class=\"timeslot\">{{getTime(ser.time)}}</small>\r\n                                                                        <div class=\"select-categ-under-div\">\r\n                                                                          <span class=\"heading-profes\">\r\n                                                                            <img *ngIf=\"ser.emp_id==null\" alt=\"user-svg\" src=\"assets/img/user-pay.svg\">\r\n                                                                            <img *ngIf=\"ser.emp_id!=null\" alt=\"user-svg\" [src]=\"getEmpImg(ser.emp_id)\">\r\n                                                                            <span class=\"empy-name\" *ngIf=\"ser.emp_id!=null\">{{getEmpName(ser.emp_id)}}</span>\r\n                                                                            <!-- <p>Select Any Professional</p> -->\r\n                                                                            <a *ngIf=\"ser.appointment_id ==null\" class=\"slect-pro\" href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#professional-typ\" (click)=\"onSelectEmployee(ser,i)\"><span *ngIf=\"ser.emp_id==null\">Select Any Professional</span> <span *ngIf=\"ser.emp_id!=null\" >Change  Professional</span></a>\r\n                                                                          </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl2\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED {{ser.cost_eng}}</h6></span>\r\n                                                                            <span class=\"add-cart-icon\" *ngIf=\"ser.appointment_id ==null\">\r\n                                                                                <a href=\"javascript:void(0)\" (click)=\"onselectService(ser,i)\">\r\n                                                                              \r\n                                                                                    <i  class=\"fa fa-minus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                        <div class=\"slkt-tim-div\" *ngIf=\"ser.appointment_id==null\">\r\n                                                                          <a *ngIf=\"ser.emp_id!=null && !ser.date && !ser.startTime1 &&  !ser.endTime1\" href=\"javascript:;\" data-toggle=\"modal\" data-target=\"#proceed-time\" (click)=\"onTimeSelect(ser)\">Select Time</a>\r\n                                                                          <a *ngIf=\"ser.emp_id!=null && ser.date && ser.startTime1 &&  ser.endTime1\" href=\"javascript:;\" (click)=\"onTimeSelect(ser)\">Change Time</a>\r\n                                                                          <a *ngIf=\"ser.emp_id!=null && ser.date && ser.startTime1 &&  ser.endTime1\" href=\"javascript:;\" (click)=\"onCoinfirmAppointment(ser)\">Confirm Appointment</a>\r\n                                                                        </div>\r\n                                                                        <div class=\"slkt-tim-div\" *ngIf=\"ser.appointment_id !=null\">\r\n                                                                          <a  href=\"javascript:;\"  (click)=\"onDelteAppontment(ser,i)\">Delete Appointment</a>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <div class=\"datetime-show\" *ngIf=\"ser.date && ser.startTime1 &&  ser.endTime1 \">\r\n                                                                    <ul >\r\n                                                                      <li>\r\n                                                                        <i class=\"fa fa-calendar\"></i>\r\n                                                                        {{ser.date}}\r\n                                                                      </li>\r\n                                                                      <li>\r\n                                                                        <i class=\"fa fa-clock-o\"></i>\r\n                                                                        {{getHours(ser.startTime1)}}:{{getMint(ser.startTime1)}} {{getAmPm(ser.startTime1)}} - {{getHours(ser.endTime1)}}:{{getMint(ser.endTime1)}} {{getAmPm(ser.endTime1)}}\r\n                                                                      </li>\r\n                                                                    </ul>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                   \r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"tab-pane {{tab2}}\" id=\"tab_b\">\r\n                                                <div class=\"appointment-sec\">\r\n                                                    <div class=\"dshbrd-content\">\r\n                                                        <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                            <ul class=\"cus-nav-tab nav nav-tabs m-tb-30\" role=\"tablist\">\r\n                                                                <li role=\"presentation\" class=\"active\">\r\n                                                                    <a href=\"#\" id=\"card-credit\" aria-controls=\"home\" role=\"tab\" data-toggle=\"tab\" (click)=\"onCard()\"> Credit Card </a>\r\n                                                                </li>\r\n                                                                <li role=\"presentation\">\r\n                                                                    <a href=\"#\" id=\"cashlink\" aria-controls=\"profile\" role=\"tab\" data-toggle=\"tab\" (click)=\"onCash()\"> Cash </a>\r\n                                                                </li>\r\n                                                            </ul>\r\n                                                        </div>\r\n                                                        <div class=\"col-md-offset-2 col-md-8 col-sm-offset-2 col-sm-8 col-xs-12\">\r\n                                                            <div *ngIf=\"showpatOtion=='card'\" role=\"tabpanel\" class=\"tab-pane active\" id=\"card-content\">\r\n                                                                <div class=\"credit-form\">\r\n                                                                    <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                                        <input type=\"text\" name=\"\" placeholder=\"Card Number\" class=\"form-control txtfield\">\r\n                                                                    </div>\r\n                                                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                                        <input type=\"text\" name=\"\" placeholder=\"MM / YY\" class=\"form-control txtfield\">\r\n                                                                    </div>\r\n                                                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n                                                                        <div class=\"input-group\">\r\n                                                                            <input type=\"text\" class=\"form-control txtfield\" placeholder=\"CVV\" aria-describedby=\"basic-addon2\">\r\n                                                                            <span class=\"input-group-addon cvv-box\" id=\"basic-addon2\"  data-placement=\"top\" data-toggle=\"tooltip\" class=\"fa fa-info-circle\" data-original-title=\"The CVV Number is the last 3 digits printed on the signature panel on the back side of the card. \">\r\n                                                                                <img src=\"assets/img/cvv.png\" />\r\n                                                                                <div class=\"cvvinfo\"></div>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                    <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                                                        <input type=\"text\" name=\"\" placeholder=\"Name of Card\" class=\"form-control txtfield\">\r\n                                                                    </div>\r\n                                                                    <div class=\"form-group col-md-12 col-sm-12 col-xs-12 \">\r\n                                                                        <input type=\"submit\" name=\"\" value=\"Proceed to Pay\" class=\"btn cut-btn\" data-target=\"#proceed-pay\" data-toggle=\"modal\">\r\n                                                                    </div>\r\n                                                                    <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                                        <p class=\"help-block\">This card will be securely saved for a faster payment experience. CVV number will not be saved</p>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-md-12 col-sm-12 col-xs-12 scure-ico\">\r\n                                                                        <img src=\"assets/img/secure-ico.png\"/>\r\n                                                                        <img src=\"assets/img/secure-icon2.png\" />\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                            <div *ngIf=\"showpatOtion=='cash'\" role=\"tabpanel\" class=\"tab-pane\" id=\"cash-content\">\r\n                                                                <div class=\"cash-section\">\r\n                                                                    <ul class=\"cash-list\">\r\n                                                                        <li>\r\n                                                                            <span class=\"cast-leftt\">\r\n                                                                                Price\r\n                                                                            </span>\r\n                                                                            <span class=\"right-cashd\">AED {{getTotalPay()}}</span>\r\n                                                                        </li>\r\n                                                                        <li>\r\n                                                                            <span class=\"cast-leftt\">\r\n                                                                                Total Services\r\n                                                                            </span>\r\n                                                                            <span class=\"right-cashd\">{{letConfirmServices.length}}</span>\r\n                                                                        </li>\r\n                                                                        <li class=\"total-price\">\r\n                                                                            <span class=\"cast-leftt\">\r\n                                                                                Amount Payable\r\n                                                                            </span>\r\n                                                                            <span class=\"right-cashd\">AED {{getTotalPay()}}</span>\r\n                                                                        </li>\r\n                                                                    </ul>\r\n                                                                </div>\r\n                                                                <div class=\"confirm-btn text-center\">\r\n                                                                    <button type=\"submit\" class=\"btn cut-btn\" (click)=\"payWithCash()\"><i class=\"fa fa-check\" ></i> OK</button>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                            <!-- 2nd type -->\r\n                                                        </div>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"tab-pane {{tab3}}\" id=\"tab_c\">\r\n                                                <div class=\"confirmation-payment\">\r\n                                                    <div class=\"wrap-confirmation\">\r\n                                                        <h4>Appointment Details</h4>\r\n                                                        <div class=\"decription-list\">\r\n                                                            <dl class=\"dl-horizontal\" *ngFor=\"let confirm of letConfirmServices\">\r\n                                                                <dt>Date:</dt>\r\n                                                                <dd>{{confirm.date}}</dd>\r\n                                                                <dt>Time:</dt>\r\n                                                                <dd>{{getHours(confirm.startTime1)}}:{{getMint(confirm.startTime1)}} {{getAmPm(confirm.startTime1)}} - {{getHours(confirm.endTime1)}}:{{getMint(confirm.endTime1)}} {{getAmPm(confirm.endTime1)}}</dd>\r\n                                                                <dt>Service Name:</dt>\r\n                                                                <dd>{{confirm.services_eng}}</dd>\r\n                                                                <dt>Payment Status:</dt>\r\n                                                                <dd class=\"salon-name\">Cash</dd>\r\n                                                            </dl>\r\n                                                        </div>\r\n                                                        <div class=\"confirm-btn\">\r\n                                                            <button type=\"submit\" class=\"btn cut-btn\" (click)=\"onclosePayment()\"><i class=\"fa fa-check\"></i> OK</button>\r\n                                                        </div>\r\n                                                    </div>                                                   \r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-md-4 col-sm-4 col-xs-12 payment-1\" *ngIf=\"currentTab=='tab1'\">\r\n                            <div class=\"payment-sidebar\">\r\n                                <div class=\"wrap-appoiment\" >\r\n                                    <div class=\"payment-service-h\">\r\n                                        <p class=\"selected-service\">Your's booked appointments please make payment for confirm appointment  </p>\r\n                                    </div>\r\n                                    <div class=\"selected-time\">\r\n                                        <ul class=\"slected-tul\">\r\n                                            <li class=\"payment-pro-in\" *ngFor=\"let confirm of letConfirmServices\">\r\n                                            <div class=\"row\">\r\n                                                <div class=\"selected-t-left\">\r\n                                                   <span style=\"color: #d5275a\">{{confirm.services_eng}} <i class=\"fa fa-clock-o\"></i>{{getTime(confirm.time)}}</span>\r\n                                               </div> \r\n                                               <div class=\"selected-t-right\">\r\n                                                    <h5>AED {{confirm.cost_eng}}</h5>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"row\">\r\n                                                <div class=\"selected-t-left\">\r\n                                                   <span><i class=\"fa fa-user\"></i>{{getEmpName(confirm.emp_id)}}</span>>\r\n                                               </div> \r\n                                               <div class=\"selected-t-right\">\r\n                                                    <p><i class=\"fa fa-calendar\">{{confirm.date}}</i></p>\r\n                                                    \r\n                                                </div>\r\n                                                \r\n                                            </div>\r\n                                            <div class=\"row\">\r\n                                                  <span><i class=\"fa fa-clock-o\"></i>{{getHours(confirm.startTime1)}}:{{getMint(confirm.startTime1)}} {{getAmPm(confirm.startTime1)}} - {{getHours(confirm.endTime1)}}:{{getMint(confirm.endTime1)}} {{getAmPm(confirm.endTime1)}}</span>  \r\n                                                </div>\r\n                                               \r\n                                            </li>\r\n                                            <!-- <li class=\"payment-pro-in\">\r\n                                               <span class=\"selected-t-left\">\r\n                                                   <p>Select a date and time to proceed booking</p>\r\n                                               </span> \r\n                                               <span class=\"selected-t-right\">\r\n                                                    <h5>AED 40</h5>\r\n                                                </span>\r\n                                            </li> -->\r\n                                        </ul>\r\n                                        <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                        <div class=\"ok-btn-otp\">\r\n                                            <button [disabled]=\"getTotalPay()==0\" type=\"submit\" data-dismiss=\"modal\" class=\"btn cut-btn\" (click)=\"creatConfirmationForPay()\"><i class=\"fa fa-check\"></i> Pay {{getTotalPay()}}</button>\r\n                                        </div>\r\n                                    </div>\r\n                                    </div>\r\n                                </div>\r\n                                <!-- <div class=\"pay-book-sec\">\r\n                                    <h5>Appointment Details</h5>\r\n                                    <dl class=\"dl-horizontal\">\r\n                                        <dt>Date</dt>\r\n                                        <dd>21 November 2017</dd>\r\n                                        <dt>Time</dt>\r\n                                        <dd>9:10 AM To 10:30 PM</dd>\r\n                                        <dt>Service Name</dt>\r\n                                        <dd>Hair Cut & Hair color</dd>\r\n                                        <dt>Salon Name</dt>\r\n                                        <dd class=\"salon-name\"> Big Beauty Services Salon </dd>\r\n                                    </dl>\r\n                                </div> -->\r\n                               <!--  <div class=\"Confirmation-sec\">\r\n                                    <div class=\"salon-add-map\">\r\n                                        <div id=\"googleMap\" style=\"width:100%;height:200px;\"></div>\r\n                                        <div class=\"address-salon\">\r\n                                            <h4>Big Hair Beauty Salon</h4>\r\n                                            <p class=\"addres-salon\">9566 Destiny USA Dr E208, Syracuse, NY 13290, USA</p>\r\n                                            <div class=\"Opening-hours\">\r\n                                                <a id=\"opening\" href=\"javascript:void(0);\">Opening Hours \r\n                                                    <span class=\"pull-right\">\r\n                                                    <i class=\"fa fa-minus-circle\"></i>  \r\n                                                    </span>\r\n                                                </a>\r\n                                                <ul class=\"timing-ul\">\r\n                                                    <li>\r\n                                                        <span class=\"week-name\">Sunday</span>\r\n                                                        <span class=\"opening-time\">10:00 AM - 10:00 PM</span>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <span class=\"week-name\">Monday</span>\r\n                                                        <span class=\"opening-time\">10:00 AM - 10:00 PM</span>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <span class=\"week-name\">Tuesday</span>\r\n                                                        <span class=\"opening-time\">10:00 AM - 10:00 PM</span>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <span class=\"week-name\">Wednesday</span>\r\n                                                        <span class=\"opening-time\">10:00 AM - 10:00 PM</span>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <span class=\"week-name\">Thursday</span>\r\n                                                        <span class=\"opening-time\">10:00 AM - 10:00 PM</span>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <span class=\"week-name\">Friday</span>\r\n                                                        <span class=\"opening-time\">10:00 AM - 10:00 PM</span>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <span class=\"week-name\">Saturday</span>\r\n                                                        <span class=\"opening-time\">10:00 AM - 10:00 PM</span>\r\n                                                    </li>\r\n                                                </ul>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div> -->\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div> \r\n        </section>\r\n        <!-- Modal -->\r\n        <div class=\"modal fade signup\" id=\"professional-typ\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n          <div class=\"modal-dialog\" role=\"document\">\r\n            <div class=\"modal-content\">\r\n                <div class=\"modal-header\">\r\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n                    <span aria-hidden=\"true\">&times;</span>\r\n                    </button>\r\n                    <h4 class=\"modal-title\" id=\"myModalLabel\">STAFF</h4>\r\n                </div>\r\n                <div class=\"modal-body\">\r\n                    <div class=\"sign-selectoption\">\r\n                        <div class=\"col-md-12 col-xs-12 col-sm-12 p-0\">\r\n                            <div class=\"professional-type\">\r\n                                <ul class=\"profe-ul\" *ngIf=\"currentServiceId\">\r\n                                    <li *ngFor=\" let emp of getEmplloyeListForService();let i=index\">\r\n                                        <div class=\"custom-radio\">\r\n                                            <input type=\"radio\" id=\"{{i}}\" name=\"empId\" [(ngModel)]=\"emp.check\" value=\"{{emp.employee_id}}\" (change)=\"onSelectEmployeeRadio(emp)\" />\r\n                                            <label for=\"{{i}}\">\r\n                                               <img *ngIf=\"!emp.employeeDetails.employee_image\" src=\"assets/img/user-pay.svg\" class=\"img-responsive\">\r\n                                               <img *ngIf=\"emp.employeeDetails.employee_image\" [src]=\"getimage(emp.employeeDetails.employee_image)\" class=\"img-responsive\"> \r\n                                               <small>{{emp.employeeDetails.first_name}} {{emp.employeeDetails.last_name}}</small> <span><span></span></span>\r\n                                            </label>\r\n                                        </div>\r\n                                    </li>\r\n                                    <!-- <li>\r\n                                        <div class=\"custom-radio\">\r\n                                            <input type=\"radio\" id=\"radio02\" name=\"radio\"/>\r\n                                            <label for=\"radio02\">\r\n                                               <img src=\"assets/img/user-pay.svg\" class=\"img-responsive\"> \r\n                                               <small>His & Her Favourite 3 <p>staff</p></small> <span><span></span></span>\r\n                                            </label>\r\n                                        </div>\r\n                                    </li>\r\n                                    <li>\r\n                                        <div class=\"custom-radio\">\r\n                                            <input type=\"radio\" id=\"radio03\" name=\"radio\"/>\r\n                                            <label for=\"radio03\">\r\n                                               <img src=\"assets/img/user-pay.svg\" class=\"img-responsive\"> \r\n                                               <small>His & Her Favourite 2 <p>staff</p></small> <span><span></span></span>\r\n                                            </label>\r\n                                        </div>\r\n                                    </li>\r\n                                    <li>\r\n                                        <div class=\"custom-radio\">\r\n                                            <input type=\"radio\" id=\"radio04\" name=\"radio\"/>\r\n                                            <label for=\"radio04\">\r\n                                               <img src=\"assets/img/user-pay.svg\" class=\"img-responsive\"> \r\n                                               <small>His & Her Favourite 1 <p>staff</p></small> <span><span></span></span>\r\n                                            </label>\r\n                                        </div>\r\n                                    </li>\r\n                                    <li>\r\n                                        \r\n                                    </li> -->\r\n                                </ul>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"modal fade signup\" id=\"proceed-pay\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n          <div class=\"modal-dialog\" role=\"document\">\r\n            <div class=\"modal-content\">\r\n                <div class=\"modal-header\">\r\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n                    <span aria-hidden=\"true\">&times;</span>\r\n                    </button>\r\n                    <h4 class=\"modal-title\" id=\"myModalLabel\">OTP FORM</h4>\r\n                </div>\r\n                <div class=\"modal-body\">\r\n                    <div class=\"sign-selectoption\">\r\n                        <div class=\"col-md-12 col-xs-12 col-sm-12 p-0\">\r\n                            <form class=\"opt-form\">\r\n                                <h4>Please enter the OTP received on your mobile number</h4>\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <label>Enter OTP Number<small class=\"manidatory\">*</small></label>\r\n                                    <input type=\"text\" value=\"\" placeholder=\"Enter OTP\" class=\"form-control\">\r\n                                </div>\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <div class=\"ok-btn-otp\">\r\n                                        <button type=\"submit\" class=\"btn cut-btn\"><i class=\"fa fa-check\"></i> OK</button>\r\n                                    </div>\r\n                                </div>\r\n                            </form>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"modal fade signup\" id=\"proceed-time\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n          <div class=\"modal-dialog\" role=\"document\">\r\n            <div class=\"modal-content\">\r\n                <div class=\"modal-header\">\r\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n                    <span aria-hidden=\"true\">&times;</span>\r\n                    </button>\r\n                    <h4 class=\"modal-title\" id=\"myModalLabel\">OTP FORM</h4>\r\n                </div>\r\n                <div class=\"modal-body\">\r\n                    <div class=\"sign-selectoption\">\r\n                        <div class=\"calender-section\">\r\n                          <div class=\"row text-center\">\r\n                                        <div class=\"col-md-12\">\r\n                                          <div class=\"btn-group\">\r\n                                            <div\r\n                                              class=\"btn cus-btn\"\r\n                                              mwlCalendarPreviousView\r\n                                              [view]=\"view\"\r\n                                              [(viewDate)]=\"viewDate\"\r\n                                              (viewDateChange)=\"activeDayIsOpen = false\" (click)=\"onPrevious()\">\r\n                                              Previous\r\n                                            </div>\r\n                                            <div\r\n                                              class=\"btn cus-btn\"\r\n                                              mwlCalendarToday\r\n                                              [(viewDate)]=\"viewDate\" (click)=\"onToday()\">\r\n                                              Today\r\n                                            </div>\r\n                                            <div\r\n                                              class=\"btn cus-btn\"\r\n                                              mwlCalendarNextView\r\n                                              [view]=\"view\"\r\n                                              [(viewDate)]=\"viewDate\"\r\n                                              (viewDateChange)=\"activeDayIsOpen = false\" (click)=\"onNext()\">\r\n                                              Next\r\n                                            </div>\r\n                                          </div>\r\n                                        </div>\r\n                                      </div>\r\n                            <div class=\"week-sec custom-week-sec\">\r\n                                <div [ngSwitch]=\"view\">\r\n                                  <mwl-calendar-month-view\r\n                                    *ngSwitchCase=\"'month'\"\r\n                                    [viewDate]=\"viewDate\"\r\n                                    [events]=\"events\"\r\n                                    [locale]=\"locale\"\r\n                                    [refresh]=\"refresh\"\r\n                                    (dayClicked)=\"dayClicked($event.day)\"\r\n                                    (eventClicked)=\"handleEvent('Clicked', $event.event)\"\r\n                                    (eventTimesChanged)=\"eventTimesChanged($event)\">\r\n                                  </mwl-calendar-month-view>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"time-sec\" *ngIf=\"selectedDate\">\r\n                              <h4>Choose Your Time Slot for {{selectedDate}}</h4>\r\n                              <ul class=\"time-slot-ul\" *ngIf=\"timeSlot.length>0\">\r\n                                <!-- <li class=\"dull-date\">01:00 - 02:00</li> -->\r\n                                <li *ngFor=\"let time of timeSlot;let i=index\" class=\"{{getClass(time,i)}}\" (click)=\"onSelectSedule(time,i)\">{{getHours(time.start)}}:{{getMint(time.start)}} {{getAmPm(time.start)}} - {{getHours(time.end)}}:{{getMint(time.end)}} {{getAmPm(time.end)}}</li>\r\n                                <!-- <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>02:00 - 03:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>02:00 - 03:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li>\r\n                                <li>01:00 - 02:00</li> -->\r\n                              </ul>\r\n                            </div>\r\n                            <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <div class=\"ok-btn-otp\">\r\n                                        <button [disabled]=\"!scheduleIndex\" type=\"submit\" data-dismiss=\"modal\" class=\"btn cut-btn\" (click)=\"creatConfirmation()\"><i class=\"fa fa-check\"></i> Confirm</button>\r\n                                    </div>\r\n                                </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n          </div>\r\n        </div>"

/***/ }),

/***/ "../../../../../src/app/payment-process/payment-process.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "agm-map {\n  height: 300px; }\n\n.salon-images-sec {\n  float: left;\n  width: 100%;\n  margin-top: 30px; }\n\n.custome-tab {\n  display: inline-block;\n  width: 100%;\n  padding-left: 0px; }\n\n.custome-tab li {\n  width: 33.33%;\n  float: left;\n  text-align: center;\n  display: inline-block;\n  background-color: #f8f8f8;\n  padding: 10px 10px; }\n\n.custome-tab li.active {\n  background-color: #d5275a; }\n\n.custome-tab li.active a {\n  color: #fff;\n  text-decoration: none; }\n\n.custome-tab li a {\n  font-size: 16px;\n  font-weight: 500;\n  color: #d5275a;\n  width: 100%;\n  display: inline-block; }\n\n.custome-tab li a:hover {\n  text-decoration: none;\n  outline: none; }\n\n.timeslot {\n  float: left;\n  width: auto;\n  margin: 5px 10px; }\n\n.select-categ {\n  float: left;\n  width: auto;\n  display: inline-block; }\n\n.select-categ-under-div {\n  float: left;\n  width: 100%;\n  margin-top: 5px; }\n\n.slkt-tim-div {\n  float: right;\n  width: 100%;\n  text-align: right;\n  padding-right: 20px; }\n\n.slkt-tim-div a {\n  color: #d5275a;\n  font-size: 16px;\n  text-decoration: none;\n  margin-left: 10px; }\n\n.right-icon {\n  top: 4px; }\n\n.right-icon i {\n  font-size: 30px;\n  line-height: 20px; }\n\n.service-listwrap > a:hover, .service-listwrap > a:focus {\n  color: #d5275a; }\n\n.slect-pro:hover, .slect-pro:focus, .slect-pro:active {\n  text-decoration: none;\n  outline: none;\n  color: #d5275b; }\n\n.slect-pro {\n  display: inline-block;\n  margin-left: 10px;\n  font-size: 14px;\n  margin-top: 10px;\n  font-weight: 500;\n  color: #d5275a; }\n\n/* .service-prl2{\r\n    float: left; \r\n} */\n.service-prl2 {\n  float: right;\n  /* width: auto; */\n  display: inline-block; }\n\n.empy-name {\n  font-size: 16px;\n  margin-left: 7px;\n  text-transform: capitalize; }\n\n.dull-date2 {\n  background-color: #e8fde7; }\n\n.datetime-show {\n  float: left;\n  width: 100%;\n  padding: 0 10px;\n  background-color: #f8f8f8; }\n\n.datetime-show ul {\n  padding: 0;\n  display: inline-block;\n  width: 100%;\n  padding: 15px 0;\n  margin-bottom: 0; }\n\n.datetime-show ul li {\n  display: inline-block;\n  width: 50%;\n  float: left;\n  font-size: 16px; }\n\n.datetime-show[_ngcontent-c2] ul[_ngcontent-c2] li[_ngcontent-c2]:last-child {\n  text-align: right;\n  padding-right: 20px; }\n\n.datetime-show i {\n  color: #d5275a;\n  font-size: 20px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/payment-process/payment-process.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PaymentProcessComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns__ = __webpack_require__("../../../../date-fns/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_date_fns___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_date_fns__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_rxjs_Subject__ = __webpack_require__("../../../../rxjs/_esm5/Subject.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__providers_app_provider__ = __webpack_require__("../../../../../src/app/providers/app.provider.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__agm_core__ = __webpack_require__("../../../../@agm/core/index.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var colors = {
    red: {
        primary: '#ad2121',
        secondary: '#FAE3E3'
    },
    blue: {
        primary: '#1e90ff',
        secondary: '#D1E8FF'
    },
    yellow: {
        primary: '#e3bc08',
        secondary: '#FDF1BA'
    }
};
var PaymentProcessComponent = (function () {
    function PaymentProcessComponent(router, saloonServices, vcr, toastr, commonService, appProvider, route, mapsAPILoader, ngZone) {
        this.router = router;
        this.saloonServices = saloonServices;
        this.toastr = toastr;
        this.commonService = commonService;
        this.appProvider = appProvider;
        this.route = route;
        this.mapsAPILoader = mapsAPILoader;
        this.ngZone = ngZone;
        this.view = 'month';
        this.locale = 'en';
        this.viewDate = new Date();
        this.selectedServices = JSON.parse(localStorage['selectedServices']);
        this.refresh = new __WEBPACK_IMPORTED_MODULE_4_rxjs_Subject__["Subject"]();
        this.activeDayIsOpen = true;
        this.userDetail = JSON.parse(localStorage['userdetails']);
        this.totalAmount = 0;
        this.timeSlot = [];
        this.letConfirmServices = [];
        this.currentTab = 'tab1';
        this.tab1 = 'active';
        this.tab2 = '';
        this.tab3 = '';
        this.showpatOtion = 'card';
        this.customer = JSON.parse(localStorage['customerdetails']);
        this.bookedTime1 = '11:30';
        this.bookedTime2 = '12:15';
        this.bookedHistory = [
            { bookedTime1: '11:30', bookedTime2: '12:15' },
            { bookedTime1: '12:25', bookedTime2: '13:20' },
            { bookedTime1: '15:45', bookedTime2: '19:20' }
        ];
        this.toastr.setRootViewContainerRef(vcr);
        this.id = +this.route.snapshot.paramMap.get('id');
        console.log(JSON.stringify(this.selectedServices));
        console.log(JSON.stringify(this.customer));
        this.getSaloonData();
    }
    PaymentProcessComponent.prototype.ngOnInit = function () {
        $('.sub-menulist').hide();
        $('.timing-ul').hide();
        this.getSaloonData();
    };
    PaymentProcessComponent.prototype.onCard = function () {
        this.showpatOtion = 'card';
    };
    PaymentProcessComponent.prototype.onCash = function () {
        this.showpatOtion = 'cash';
    };
    PaymentProcessComponent.prototype.getLat = function (lat) {
        return parseInt(lat);
    };
    PaymentProcessComponent.prototype.getLon = function (long) {
        return parseInt(long);
    };
    PaymentProcessComponent.prototype.getSaloonData = function () {
        var _this = this;
        this.waitLoader = true;
        this.commonService.getAllServiceBySaloon(this.id)
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.saloonData = data.data;
                _this.saloonServicesList = _this.saloonData.saloonServices;
                _this.saloonEmployeeList = _this.saloonData.saloonEmployee;
                var owl = $(".owl-demo1");
                owl.owlCarousel({
                    nav: true,
                    loop: true,
                    items: 4,
                    itemsDesktop: [1000, 3],
                    itemsDesktopSmall: [900, 3],
                    itemsTablet: [600, 2],
                    itemsMobile: false,
                    autoplay: true // itemsMobile disabled - inherit from itemsTablet option
                });
                console.log(_this.saloonData.description_eng);
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    PaymentProcessComponent.prototype.onSelectEmployee = function (ser, i) {
        this.selecteEmployeeAppointment = null;
        this.currentServiceId = ser.service_id;
        this.currentIndex = i;
    };
    PaymentProcessComponent.prototype.getEmplloyeListForService = function () {
        var _this = this;
        var data = this.saloonServicesList.filter(function (arg) { return arg.service_id == _this.currentServiceId && arg.saloon_id == _this.id; });
        if (data.length > 0) {
            // code...
            return data[0].servicesData.serByEmplnServiceData;
        }
        else {
            return [];
        }
    };
    PaymentProcessComponent.prototype.onSelectEmployeeRadio = function (value) {
        //alert(this.currentIndex)
        //alert(value)his.selectedServices[this.currentIndex] is undefined
        this.selecteEmployeeAppointment = value.employeeDetails.Appointment;
        this.selectedServices[this.currentIndex].emp_id = value.employee_id;
    };
    PaymentProcessComponent.prototype.getimage = function (img) {
        return 'http://18.216.88.154/public/beauti-service/' + img;
    };
    PaymentProcessComponent.prototype.getEmpImg = function (emp_id) {
        var data = this.saloonEmployeeList.filter(function (arg) { return arg.id == emp_id; });
        if (data.length > 0) {
            // code...
            return 'http://18.216.88.154/public/beauti-service/' + data[0].employee_image;
        }
        else {
            return 'assets/img/user-pay.svg';
        }
    };
    PaymentProcessComponent.prototype.getEmpName = function (emp_id) {
        var data = this.saloonEmployeeList.filter(function (arg) { return arg.id == emp_id; });
        if (data.length > 0) {
            // code...
            return data[0].first_name + ' ' + data[0].last_name;
        }
    };
    PaymentProcessComponent.prototype.onTimeSelect = function (ser) {
        this.cusrrentService = ser;
        this.selectedDate = null;
        this.scheduleIndex = null;
        this.timeSlot = [];
        var openingTime = this.saloonData.opening_time.split(':');
        var closingTime = this.saloonData.closing_time.split(':');
        var time1 = parseInt(openingTime[0]) * 60 + parseInt(openingTime[1]);
        var time2 = parseInt(closingTime[0]) * 60 + parseInt(closingTime[1]);
        var length = (time2 - time1) / parseInt(ser.time);
        if (length > 0) {
            var time3 = time1;
            var time4 = time3 + parseInt(ser.time);
            for (var i = 0; i < length; ++i) {
                if (time3 < time2 && time4 < time2) {
                    this.timeSlot.push({ start: time3, end: time4, checkStatus: false });
                    time3 = time3 + parseInt(ser.time);
                    time4 = time4 + parseInt(ser.time);
                }
                // code...
            }
        }
    };
    PaymentProcessComponent.prototype.getHours = function (time) {
        var a = Math.floor(time / 60);
        if (a < 10) {
            return '0' + a;
        }
        else {
            if (a > 12) {
                var b = a - 12;
                return '0' + b; // code...
            }
            else {
                return a;
            }
        }
    };
    PaymentProcessComponent.prototype.getMint = function (time) {
        var a = Math.floor(time % 60);
        if (a < 10) {
            return '0' + a;
        }
        else {
            return a;
        }
    };
    PaymentProcessComponent.prototype.getAmPm = function (time) {
        var a = Math.floor(time / 60);
        if (a > 11) {
            return 'PM';
        }
        else {
            return 'AM';
        }
    };
    PaymentProcessComponent.prototype.getClass = function (time, index) {
        // let time1=this.bookedTime1.split(':')
        // let time2=this.bookedTime2.split(':')
        // let time3=parseInt(time1[0])*60+parseInt(time1[1])
        // let time4=parseInt(time2[0])*60+parseInt(time2[1])
        // console.log('time3',time3)
        // console.log('time4',time4)
        // console.log('start',time.start) onSelectEmployee
        // console.log('end',time.end)
        //alert('hy')
        if (time.checkStatus == true) {
            if (time.secheuleStart && time.secheuleEnd) {
                return 'dull-date2';
                // code...
            }
            else {
                return 'dull-date';
            }
        }
        else {
            //this.appointmentOnselecteddate=this.selecteEmployeeAppointment.filter(arg=>arg.date==this.selectedDate)
            if (this.appointmentOnselecteddate.length > 0) {
                // code...
                for (var i = 0; i < this.appointmentOnselecteddate.length; ++i) {
                    var time1 = this.appointmentOnselecteddate[i].start_time.split(':');
                    var time2 = this.appointmentOnselecteddate[i].end_time.split(':');
                    var time3 = parseInt(time1[0]) * 60 + parseInt(time1[1]);
                    var time4 = parseInt(time2[0]) * 60 + parseInt(time2[1]);
                    console.log('time3', time3);
                    console.log('time4', time4);
                    console.log('start', time.start);
                    console.log('end', time.end);
                    if (time.start < time3 && time.end <= time3) {
                        // return ''
                    }
                    else if (time.start > time4 && time.end > time4) {
                        // return ''
                    }
                    else if (time.start <= time3 && time.end <= time4) {
                        this.timeSlot[index].checkStatus = true;
                        return 'dull-date';
                    }
                    else if (time.start > time3 && time.end <= time4) {
                        this.timeSlot[index].checkStatus = true;
                        return 'dull-date';
                    }
                    else if (time.start < time3 && time.end > time4) {
                        // code...
                        this.timeSlot[index].checkStatus = true;
                        return 'dull-date';
                    }
                    else if (time.start < time4 && time.end > time4) {
                        this.timeSlot[index].checkStatus = true;
                        return 'dull-date';
                    }
                }
            }
        }
    };
    PaymentProcessComponent.prototype.onSelectSedule = function (time, index) {
        if (time.checkStatus == true) {
        }
        else {
            this.scheduleIndex = index;
            for (var i = 0; i < this.timeSlot.length; i++) {
                if (this.timeSlot[i].secheuleStart && this.timeSlot[i].secheuleEnd) {
                    this.timeSlot[i].checkStatus = false;
                }
            }
            this.timeSlot[index].secheuleStart = time.start;
            this.timeSlot[index].secheuleEnd = time.end;
            this.timeSlot[index].checkStatus = true;
        }
    };
    PaymentProcessComponent.prototype.rest = function () {
        this.scheduleIndex = null;
        for (var i = 0; i < this.timeSlot.length; i++) {
            if (this.timeSlot[i].secheuleStart && this.timeSlot[i].secheuleEnd) {
                this.timeSlot[i].checkStatus = false;
                this.timeSlot[i].secheuleStart = false;
                this.timeSlot[i].secheuleEnd = false;
            }
        }
    };
    PaymentProcessComponent.prototype.onPrevious = function () {
        this.rest();
    };
    PaymentProcessComponent.prototype.onToday = function () {
        this.rest();
    };
    PaymentProcessComponent.prototype.onNext = function () {
        this.rest();
    };
    PaymentProcessComponent.prototype.creatConfirmation = function () {
        console.log(JSON.stringify(this.timeSlot[this.scheduleIndex]));
        var startTime = this.getHours(this.timeSlot[this.scheduleIndex].secheuleStart) + ':' + this.getMint(this.timeSlot[this.scheduleIndex].secheuleStart);
        var endTime = this.getHours(this.timeSlot[this.scheduleIndex].secheuleEnd) + ':' + this.getMint(this.timeSlot[this.scheduleIndex].secheuleEnd);
        this.selectedServices[this.currentIndex].startTime = startTime;
        this.selectedServices[this.currentIndex].endTime = endTime;
        this.selectedServices[this.currentIndex].startTime1 = this.timeSlot[this.scheduleIndex].secheuleStart;
        this.selectedServices[this.currentIndex].endTime1 = this.timeSlot[this.scheduleIndex].secheuleEnd;
        this.selectedServices[this.currentIndex].date = this.selectedDate;
    };
    PaymentProcessComponent.prototype.onCoinfirmAppointment = function (ser) {
        var _this = this;
        this.waitLoader = true;
        var a = {
            customer_id: this.customer.id,
            saloon_id: ser.saloon_id,
            category_id: ser.category_id,
            services_id: ser.service_id,
            amount: ser.cost_eng,
            start_time: ser.startTime,
            end_time: ser.endTime,
            emp_id: ser.emp_id,
            date: ser.date
        };
        this.commonService.createAppointment(a)
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            if (data.response) {
                _this.getSaloonData();
                _this.selectedServices[_this.currentIndex].appointment_id = data.data.id;
                _this.letConfirmServices.push(_this.selectedServices[_this.currentIndex]);
            }
        });
    };
    PaymentProcessComponent.prototype.getTotalPay = function () {
        if (this.letConfirmServices.length > 0) {
            var cost = 0;
            for (var i = 0; i < this.letConfirmServices.length; ++i) {
                // code...
                cost = cost + parseInt(this.letConfirmServices[i].cost_eng);
            }
            return cost;
            // code...
        }
        else {
            return 0;
        }
    };
    PaymentProcessComponent.prototype.onGetConfirmService = function () {
        var data = this.selectedServices.filter(function (arg) { return arg.appointment_id; });
        console.log(data);
        return data;
    };
    PaymentProcessComponent.prototype.creatConfirmationForPay = function () {
        this.currentTab = 'tab2';
        this.tab1 = '';
        this.tab2 = 'active';
        this.tab3 = '';
    };
    PaymentProcessComponent.prototype.payWithCash = function () {
        var _this = this;
        for (var i = 0; i < this.letConfirmServices.length; ++i) {
            this.commonService.updatePaymentStatusByCash(this.letConfirmServices[i].appointment_id)
                .subscribe(function (data) {
                var list = [];
                _this.waitLoader = false;
                if (data.response) {
                    _this.letConfirmServices[i].paymrnt_status = true;
                    //  //this.getSaloonData()
                    // this.selectedServices[this.currentIndex].appointment_id=data.data.id
                    // this.letConfirmServices.push(this.selectedServices[this.currentIndex])
                }
            });
            // code...
        }
        this.currentTab = 'tab3';
        this.tab1 = '';
        this.tab2 = '';
        this.tab3 = 'active';
    };
    PaymentProcessComponent.prototype.onDelteAppontment = function (ser, index) {
        var _this = this;
        this.waitLoader = true;
        this.commonService.deleteAppointmentById(ser.appointment_id)
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            if (data.response) {
                _this.getSaloonData();
                _this.selectedServices[index].appointment_id = null;
                _this.selectedServices[index].date = null;
                _this.selectedServices[index].startTime = null;
                _this.selectedServices[index].endTime = null;
                _this.selectedServices[index].startTime1 = null;
                _this.selectedServices[index].endTime1 = null;
                _this.selectedServices[index].emp_id = null;
                var indexOf = _this.letConfirmServices.map(function (img) { return img.appointment_id; }).indexOf(data.appointment_id);
                _this.letConfirmServices.splice(index, 1);
                // this.letConfirmServices.push(this.selectedServices[this.currentIndex])
            }
        });
    };
    PaymentProcessComponent.prototype.onclosePayment = function () {
        this.router.navigate(['/header-one-layout/home-page']);
    };
    PaymentProcessComponent.prototype.ngOnDestroy = function () {
        localStorage['selectedServices'] = 'null';
        //localStorage.removeItem('selectedServices');
    };
    PaymentProcessComponent.prototype.openCategory = function (ref) {
        $(ref).toggleClass('active');
        $(ref).next('.sub-menulist').slideToggle('500');
        $(ref).find('i').toggleClass('fa-angle-up fa-angle-down');
    };
    PaymentProcessComponent.prototype.openCategory2 = function (ref) {
        $(ref).next('.timing-ul').slideToggle('500');
        $(ref).find('i').toggleClass('fa-plus-circle fa-minus-circle');
    };
    PaymentProcessComponent.prototype.getTime = function (time) {
        var a;
        switch (time) {
            case "15":
                a = '15 Min';
                //alert(a)
                return a;
            case "30":
                a = '30 Min';
                return a;
            case "45":
                a = '45 Min';
                return a;
            case "60":
                a = '1 Hr';
                return a;
            case "75":
                a = '1 Hr 15 Min';
                return a;
            case "90":
                a = '1 Hr 30 Min';
                return a;
            case "105":
                a = '1 Hr 45 Min';
                return a;
            case "120":
                a = '2 Hr';
                return a;
            case "135":
                a = '2 Hr 15 Mi';
                return a;
            case "150":
                a = '2 Hr 30 Min';
                return a;
            case "165":
                a = '2 Hr 45 Min';
                return a;
            case "180":
                a = '3 Hr';
                return a;
            default:
                0;
                // alert(a)
                return a;
        }
    };
    PaymentProcessComponent.prototype.onselectService = function (data) {
        if (this.selectedServices.map(function (img) { return img.saloon_id; }).indexOf(data.saloon_id) == -1) {
            this.selectedServices.push(data);
            this.totalAmount = this.totalAmount + parseInt(data.cost_eng);
            // code...
        }
        else {
            var index = this.selectedServices.map(function (img) { return img.saloon_id; }).indexOf(data.saloon_id);
            this.selectedServices.splice(index, 1);
            this.totalAmount = this.totalAmount - parseInt(data.cost_eng);
        }
    };
    PaymentProcessComponent.prototype.getStatus = function (data) {
        if (this.selectedServices.length > 0) {
            if (this.selectedServices.map(function (img) { return img.saloon_id; }).indexOf(data.saloon_id) == -1) {
                return false;
            }
            else if (this.selectedServices.map(function (img) { return img.saloon_id; }).indexOf(data.saloon_id) != -1) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    };
    // onSchedule(){
    // localStorage['selectedServices']=JSON.stringify(this.selectedServices)
    // //this.route.na
    // }
    PaymentProcessComponent.prototype.dayClicked = function (_a) {
        var _this = this;
        var date = _a.date, events = _a.events;
        //alert(date)
        this.selectedDate = null;
        if (Object(__WEBPACK_IMPORTED_MODULE_3_date_fns__["isSameMonth"])(date, this.viewDate)) {
            var currentDateTime = new Date();
            var current = currentDateTime.getFullYear();
            var selecteddate = date.getDate();
            var selectedMonth = date.getMonth() + 1;
            var selectedyear = date.getFullYear();
            var date1 = void 0;
            var month1 = void 0;
            var year = void 0;
            if (selecteddate < 10) {
                date1 = '0' + selecteddate;
            }
            else {
                date1 = selecteddate;
            }
            if (selectedMonth < 10) {
                month1 = '0' + selectedMonth;
            }
            else {
                month1 = selectedMonth;
            }
            if (currentDateTime.getFullYear() < date.getFullYear()) {
                this.selectedDate = selectedyear + '-' + month1 + '-' + date1;
            }
            else if (currentDateTime.getFullYear() == date.getFullYear()) {
                if (currentDateTime.getMonth() < date.getMonth()) {
                    this.selectedDate = selectedyear + '-' + month1 + '-' + date1;
                }
                else if (currentDateTime.getMonth() == date.getMonth()) {
                    // code...
                    if (currentDateTime.getDate() < date.getDate()) {
                        this.selectedDate = selectedyear + '-' + month1 + '-' + date1;
                    }
                    else if (currentDateTime.getDate() == date.getDate()) {
                        this.selectedDate = selectedyear + '-' + month1 + '-' + date1;
                    }
                    else {
                        this.selectedDate = null;
                    }
                }
                else {
                    this.selectedDate = null;
                }
            }
            else if (currentDateTime.getFullYear() < date.getFullYear()) {
                this.selectedDate = null;
            }
            if ((Object(__WEBPACK_IMPORTED_MODULE_3_date_fns__["isSameDay"])(this.viewDate, date) && this.activeDayIsOpen === true) ||
                events.length === 0) {
                this.activeDayIsOpen = false;
            }
            else {
                // this.rest()
                this.activeDayIsOpen = true;
                this.viewDate = date;
            }
            if (this.selectedDate != null) {
                this.appointmentOnselecteddate = this.selecteEmployeeAppointment.filter(function (arg) { return arg.date == _this.selectedDate; });
                // code...
            }
            else {
                this.appointmentOnselecteddate = [];
            }
        }
    };
    PaymentProcessComponent.prototype.eventTimesChanged = function (_a) {
        var event = _a.event, newStart = _a.newStart, newEnd = _a.newEnd;
        event.start = newStart;
        event.end = newEnd;
        //this.handleEvent('Dropped or resized', event);
        this.refresh.next();
    };
    // handleEvent(action: string, event: CalendarEvent): void {
    //   this.modalData = { event, action };
    //   this.modal.open(this.modalContent, { size: 'lg' });
    // }
    PaymentProcessComponent.prototype.addEvent = function () {
        // this.events.push({
        //   title: 'New event',
        //   start: startOfDay(new Date()),
        //   end: endOfDay(new Date()),
        //   color: colors.red,
        //   draggable: true,
        //   resizable: {
        //     beforeStart: true,
        //     afterEnd: true
        //   }
        // });
        // this.refresh.next();
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('modalContent'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["TemplateRef"])
    ], PaymentProcessComponent.prototype, "modalContent", void 0);
    PaymentProcessComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-payment-process',
            template: __webpack_require__("../../../../../src/app/payment-process/payment-process.component.html"),
            styles: [__webpack_require__("../../../../../src/app/payment-process/payment-process.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */],
            __WEBPACK_IMPORTED_MODULE_5__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_6__providers_common_service__["a" /* CommonService */],
            __WEBPACK_IMPORTED_MODULE_7__providers_app_provider__["a" /* AppProvider */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* ActivatedRoute */],
            __WEBPACK_IMPORTED_MODULE_8__agm_core__["b" /* MapsAPILoader */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["NgZone"]])
    ], PaymentProcessComponent);
    return PaymentProcessComponent;
}());



/***/ }),

/***/ "../../../../../src/app/payment-process/payment-process.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentProcessModule", function() { return PaymentProcessModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__payment_process_routing_module__ = __webpack_require__("../../../../../src/app/payment-process/payment-process-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__payment_process_component__ = __webpack_require__("../../../../../src/app/payment-process/payment-process.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_material_tabs__ = __webpack_require__("../../../material/esm5/tabs.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__agm_core__ = __webpack_require__("../../../../@agm/core/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_angular_calendar__ = __webpack_require__("../../../../angular-calendar/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__ng_bootstrap_ng_bootstrap__ = __webpack_require__("../../../../@ng-bootstrap/ng-bootstrap/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};













var PaymentProcessModule = (function () {
    function PaymentProcessModule() {
    }
    PaymentProcessModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_3__payment_process_routing_module__["a" /* PaymentProcessRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_material_tabs__["a" /* MatTabsModule */],
                __WEBPACK_IMPORTED_MODULE_6__angular_common_http__["b" /* HttpClientModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["c" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["h" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_9_angular_calendar__["a" /* CalendarModule */].forRoot(),
                __WEBPACK_IMPORTED_MODULE_10__ng_bootstrap_ng_bootstrap__["b" /* NgbModalModule */].forRoot(),
                __WEBPACK_IMPORTED_MODULE_7_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_8__agm_core__["a" /* AgmCoreModule */].forRoot({
                    apiKey: "AIzaSyCSqtRTdfc2DOAYpOut4KEwS1xL5or4ekI",
                    libraries: ["places"]
                }),
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_4__payment_process_component__["a" /* PaymentProcessComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_11__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_12__providers_common_service__["a" /* CommonService */]]
        })
    ], PaymentProcessModule);
    return PaymentProcessModule;
}());



/***/ })

});
//# sourceMappingURL=payment-process.module.chunk.js.map