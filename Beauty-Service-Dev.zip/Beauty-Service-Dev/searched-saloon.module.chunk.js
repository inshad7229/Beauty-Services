webpackJsonp(["searched-saloon.module"],{

/***/ "../../../../../src/app/header-two-layout/searched-saloon/searched-saloon-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SearchedSaloonRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__searched_saloon_component__ = __webpack_require__("../../../../../src/app/header-two-layout/searched-saloon/searched-saloon.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__searched_saloon_component__["a" /* SearchedSaloonComponent */]
    }
];
var SearchedSaloonRoutingModule = (function () {
    function SearchedSaloonRoutingModule() {
    }
    SearchedSaloonRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], SearchedSaloonRoutingModule);
    return SearchedSaloonRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/searched-saloon/searched-saloon.component.html":
/***/ (function(module, exports) {

module.exports = " <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n         <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n </div>\r\n        <section class=\"search-saloonsec\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12\">\r\n                    <h4 class=\"header-heading\">\r\n                        <ul class=\"breadcrumb\">\r\n                            <li>\r\n                                <a href=\"javascript:void(0)\">Home</a>\r\n                            </li>\r\n                            <li>\r\n                                <a href=\"javascript:void(0)\">Salon Page</a>\r\n                            </li>\r\n                        </ul>\r\n                    </h4>\r\n                    <div class=\"row\">\r\n                        <div class=\"col-lg-3 col-md-3 col-sm-12 col-xs-12\"> \r\n                            <div class=\"filter-section\">\r\n                                <div class=\"header-saloon\">\r\n                                    <h4>Filter</h4><a href=\"javascript:void(0);\" (click)=\"onClearAll()\">Clear All</a>\r\n                                </div>\r\n                                <div class=\"filter-content\">\r\n                                    <div class=\"row\" style=\"padding-left:15px;padding-right:15px;\">\r\n                                        <div class=\"filter-inner\">\r\n                                            <h5 class=\"text-left\">Price</h5>\r\n                                            <ul class=\"priceul price-inline\">\r\n                                                <li >\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\" [(ngModel)]=\"filter.first\"   [ngModelOptions]=\"{standalone: true}\" (change)=\"onFirst(filter.first)\"> $\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\" checked=\"checked\" [(ngModel)]=\"filter.two\"   [ngModelOptions]=\"{standalone: true}\" (change)=\"onSecond(filter.two)\" > $$\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\" [(ngModel)]=\"filter.three\"  [ngModelOptions]=\"{standalone: true}\" (change)=\"onThird(filter.three)\"> $$$\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\" [(ngModel)]=\"filter.four\"  [ngModelOptions]=\"{standalone: true}\" (change)=\"onFourth(filter.four)\"> $$$$\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                </li>\r\n                                            </ul>\r\n                                        </div>\r\n                                       <!--  <div class=\"filter-inner\">\r\n                                            <h5 class=\"text-left\">Area</h5>\r\n                                            <ul class=\"priceul area-ul\">\r\n                                                <li>\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\"> <p>Business Bay</p>\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                    <small class=\"sm-1\">1</small>\r\n                                                </li>\r\n                                            </ul>\r\n                                        </div> -->\r\n                                    </div>\r\n                                    <div class=\"row\" style=\"padding-left:15px;padding-right:15px;\">\r\n                                        <!-- <div class=\"filter-inner\">\r\n                                            <h5 class=\"text-left\">Ctegories</h5>\r\n                                            <ul class=\"category-ul\">\r\n                                                <li>\r\n                                                  Spa <span class=\"remove-cross\"><a href=\"#\">X</a></span> \r\n                                                </li>\r\n                                            </ul>\r\n                                        </div> -->\r\n                                        <div class=\"filter-inner\">\r\n                                            <h5 class=\"text-left\">Services</h5>\r\n                                            <ul class=\"priceul area-ul\">\r\n                                                <li *ngFor=\"let ser of serviceList\">\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\" [(ngModel)]=\"ser.checkStatus\"  [ngModelOptions]=\"{standalone: true}\" (change)=\"onService(ser.checkStatus,ser.id)\"> <p><span>{{ser.services_eng}}</span></p>\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                  <!--   <small class=\"sm-1\">281</small> -->\r\n                                                </li>\r\n                                               <!--  <li>\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\"> <p>Blow Dry</p>\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                    <small class=\"sm-1\">231</small>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\" checked=\"checked\"> <p>Haircut</p>\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                    <small class=\"sm-1\">231</small>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\"> <p>Hair Highlight</p>\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                    <small class=\"sm-1\">200</small>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <label class=\"remember-me\">\r\n                                                        <input type=\"checkbox\"> <p>Women's Haircut</p>\r\n                                                        <span></span>\r\n                                                    </label>\r\n                                                    <small class=\"sm-1\">207</small>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <a class=\"load-more\" href=\"javascript:void(0);\">\r\n                                                        <i class=\"fa fa-plus\"></i> Load More\r\n                                                    </a>\r\n                                                </li> -->\r\n                                            </ul>\r\n                                        </div>\r\n                                    </div>\r\n                                   <!--  <div class=\"row\" style=\"padding-left:15px;padding-right:15px;\"> -->   <!-- changes div -->\r\n                                        <!-- <div class=\"filter-inner\">\r\n                                            <h5 class=\"text-left\">Service's Price</h5>\r\n                                            <div class=\"filter-sub-categ\">\r\n                                                <span class=\"min-range\">\r\n                                                    <span class=\"left-range\">AED 200.00</span>   \r\n                                                    <span class=\"right-range\">AED 200.00</span>   \r\n                                                </span>>\r\n                                                <mat-slider\r\n                                                        class=\"example-margin\"\r\n                                                        [disabled]=\"disabled\"\r\n                                                        [invert]=\"invert\"\r\n                                                        [max]=\"max\"\r\n                                                        [min]=\"min\"\r\n                                                        [step]=\"step\"\r\n                                                        [thumb-label]=\"thumbLabel\"\r\n                                                        [tick-interval]=\"tickInterval\"\r\n                                                        [(ngModel)]=\"value\"\r\n                                                        [vertical]=\"vertical\" [ngModelOptions]=\"{standalone: true}\">\r\n                                                    </mat-slider>\r\n                                            </div>\r\n                                        </div> -->\r\n                                        <!-- <div class=\"filter-inner\">\r\n                                            <h5 class=\"text-left\">Date</h5>\r\n                                            <div class=\"col-md-12 col-sm-12 col-xs-12 p-l-0\">\r\n                                                <div class=\"date-wrsap\">\r\n                                                    <div class=\"input-group\">\r\n                                                        <span class=\"input-group-addon\" id=\"basic-addon1\">\r\n                                                            <i class=\"fa fa-calendar\"></i>\r\n                                                        </span>\r\n                                                        <input type=\"text\" class=\"form-control datetimepicker1\" placeholder=\"Username\" aria-describedby=\"basic-addon1\">\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"filter-time\">\r\n                                                <p>Time</p>\r\n                                                <ul class=\"time-ul\">\r\n                                                    <li>\r\n                                                        <label class=\"remember-me\">\r\n                                                            <input type=\"checkbox\" checked=\"checked\"> <p>Any Time</p>\r\n                                                            <span></span>\r\n                                                        </label>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <label class=\"remember-me\">\r\n                                                            <input type=\"checkbox\"> <p>Morning</p>\r\n                                                            <span></span>\r\n                                                        </label>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <label class=\"remember-me\">\r\n                                                            <input type=\"checkbox\"> <p>Afternoon</p>\r\n                                                            <span></span>\r\n                                                        </label>\r\n                                                    </li>\r\n                                                    <li>\r\n                                                        <label class=\"remember-me\">\r\n                                                            <input type=\"checkbox\"> <p>Evening</p>\r\n                                                            <span></span>\r\n                                                        </label>\r\n                                                    </li>\r\n                                                </ul>\r\n                                            </div>\r\n                                        </div> -->\r\n                                    <!-- </div> -->\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-lg-9 col-md-9 col-sm-12 col-xs-12 custom-p\"> <!-- changes class please add -->\r\n                            <div class=\"service-show-sec\">\r\n                                <div class=\"filter-content\">\r\n                                    <div class=\"sorting-div wow fadeInDown\" wow-data-delay=\"0.4s\">\r\n                                        <span class=\"showing-list\" *ngIf=\"saloonList\">Showing {{saloonList.length}} results</span>\r\n                                        <span class=\"sort-by\">\r\n                                            <div class=\"col-md-4 col-sm-4 col-xs-4 p-0\"> <!-- changes class please change -->\r\n                                                <label>Sort BY</label>    \r\n                                            </div>\r\n                                            <div class=\"col-md-8 col-sm-8 col-xs-8 p-0\"> <!-- changes class please change -->\r\n                                                <div class=\"custom-select\">\r\n                                                    <select class=\"form-control txtfield\" placeholder=\"Select\">\r\n                                                        <option value=\"\" selected=\"\">Relevance</option>\r\n                                                        <option value=\"\">Lowest</option>\r\n                                                        <option value=\"\">Highest</option>\r\n                                                        <option value=\"\">Proximity</option>\r\n                                                    </select>\r\n                                                    <span class=\"caret\"></span>\r\n                                                </div>\r\n                                            </div>\r\n                                        </span>\r\n                                    </div>\r\n                                    <div class=\"service-list-sec salon-section\">\r\n                                        <div class=\"wrap-service\" *ngFor=\"let saloon of saloonList\">\r\n                                            <div class=\"img-content-sec\">\r\n                                                <div class=\"col-lg-5 col-md-5 col-sm-5 col-xs-12 p-l-0\">\r\n                                                    <div class=\"service-img\">\r\n                                                        <img *ngIf=\"!saloon.image || saloon.image=='null' || saloon.image==null \" src=\"assets/img/saloon-1.jpg\" class=\"img-responsive\">\r\n                                                        <img *ngIf=\"saloon.image && saloon.image!='null' && saloon.image!=null \" [src]=\"imagePath(saloon.image)\" class=\"img-responsive\">\r\n                                                    </div>\r\n                                                </div>\r\n                                                <div class=\"col-lg-7 col-md-7 col-sm-7 col-xs-12\">\r\n                                                    <div class=\"service-inner-des\">\r\n                                                        <h5 class=\"name-saloon\">\r\n                                                            <a href=\"javascript:void(0);\" routerLink=\"/header-two-layout/saloon-details/{{saloon.id}}\"><span>{{saloon.saloon_name}}</span></a>\r\n                                                        </h5>\r\n                                                        <address><span>{{saloon.city}}</span></address>\r\n                                                        <ul class=\"rating-points\">\r\n                                                            <li>\r\n                                                                <span *ngIf=\"saloon.saloonRating.length>0\" class=\"rating-salon\">\r\n                                                                <i class=\"{{getRatingClass(saloon.saloonRating,1)}}\"></i>\r\n                                                                <i class=\"{{getRatingClass(saloon.saloonRating,2)}}\"></i>\r\n                                                                <i class=\"{{getRatingClass(saloon.saloonRating,3)}}\"></i>\r\n                                                                <i class=\"{{getRatingClass(saloon.saloonRating,4)}}\"></i>\r\n                                                                <i class=\"{{getRatingClass(saloon.saloonRating,5)}}\"></i>\r\n                                                              </span>\r\n                                                              <span *ngIf=\"saloon.saloonRating.length<1\" class=\"rating-salon \">\r\n                                                                <i class=\"fa fa-star-o\"></i>\r\n                                                                <i class=\"fa fa-star-o\"></i>\r\n                                                                <i class=\"fa fa-star-o\"></i>\r\n                                                                <i class=\"fa fa-star-o\"></i>\r\n                                                                <i class=\"fa fa-star-o\"></i>\r\n                                                              </span>\r\n                                                                <span class=\"star-number\">({{saloon.saloonRating.length}})</span>\r\n                                                            </li>\r\n                                                            <li>\r\n                                                                <span class=\"dollor-select\">\r\n                                                                    <span class=\"card-check\" *ngIf=\"saloon.cardPay\">\r\n                                                                        <i class=\"fa fa-credit-card\"></i>\r\n                                                                        <p><i class=\"fa fa-check-circle\"></i></p>\r\n                                                                    </span>\r\n                                                                    <ul class=\"dollor-view\">\r\n                                                                        <li class=\"{{findRangclass(saloon.price_range,1)}}\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li class=\"{{findRangclass(saloon.price_range,2)}}\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li class=\"{{findRangclass(saloon.price_range,3)}}\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li class=\"{{findRangclass(saloon.price_range,4)}}\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                    </ul>\r\n                                                                </span>\r\n                                                            </li>\r\n                                                        </ul>\r\n                                                        <p class=\"description-salon\">\r\n                                                            {{saloon.description_eng}}\r\n                                                            <!-- <a href=\"javascript:void(0);\">Read More</a> -->\r\n                                                        </p>    \r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <!-- <div class=\"esact-service salon-sec\">\r\n                                                <div class=\"searched-service\" *ngFor=\"let ser of saloon.saloonServices\">\r\n                                                    <ul class=\"searched-ul {{getClass(ser.servicesData.services_eng)}}\" >\r\n                                                        <li>\r\n                                                            <span class=\"service-name\">\r\n                                                                <span>{{ser.servicesData.services_eng}}</span>\r\n                                                                <span class=\"time-on\"><i class=\"fa fa-clock-o\"></i> <span>{{getTime(ser.time)}}</span></span>\r\n                                                            </span>\r\n                                                            <span class=\"price-and-book\">\r\n                                                                <span class=\"price-nub\"><span>AED {{ser.cost_eng}}</span>\r\n                                                                </span>\r\n                                                                <span class=\"book-btn\">\r\n                                                                    <a class=\"btn cus-btn\" href=\"javascript:void(0);\">Book</a>\r\n                                                                </span>\r\n                                                            </span>\r\n                                                        </li>\r\n                                                    </ul>\r\n                                                </div>\r\n                                            </div> -->\r\n                                        </div>\r\n                                        <!-- <div class=\"wrap-service\">\r\n                                            <div class=\"img-content-sec\">\r\n                                                <div class=\"col-lg-5 col-md-5 col-sm-5 col-xs-12 p-l-0\">\r\n                                                    <div class=\"service-img\">\r\n                                                        <img src=\"assets/img/saloon-2.jpg\" class=\"img-responsive\">\r\n                                                    </div>\r\n                                                </div>\r\n                                                <div class=\"col-lg-7 col-md-7 col-sm-7 col-xs-12\">\r\n                                                    <div class=\"service-inner-des\">\r\n                                                        <h5 class=\"name-saloon\">\r\n                                                            <a href=\"javascript:void(0);\">Bebe Beauty Salon (Ledies)</a>\r\n                                                        </h5>\r\n                                                        <address>9566 Destiny USA Dr E208, Syracuse, NY 13290, USA</address>\r\n                                                        <ul class=\"rating-points\">\r\n                                                            <li>\r\n                                                                <span class=\"rating-star\">\r\n                                                                    <i class=\"fa fa-star\"></i>\r\n                                                                    <i class=\"fa fa-star\"></i>\r\n                                                                    <i class=\"fa fa-star\"></i>\r\n                                                                    <i class=\"fa fa-star\"></i>\r\n                                                                    <i class=\"fa fa-star-half-o\"></i>\r\n                                                                </span>\r\n                                                                <span class=\"star-number\">(100)</span>\r\n                                                            </li>\r\n                                                            <li>\r\n                                                                <span class=\"dollor-select\">\r\n                                                                    <span class=\"card-check\">\r\n                                                                        <i class=\"fa fa-credit-card\"></i>\r\n                                                                        <p><i class=\"fa fa-check-circle\"></i></p>\r\n                                                                    </span>\r\n                                                                    <ul class=\"dollor-view\">\r\n                                                                        <li class=\"active\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li class=\"\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li>\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li>\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                    </ul>\r\n                                                                </span>\r\n                                                            </li>\r\n                                                        </ul>\r\n                                                        <p class=\"description-salon\">\r\n                                                            Sasha Beauty Salon is not a name unheard of in the Dubai beauty scene. With a chain of world class salons and only the very best quality of services, Sasha beauty is a name associated with reliable beauty care. The salon has an extensive...\r\n                                                            <a href=\"javascript:void(0);\">Read More</a>\r\n                                                        </p>    \r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"esact-service salon-sec\">\r\n                                                <p class=\"popular-service\">Popular Services</p>\r\n                                                <div class=\"searched-service relevant-de\">\r\n                                                    <ul class=\"searched-ul \">\r\n                                                        <li>\r\n                                                            <span class=\"service-name\">\r\n                                                                Extension Removal by Piece(Form another salon)\r\n                                                                <span class=\"time-on\"><i class=\"fa fa-clock-o\"></i> 15 Min</span>\r\n                                                            </span>\r\n                                                            <span class=\"price-and-book\">\r\n                                                                <span class=\"price-nub\">AED 10\r\n                                                                </span>\r\n                                                                <span class=\"book-btn\">\r\n                                                                    <a class=\"btn cus-btn\" href=\"javascript:void(0);\">Book</a>\r\n                                                                </span>\r\n                                                            </span>\r\n                                                        </li>\r\n                                                    </ul>\r\n                                                </div>\r\n                                                <div class=\"searched-service relevant-de\">\r\n                                                    <ul class=\"searched-ul\">\r\n                                                        <li>\r\n                                                            <span class=\"service-name\">\r\n                                                                Hair Cut\r\n                                                                <span class=\"time-on\"><i class=\"fa fa-clock-o\"></i> 1h 15 Min</span>\r\n                                                            </span>\r\n                                                            <span class=\"price-and-book\">\r\n                                                                <span class=\"price-nub\">AED 125\r\n                                                                </span>\r\n                                                                <span class=\"book-btn\">\r\n                                                                    <a class=\"btn cus-btn\" href=\"javascript:void(0);\">Book</a>\r\n                                                                </span>\r\n                                                            </span>\r\n                                                        </li>\r\n                                                    </ul>\r\n                                                </div>\r\n                                                <div class=\"searched-service relevant-de2\">\r\n                                                    <ul class=\"searched-ul\">\r\n                                                        <li>\r\n                                                            <span class=\"service-name\">\r\n                                                                Hair Trim\r\n                                                                <span class=\"time-on\"><i class=\"fa fa-clock-o\"></i> 15 Min</span>\r\n                                                            </span>\r\n                                                            <span class=\"price-and-book\">\r\n                                                                <span class=\"price-nub\">AED 80\r\n                                                                </span>\r\n                                                                <span class=\"book-btn\">\r\n                                                                    <a class=\"btn cus-btn\" href=\"javascript:void(0);\">Book</a>\r\n                                                                </span>\r\n                                                            </span>\r\n                                                        </li>\r\n                                                    </ul>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"wrap-service\">\r\n                                            <div class=\"img-content-sec\">\r\n                                                <div class=\"col-lg-5 col-md-5 col-sm-5 col-xs-12 p-l-0\">\r\n                                                    <div class=\"service-img\">\r\n                                                        <img src=\"assets/img/saloon-3.jpg\" class=\"img-responsive\">\r\n                                                    </div>\r\n                                                </div>\r\n                                                <div class=\"col-lg-7 col-md-7 col-sm-7 col-xs-12\">\r\n                                                    <div class=\"service-inner-des\">\r\n                                                        <h5 class=\"name-saloon\">\r\n                                                            <a href=\"javascript:void(0);\">Morning Glory Health & Beauty Salon</a>\r\n                                                        </h5>\r\n                                                        <address>9566 Destiny USA Dr E208, Syracuse, NY 13290, USA</address>\r\n                                                        <ul class=\"rating-points\">\r\n                                                            <li>\r\n                                                                <span class=\"rating-star\">\r\n                                                                    <i class=\"fa fa-star\"></i>\r\n                                                                    <i class=\"fa fa-star\"></i>\r\n                                                                    <i class=\"fa fa-star\"></i>\r\n                                                                    <i class=\"fa fa-star\"></i>\r\n                                                                    <i class=\"fa fa-star-half-o\"></i>\r\n                                                                </span>\r\n                                                                <span class=\"star-number\">(216)</span>\r\n                                                            </li>\r\n                                                            <li>\r\n                                                                <span class=\"dollor-select\">\r\n                                                                    <span class=\"card-check\">\r\n                                                                        <i class=\"fa fa-credit-card\"></i>\r\n                                                                        <p><i class=\"fa fa-check-circle\"></i></p>\r\n                                                                    </span>\r\n                                                                    <ul class=\"dollor-view\">\r\n                                                                        <li class=\"active\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li class=\"active\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li class=\"active\">\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                        <li>\r\n                                                                            <i class=\"fa fa-usd\"></i>\r\n                                                                        </li>\r\n                                                                    </ul>\r\n                                                                </span>\r\n                                                            </li>\r\n                                                        </ul>\r\n                                                        <p class=\"description-salon\">\r\n                                                            Sasha Beauty Salon is not a name unheard of in the Dubai beauty scene. With a chain of world class salons and only the very best quality of services, Sasha beauty is a name associated with reliable beauty care. The salon has an extensive...\r\n                                                            <a href=\"javascript:void(0);\">Read More</a>\r\n                                                        </p>    \r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"esact-service salon-sec\">\r\n                                                <p class=\"popular-service\">Popular Services</p>\r\n                                                <div class=\"searched-service relevant-de\">\r\n                                                    <ul class=\"searched-ul \">\r\n                                                        <li>\r\n                                                            <span class=\"service-name\">\r\n                                                                Bridal Up Style (In Salon)\r\n                                                                <span class=\"time-on\"><i class=\"fa fa-clock-o\"></i> 1h</span>\r\n                                                            </span>\r\n                                                            <span class=\"price-and-book\">\r\n                                                                <span class=\"price-nub\">AED 1,500\r\n                                                                </span>\r\n                                                                <span class=\"book-btn\">\r\n                                                                    <a class=\"btn cus-btn\" href=\"javascript:void(0);\">Book</a>\r\n                                                                </span>\r\n                                                            </span>\r\n                                                        </li>\r\n                                                    </ul>\r\n                                                </div>\r\n                                                <div class=\"searched-service relevant-de\">\r\n                                                    <ul class=\"searched-ul\">\r\n                                                        <li>\r\n                                                            <span class=\"service-name\">\r\n                                                                Bridal Makeup (In Salon)\r\n                                                                <span class=\"time-on\"><i class=\"fa fa-clock-o\"></i> 2h</span>\r\n                                                            </span>\r\n                                                            <span class=\"price-and-book\">\r\n                                                                <span class=\"price-nub\">AED 1,500\r\n                                                                </span>\r\n                                                                <span class=\"book-btn\">\r\n                                                                    <a class=\"btn cus-btn\" href=\"javascript:void(0);\">Book</a>\r\n                                                                </span>\r\n                                                            </span>\r\n                                                        </li>\r\n                                                    </ul>\r\n                                                </div>\r\n                                                <div class=\"searched-service relevant-de2\">\r\n                                                    <ul class=\"searched-ul\">\r\n                                                        <li>\r\n                                                            <span class=\"service-name\">\r\n                                                            Moroccan Bath with Massage\r\n                                                                <span class=\"time-on\"><i class=\"fa fa-clock-o\"></i> 60 Min</span>\r\n                                                            </span>\r\n                                                            <span class=\"price-and-book\">\r\n                                                                <span class=\"price-nub\">AED 199\r\n                                                                </span>\r\n                                                                <span class=\"book-btn\">\r\n                                                                    <a class=\"btn cus-btn\" href=\"javascript:void(0);\">Book</a>\r\n                                                                </span>\r\n                                                            </span>\r\n                                                        </li>\r\n                                                    </ul>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div> -->\r\n                                    </div>\r\n                                </div> \r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/searched-saloon/searched-saloon.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".example-h2 {\n  margin: 10px; }\n\n.example-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-line-pack: center;\n      align-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 60px; }\n\n.example-margin {\n  margin: 10px; }\n\n.mat-slider-horizontal {\n  width: 300px; }\n\n.mat-slider-vertical {\n  height: 300px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/searched-saloon/searched-saloon.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SearchedSaloonComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs_observable_forkJoin__ = __webpack_require__("../../../../rxjs/_esm5/observable/forkJoin.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__models_saloon_modal__ = __webpack_require__("../../../../../src/app/models/saloon.modal.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__providers_app_provider__ = __webpack_require__("../../../../../src/app/providers/app.provider.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var SearchedSaloonComponent = (function () {
    function SearchedSaloonComponent(router, saloonServices, vcr, toastr, commonService, appProvider) {
        this.router = router;
        this.saloonServices = saloonServices;
        this.toastr = toastr;
        this.commonService = commonService;
        this.appProvider = appProvider;
        this.saloonDetailsModel = new __WEBPACK_IMPORTED_MODULE_5__models_saloon_modal__["b" /* SaloonDetailsModel */]();
        this.accountCreationModel = new __WEBPACK_IMPORTED_MODULE_5__models_saloon_modal__["a" /* AccountCreationModel */]();
        this.verifiactionModel = new __WEBPACK_IMPORTED_MODULE_5__models_saloon_modal__["c" /* VerifiactionModel */]();
        this.serviceList = [];
        this.afterFilterSaloon = [];
        this.autoTicks = false;
        this.disabled = false;
        this.invert = false;
        this.max = 100;
        this.min = 0;
        this.showTicks = false;
        this.step = 1;
        this.thumbLabel = false;
        this.value = 0;
        this.vertical = false;
        this._tickInterval = 1;
        this.filter = {};
        this.toastr.setRootViewContainerRef(vcr);
    }
    Object.defineProperty(SearchedSaloonComponent.prototype, "tickInterval", {
        get: function () {
            return this.showTicks ? (this.autoTicks ? 'auto' : this._tickInterval) : 0;
        },
        set: function (v) {
            this._tickInterval = Number(v);
        },
        enumerable: true,
        configurable: true
    });
    SearchedSaloonComponent.prototype.ngOnInit = function () {
        //alert(this.appProvider.current.serviceSearched)
        $(window).scroll(function () {
            if ($(this).scrollTop() > 1) {
                $('header').addClass("sticky");
            }
            else {
                $('header').removeClass("sticky");
            }
        });
        // 	var wow = new WOW(
        // 	        {
        // 	            animateClass: 'animated',
        // 	            offset:       100,
        // 	            callback:     function(box) {
        // 	                console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        // 	            }
        // 	        }
        // 	    );
        // wow.init();
        // 	$(window).load(function() {
        // 	        $(".datetimepicker1");
        // 	    });
        // 	$('.datetimepicker1').datetimepicker({
        // 	        //lang:'ch',
        // 	         //yearOffset:200,       
        // 	        timepicker:false,
        // 	        format:'d-m-Y',
        // 	        formatDate:'d-m-Y',
        // 	        value:'Enter Date',
        // 	        step:10,
        // 	        minDate:'+1d',
        // 	        scrollMonth:false,
        // 	        scrollTime:false,
        // 	        scrollInput:true,
        // 	    });
        // 	var mySlider = $("#rane-slide").slider({
        // 	        'tooltip':'hide'
        // 	    });
        // 	    // Cal l a method on the slider
        // 	    mySlider.on('change',function(){
        // 	        var value = mySlider.slider('getValue');
        // 	        $('.min-range').html('<b>$'+value[0]+'</b>');
        // 	        $('.max-range').html('<b>$'+value[1]+'</b>');
        // 	    });
        this.getserviceList();
    };
    SearchedSaloonComponent.prototype.getserviceList = function () {
        var _this = this;
        this.saloonList = [];
        this.waitLoader = true;
        this.commonService.getAllSaloonList();
        Object(__WEBPACK_IMPORTED_MODULE_3_rxjs_observable_forkJoin__["a" /* forkJoin */])([this.commonService.getAllSaloonList(), this.commonService.getServices()])
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            console.log(data);
            if (data[0].response) {
                if (_this.appProvider.current.selectedCity) {
                    //alert(this.appProvider.current.selectedCity)
                    //this.saloonList=this.saloonList.concat(data[0].data.slice(0));
                    _this.saloonListBackup1 = data[0].data.filter(function (arg) { return arg.city.includes(_this.appProvider.current.selectedCity) == true; });
                    _this.saloonListBackup2 = data[0].data.filter(function (arg) { return arg.city.includes(_this.appProvider.current.selectedCity) == true; });
                    // alert('hiiii')
                    _this.saloonList = _this.saloonListBackup1.filter(function (arg) { return arg.city.includes(_this.appProvider.current.selectedCity) == true; });
                }
                else {
                    //this.saloonList=this.saloonList.concat(data[0].data.slice(0));
                    _this.saloonListBackup1 = data[0].data.slice(0);
                    _this.saloonListBackup2 = data[0].data.slice(0);
                    // alert('hiiii')
                    _this.saloonList = data[0].data.slice(0);
                }
            }
            if (data[1].response) {
                _this.serviceList = data[1].data;
            }
        });
    };
    SearchedSaloonComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.221.208.210/public/beauty-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    SearchedSaloonComponent.prototype.getTime = function (time) {
        var a;
        switch (time) {
            case "15":
                a = '15 Min';
                //alert(a)
                return a;
            case "30":
                a = '30 Min';
                return a;
            case "45":
                a = '45 Min';
                return a;
            case "60":
                a = '1 Hr';
                return a;
            case "75":
                a = '1 Hr 15 Min';
                return a;
            case "90":
                a = '1 Hr 30 Min';
                return a;
            case "105":
                a = '1 Hr 45 Min';
                return a;
            case "120":
                a = '2 Hr';
                return a;
            case "135":
                a = '2 Hr 15 Mi';
                return a;
            case "150":
                a = '2 Hr 30 Min';
                return a;
            case "165":
                a = '2 Hr 45 Min';
                return a;
            case "180":
                a = '3 Hr';
                return a;
            default:
                0;
                // alert(a)
                return a;
        }
    };
    SearchedSaloonComponent.prototype.getClass = function (name) {
        if (this.appProvider.current.serviceSearched == name) {
            return '';
        }
        else {
            return 'relevant-de';
        }
    };
    SearchedSaloonComponent.prototype.getRatingClass = function (rating, flag) {
        var count = 0;
        var avg = 0;
        for (var i = 0; i < rating.length; ++i) {
            // code...rating
            if (rating[i].rating) {
                // code...
                count = count + parseInt(rating[i].rating);
            }
        }
        avg = count / rating.length;
        if (flag == 1) {
            if (avg < 1) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
        else if (flag == 2) {
            if (avg < 2) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
        else if (flag == 3) {
            if (avg < 3) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
        else if (flag == 4) {
            if (avg < 4) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
        else if (flag == 5) {
            if (avg < 5) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
    };
    SearchedSaloonComponent.prototype.findRangclass = function (rang, flag) {
        if (flag == 1) {
            if (parseInt(rang) >= flag) {
                return 'active';
            }
        }
        else if (flag == 2) {
            if (parseInt(rang) >= flag) {
                return 'active';
            }
        }
        else if (flag == 3) {
            if (parseInt(rang) >= flag) {
                return 'active';
            }
        }
        else if (flag == 4) {
            if (parseInt(rang) >= flag) {
                return 'active';
            }
        }
    };
    SearchedSaloonComponent.prototype.unique = function (array) {
        return array.filter(function (el, index, arr) {
            return index == arr.indexOf(el);
        });
    };
    SearchedSaloonComponent.prototype.onFirst = function (status) {
        if (status == true) {
            var data = this.saloonListBackup1.filter(function (arg) { return arg.price_range == '1'; });
            this.afterFilterSaloon = this.afterFilterSaloon.concat(data);
            this.saloonList = this.unique(this.afterFilterSaloon);
            this.saloonList = this.unique(this.saloonList);
        }
        else {
            this.saloonList = this.saloonList.filter(function (arg) { return arg.price_range != '1'; });
            this.afterFilterSaloon = this.afterFilterSaloon.filter(function (arg) { return arg.price_range != '1'; });
        }
    };
    SearchedSaloonComponent.prototype.onSecond = function (status) {
        if (status == true) {
            var data = this.saloonListBackup1.filter(function (arg) { return arg.price_range == '2'; });
            this.afterFilterSaloon = this.afterFilterSaloon.concat(data);
            this.saloonList = this.unique(this.afterFilterSaloon);
            this.saloonList = this.unique(this.saloonList);
        }
        else {
            this.saloonList = this.saloonList.filter(function (arg) { return arg.price_range != '2'; });
            this.afterFilterSaloon = this.afterFilterSaloon.filter(function (arg) { return arg.price_range != '2'; });
        }
    };
    SearchedSaloonComponent.prototype.onThird = function (status) {
        if (status == true) {
            var data = this.saloonListBackup1.filter(function (arg) { return arg.price_range == '3'; });
            this.afterFilterSaloon = this.afterFilterSaloon.concat(data);
            this.saloonList = this.unique(this.afterFilterSaloon);
            this.saloonList = this.unique(this.saloonList);
        }
        else {
            this.saloonList = this.saloonList.filter(function (arg) { return arg.price_range != '3'; });
            this.afterFilterSaloon = this.afterFilterSaloon.filter(function (arg) { return arg.price_range != '3'; });
        }
    };
    SearchedSaloonComponent.prototype.onFourth = function (status) {
        if (status == true) {
            var data = this.saloonListBackup1.filter(function (arg) { return arg.price_range == '4'; });
            this.afterFilterSaloon = this.afterFilterSaloon.concat(data);
            this.saloonList = this.unique(this.afterFilterSaloon);
            this.saloonList = this.unique(this.saloonList);
        }
        else {
            this.saloonList = this.saloonList.filter(function (arg) { return arg.price_range != '4'; });
            this.afterFilterSaloon = this.afterFilterSaloon.filter(function (arg) { return arg.price_range != '4'; });
        }
    };
    SearchedSaloonComponent.prototype.onService = function (checkStatus, id) {
        var _this = this;
        if (checkStatus == true) {
            var data = this.saloonListBackup1.filter(function (arg) { return _this.checkIndex(arg, id) == true; });
            this.afterFilterSaloon = this.afterFilterSaloon.concat(data);
            this.saloonList = this.unique(this.afterFilterSaloon);
            this.saloonList = this.unique(this.saloonList);
        }
        else {
            this.saloonList = this.saloonList.filter(function (arg) { return _this.checkIndex2(arg, id) == true; });
            this.afterFilterSaloon = this.afterFilterSaloon.filter(function (arg) { return _this.checkIndex2(arg, id) == true; });
        }
    };
    // this.filterDist.map(function (img) { return img.name; }).indexOf(this.selectedDist[i])==-1)
    SearchedSaloonComponent.prototype.checkIndex = function (arg, id) {
        if (arg.saloonServices.length > 0) {
            if (arg.saloonServices.map(function (img) { return +img.service_id; }).indexOf(id) != -1) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    };
    SearchedSaloonComponent.prototype.checkIndex2 = function (arg, id) {
        if (arg.saloonServices.length > 0) {
            if (arg.saloonServices.map(function (img) { return +img.service_id; }).indexOf(id) != -1) {
                return false;
            }
            else {
                return true;
            }
        }
    };
    SearchedSaloonComponent.prototype.onClearAll = function () {
        this.filter.first = false;
        this.filter.two = false;
        this.filter.three = false;
        this.filter.four = false;
        for (var i = 0; i < this.serviceList.length; ++i) {
            this.serviceList[i].checkStatus = false;
        }
        this.saloonList = this.saloonListBackup2.slice(0);
    };
    SearchedSaloonComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-searched-saloon',
            template: __webpack_require__("../../../../../src/app/header-two-layout/searched-saloon/searched-saloon.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/searched-saloon/searched-saloon.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */],
            __WEBPACK_IMPORTED_MODULE_4__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_6__providers_common_service__["a" /* CommonService */],
            __WEBPACK_IMPORTED_MODULE_7__providers_app_provider__["a" /* AppProvider */]])
    ], SearchedSaloonComponent);
    return SearchedSaloonComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/searched-saloon/searched-saloon.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchedSaloonModule", function() { return SearchedSaloonModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_material__ = __webpack_require__("../../../material/esm5/material.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__searched_saloon_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/searched-saloon/searched-saloon-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__searched_saloon_component__ = __webpack_require__("../../../../../src/app/header-two-layout/searched-saloon/searched-saloon.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var SearchedSaloonModule = (function () {
    function SearchedSaloonModule() {
    }
    SearchedSaloonModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_6__searched_saloon_routing_module__["a" /* SearchedSaloonRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_common_http__["b" /* HttpClientModule */], __WEBPACK_IMPORTED_MODULE_4__angular_material__["c" /* MatSliderModule */],
                __WEBPACK_IMPORTED_MODULE_3_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_5__angular_forms__["j" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_forms__["e" /* FormsModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_7__searched_saloon_component__["a" /* SearchedSaloonComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_8__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_9__providers_common_service__["a" /* CommonService */]],
        })
    ], SearchedSaloonModule);
    return SearchedSaloonModule;
}());



/***/ })

});
//# sourceMappingURL=searched-saloon.module.chunk.js.map