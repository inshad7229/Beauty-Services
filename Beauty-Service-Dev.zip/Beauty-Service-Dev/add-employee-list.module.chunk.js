webpackJsonp(["add-employee-list.module"],{

/***/ "../../../../../src/app/header-three-layout/add-employee-list/add-employee-list-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AddEmployeeListRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__add_employee_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/add-employee-list/add-employee-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__add_employee_list_component__["a" /* AddEmployeeListComponent */]
    }
];
var AddEmployeeListRoutingModule = (function () {
    function AddEmployeeListRoutingModule() {
    }
    AddEmployeeListRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], AddEmployeeListRoutingModule);
    return AddEmployeeListRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/add-employee-list/add-employee-list.component.html":
/***/ (function(module, exports) {

module.exports = "\r\n <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n         <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n </div>\r\n<div class=\"page-content-wrapper\">\r\n\t\t\t\t<div class=\"page-content\">\r\n\t\t\t\t\t<ul class=\"page-breadcrumb breadcrumb hide\">\r\n\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t<a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<li class=\"active\">\r\n\t\t\t\t\t\t\t Dashboard\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t\t<!-- BEGIN PAGE CONTENT INNER -->\r\n\t\t\t\t\t<div class=\"emp-list-sec\">\r\n\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 p-0\">\r\n\t\t\t\t\t\t\t<!-- BEGIN PORTLET-->\r\n\t\t\t\t\t\t\t<div class=\"booking-section\">\r\n\t\t\t\t\t\t\t\t<div class=\"portlet light\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-title\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"caption caption-md\">\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"caption-subject theme-font-color bold uppercase\">Add Employee</span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-body\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"add-emp-form\">\r\n\t\t\t\t\t\t\t\t            \t<form class=\"add-empform\" [formGroup]=\"addEmployeeForm\">\r\n\t\t\t\t\t\t\t            \t\t\t<div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t\t\t\t\t\t\t            \t\t\t\t<div class=\"row add-emppic\">\r\n\t\t\t\t\t                                        <div class=\"col-md-offset-3 col-md-6 col-sm-6 col-xs-12 text-center\">\r\n\t\t\t\t\t                                            <div class=\"form-group custom-upload\">\r\n\t\t\t\t\t                                                <div class=\"file-previewimg\">\r\n\t\t\t\t\t                                                     <img *ngIf=\"!addEmployee.employee_image\" src=\"assets/img/no-img.png\" class=\"img-responsive\" alt=\"NO-IMAGES\">\r\n\t\t\t\t\t\t\t\t                            \t\t\t<img *ngIf=\"addEmployee.employee_image\" [src]=\"imagePath(addEmployee.employee_image)\" >\r\n\t\t\t\t\t                                                </div>\r\n\t\t\t\t\t                                                <div class=\"profile-upload\">\r\n\t\t\t\t\t                                                    <div class=\"input-btn\">\r\n\t\t\t\t\t                                                        <input type=\"file\" (change)=\"imageUploadEvent($event)\" accept=\"image/gif, image/jpeg, image/png\" />\r\n\t\t\t\t\t                                                        <button class=\"btn cus-btn\"> \r\n\t\t\t\t\t                                                        <i class=\"fa fa-file-image-o\"></i> Employee Image</button>\r\n\t\t\t\t\t                                                    </div>\r\n\t\t\t\t\t                                                </div>\r\n\t\t\t\t\t                                            </div>\r\n\t\t\t\t\t                                        </div>\r\n\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t\t            \t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>Employee First Name In English<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Employee First Name In English\" class=\"form-control\" [formControl]=\"addEmployeeForm.controls['firstNameEng']\" [(ngModel)]=\"addEmployee.first_name\">\r\n\t\t\t\t\t\t\t                                        <p  *ngIf=\"addEmployeeForm.controls['firstNameEng'].hasError('required') && addEmployeeForm.controls['firstNameEng'].touched\">\r\n\t\t\t\t\t                                                      Employee First Name In English is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['firstNameEng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['firstNameEng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p> \r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>Employee First Name In Arabic<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Employee First Name In Arabic\" class=\"form-control\" [formControl]=\"addEmployeeForm.controls['firstNameArb']\" [(ngModel)]=\"addEmployee.first_name_arb\">\r\n\t\t\t\t\t\t                                         <p  *ngIf=\"addEmployeeForm.controls['firstNameArb'].hasError('required') && addEmployeeForm.controls['firstNameArb'].touched\">\r\n\t\t\t\t\t                                                     Employee First Name In Arabic is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['firstNameArb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['firstNameArb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>Employee Last Name In English<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Employee Last Name In English\" class=\"form-control\" [formControl]=\"addEmployeeForm.controls['lastNameEng']\" [(ngModel)]=\"addEmployee.last_name\">\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addEmployeeForm.controls['lastNameEng'].hasError('required') && addEmployeeForm.controls['lastNameEng'].touched\">\r\n\t\t\t\t\t                                                     Employee Last Name In English is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['lastNameEng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['lastNameEng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>Employee Last Name In Arabic<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Employee First Name In Arabic\" class=\"form-control\" [formControl]=\"addEmployeeForm.controls['lastNameArb']\" [(ngModel)]=\"addEmployee.last_name_arb\">\r\n\t\t\t\t\t\t                                         <p  *ngIf=\"addEmployeeForm.controls['lastNameArb'].hasError('required') && addEmployeeForm.controls['lastNameArb'].touched\">\r\n\t\t\t\t\t                                                     Employee Last Name In Arabic is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['lastNameArb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['lastNameArb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>Contact Number<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"text\" placeholder=\"Enter Number\" class=\"form-control\" [formControl]=\"addEmployeeForm.controls['contactNumber']\" [(ngModel)]=\"addEmployee.contact_number\">\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addEmployeeForm.controls['contactNumber'].hasError('required') && addEmployeeForm.controls['contactNumber'].touched\">\r\n\t\t\t\t\t                                                     Contact Number is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['contactNumber'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['contactNumber'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 12\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>Email <small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                        <input type=\"email\" placeholder=\"Enter Employee Email\" class=\"form-control\" [formControl]=\"addEmployeeForm.controls['email']\" [(ngModel)]=\"addEmployee.email\">\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addEmployeeForm.controls['email'].hasError('required') && addEmployeeForm.controls['email'].touched\">\r\n\t\t\t\t\t                                                    Email is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['email'].hasError('pattern')\">\r\n\t\t\t\t\t                                                          Enter Valid email id\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['email'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>Select Gender<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t                                            <div class=\"custom-radio\">\r\n\t\t\t\t\t                                                <div class=\"radio-inline\">\r\n\t\t\t\t\t                                                    <input type=\"radio\" value=\"male\" id=\"radio01\" name=\"radio\"  [formControl]=\"addEmployeeForm.controls['gender']\" [(ngModel)]=\"addEmployee.gender\" >\r\n\t\t\t\t\t                                                    <label for=\"radio01\">\r\n\t\t\t\t\t                                                        <span><span></span></span>Male\r\n\t\t\t\t\t                                                    </label>\r\n\t\t\t\t\t                                                </div>\r\n\t\t\t\t\t                                                <div class=\"radio-inline\">\r\n\t\t\t\t\t                                                    <input type=\"radio\" value=\"female\" id=\"radio02\" name=\"radio\"  [formControl]=\"addEmployeeForm.controls['gender']\" [(ngModel)]=\"addEmployee.gender\">\r\n\t\t\t\t\t                                                    <label for=\"radio02\">\r\n\t\t\t\t\t                                                        <span><span></span></span>Female\r\n\t\t\t\t\t                                                    </label>\r\n\t\t\t\t\t                                                </div>\r\n\t\t\t\t\t                                            </div>\r\n\t\t\t\t\t                                            <p  *ngIf=\"addEmployeeForm.controls['gender'].hasError('required') && addEmployeeForm.controls['gender'].touched\">\r\n\t\t\t\t\t                                                    Gender is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['gender'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['gender'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                     <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>Select Employee Services<small class=\"manidatory\">*</small></label>\r\n\t\t\t\t\t\t                                         <div class=\"custom-select\">\r\n\t\t                                                             <ss-multiselect-dropdown [options]=\"myOptions2\" [(ngModel)]=\"optionsModel2\" (ngModelChange)=\"onChange2($event)\" [formControl]=\"addEmployeeForm.controls['services']\" ></ss-multiselect-dropdown>\r\n\t\t                                                        </div>\r\n\t\t                                                        <p  *ngIf=\"addEmployeeForm.controls['services'].hasError('required') && addEmployeeForm.controls['services'].touched\">\r\n\t\t\t\t\t                                                    Employee Services is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['services'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['services'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 100\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>\r\n\t\t\t\t\t\t                                        \tEnter Employee Details in English <small class=\"manidatory\">*</small>\r\n\t\t\t\t\t\t                                        </label>\r\n\t\t\t\t\t\t                                        <textarea class=\"cus-textarea form-control\" col=\"8\" rows=\"10\" [formControl]=\"addEmployeeForm.controls['detailsEng']\" [(ngModel)]=\"addEmployee.details\"></textarea>\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addEmployeeForm.controls['detailsEng'].hasError('required') && addEmployeeForm.controls['detailsEng'].touched\">\r\n\t\t\t\t\t                                                    Employee Details English is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['detailsEng'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['detailsEng'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 1000\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                 <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t                                        <label>\r\n\t\t\t\t\t\t                                        \tEnter Employee Details in Arabic <small class=\"manidatory\">*</small>\r\n\t\t\t\t\t\t                                        </label>\r\n\t\t\t\t\t\t                                        <textarea class=\"cus-textarea form-control\" col=\"8\" rows=\"10\" [formControl]=\"addEmployeeForm.controls['detailsArb']\" [(ngModel)]=\"addEmployee.details_arb\"></textarea>\r\n\t\t\t\t\t\t                                        <p  *ngIf=\"addEmployeeForm.controls['detailsArb'].hasError('required') && addEmployeeForm.controls['detailsArb'].touched\">\r\n\t\t\t\t\t                                                    Employee Details Arabic is <strong>required</strong>\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['detailsArb'].hasError('pattern')\">\r\n\t\t\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t                                                <p  *ngIf=\"addEmployeeForm.controls['detailsArb'].hasError('maxlength')\">\r\n\t\t\t\t\t                                                           max length is 1000\r\n\t\t\t\t\t                                                </p>\r\n\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"row\">\r\n\t\t\t\t\t\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t                                \t\t<label>\r\n\t\t\t\t\t\t                                        \tUpload Employee Id <small class=\"manidatory\">*</small>\r\n\t\t\t\t\t\t                                        </label>\r\n\t\t\t\t\t\t                                \t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n\t\t\t\t\t\t                                \t\t\t<div class=\"row add-emppic\">\r\n\t\t\t\t\t\t\t                                            <div class=\"form-group custom-upload\">\r\n\t\t\t\t\t\t\t                                                <div class=\"file-previewimg\">\r\n\t\t\t\t\t\t\t                                                     <img *ngIf=\"!addEmployee.employee_Ids\" src=\"assets/img/no-img.png\" class=\"img-responsive\" alt=\"NO-IMAGES\">\r\n\t\t\t\t\t\t\t\t\t\t                            \t\t\t<img *ngIf=\"addEmployee.employee_Ids\" [src]=\"imagePath(addEmployee.employee_Ids)\" >\r\n\t\t\t\t\t\t\t                                                </div>\r\n\t\t\t\t\t\t\t                                                <div class=\"profile-upload\">\r\n\t\t\t\t\t\t\t                                                    <div class=\"input-btn\">\r\n\t\t\t\t\t\t\t                                                        <input type=\"file\"  (change)=\"idUploadEvent($event)\" value=\"demo\" />\r\n\t\t\t\t\t\t\t                                                        <button class=\"btn cus-btn\"> \r\n\t\t\t\t\t\t\t                                                        <i class=\"fa fa-address-card\"></i> Upload Id</button>\r\n\t\t\t\t\t\t\t                                                    </div>\r\n\t\t\t\t\t\t\t                                                    \r\n\t\t\t\t\t\t\t                                                </div>\r\n\t\t\t\t\t\t\t                                            </div>\r\n\t\t\t\t\t\t\t\t                                    </div>\r\n\t\t\t\t\t\t                                \t\t</div>\r\n\t\t\t\t\t\t                                \t</div>\r\n\t\t\t\t\t\t                                </div>\r\n\t\t\t\t\t\t                                <div class=\"modal-footerbtn\">\r\n\t\t\t\t\t\t\t\t\t\t\t          \t\t<span class=\"back-bt\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t\t<button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\">Cancel</button>\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t</span>\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t<span class=\"save-bt\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t\t<!-- <button type=\"button\" class=\"btn cut-btn\">Save</button> -->\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t\t<button href=\"saloon-employee-list.php\" class=\"btn cut-btn\" [disabled]=\"!addEmployeeForm.valid\" (click)=\"AddEmployee()\">Save</button>\r\n\t\t\t\t\t\t\t\t\t\t\t\t          \t</span>\r\n\t\t\t\t\t\t\t\t\t\t\t          \t</div>\r\n\t\t\t\t\t\t\t            \t\t\t</div>\r\n\t\t\t\t\t\t\t\t            \t</form>\r\n\t\t\t\t\t\t\t\t            </div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<!-- END PORTLET-->\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<!-- END PAGE CONTENT INNER -->\r\n\t\t\t\t</div>\r\n\t\t\t</div>"

/***/ }),

/***/ "../../../../../src/app/header-three-layout/add-employee-list/add-employee-list.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-three-layout/add-employee-list/add-employee-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AddEmployeeListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__models_employee__ = __webpack_require__("../../../../../src/app/models/employee.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var AddEmployeeListComponent = (function () {
    function AddEmployeeListComponent(router, fb, vcr, toastr, translate, saloonServices, commonServices) {
        this.router = router;
        this.fb = fb;
        this.toastr = toastr;
        this.translate = translate;
        this.saloonServices = saloonServices;
        this.commonServices = commonServices;
        this.userDetail = JSON.parse(localStorage['userdetails']);
        this.addEmployee = new __WEBPACK_IMPORTED_MODULE_5__models_employee__["a" /* AddEmployee */]();
        this.serviceList = [];
        this.toastr.setRootViewContainerRef(vcr);
        this.addEmployeeForm = fb.group({
            'firstNameEng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'firstNameArb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'lastNameEng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'lastNameArb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'contactNumber': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(12)])],
            'email': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100), __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].pattern(EMAIL_REGEX)])],
            'gender': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'services': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(100)])],
            'detailsEng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(1000)])],
            'detailsArb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["k" /* Validators */].maxLength(1000)])],
        });
    }
    AddEmployeeListComponent.prototype.ngOnInit = function () {
        this.myOptions2 = [
            { id: 1, name: 'Option 1' },
            { id: 2, name: 'Option 2' },
            { id: 3, name: 'Option 3' },
            { id: 4, name: 'Option 4' },
            { id: 5, name: 'Option 5' },
            { id: 6, name: 'Option 6' },
        ];
        this.getserviceList();
    };
    AddEmployeeListComponent.prototype.onChange2 = function () {
        console.log(this.optionsModel2);
    };
    AddEmployeeListComponent.prototype.AddEmployee = function () {
        var _this = this;
        this.waitLoader = true;
        var a = this.optionsModel2.slice(0);
        this.addEmployee.saloon_id = this.userDetail.id;
        this.addEmployee.services = a.toString();
        this.saloonServices.AddEmployee(this.addEmployee)
            .subscribe(function (data) {
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.toastr.success(data.message, 'Employee Registration', { toastLife: 1000, showCloseButton: true });
                _this.router.navigate(['/header-three-layout/saloon-employee-list']);
            }
            else if (data.message == 'Unable to update Password') {
                _this.toastr.error('Unable to update Password', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else if (data.message == 'email Id already register with same saloon') {
                _this.toastr.error('email Id already register with same saloon', 'Employee Registration Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Employee Registration Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    AddEmployeeListComponent.prototype.getserviceList = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonServices.getservicesById(this.userDetail.id)
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.serviceList = data.data;
                for (var i = 0; i < _this.serviceList.length; ++i) {
                    list.push({ id: _this.serviceList[i].servicesData.id, name: _this.serviceList[i].servicesData.services_eng });
                }
                _this.myOptions2 = list;
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    AddEmployeeListComponent.prototype.imageUploadEvent = function (evt) {
        var _this = this;
        if (!evt.target) {
            return;
        }
        if (!evt.target.files) {
            return;
        }
        if (evt.target.files.length !== 1) {
            return;
        }
        var file = evt.target.files[0];
        if (file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif' && file.type !== 'image/jpg') {
            return;
        }
        var fr = new FileReader();
        fr.onloadend = function (loadEvent) {
            _this.addEmployee.employee_image = fr.result;
            console.log(_this.addEmployee.employee_image);
        };
        fr.readAsDataURL(file);
    };
    AddEmployeeListComponent.prototype.idUploadEvent = function (evt) {
        var _this = this;
        if (!evt.target) {
            return;
        }
        if (!evt.target.files) {
            return;
        }
        if (evt.target.files.length !== 1) {
            return;
        }
        var file = evt.target.files[0];
        // if (file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif' && file.type !== 'image/jpg') {
        //     return;
        // }
        var fr = new FileReader();
        fr.onloadend = function (loadEvent) {
            _this.addEmployee.employee_Ids = fr.result;
            console.log(_this.addEmployee.employee_Ids);
        };
        fr.readAsDataURL(file);
    };
    AddEmployeeListComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.221.208.210/public/beauty-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    AddEmployeeListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-add-employee-list',
            template: __webpack_require__("../../../../../src/app/header-three-layout/add-employee-list/add-employee-list.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-three-layout/add-employee-list/add-employee-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["b" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__["c" /* TranslateService */],
            __WEBPACK_IMPORTED_MODULE_6__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_7__providers_common_service__["a" /* CommonService */]])
    ], AddEmployeeListComponent);
    return AddEmployeeListComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/add-employee-list/add-employee-list.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddEmployeeListModule", function() { return AddEmployeeListModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_angular_2_dropdown_multiselect__ = __webpack_require__("../../../../angular-2-dropdown-multiselect/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__add_employee_list_routing_module__ = __webpack_require__("../../../../../src/app/header-three-layout/add-employee-list/add-employee-list-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__add_employee_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/add-employee-list/add-employee-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var AddEmployeeListModule = (function () {
    function AddEmployeeListModule() {
    }
    AddEmployeeListModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_7__add_employee_list_routing_module__["a" /* AddEmployeeListRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["e" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["j" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_5_angular_2_dropdown_multiselect__["a" /* MultiselectDropdownModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_common_http__["b" /* HttpClientModule */],
                __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__["b" /* TranslateModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_8__add_employee_list_component__["a" /* AddEmployeeListComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_9__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_10__providers_common_service__["a" /* CommonService */]]
        })
    ], AddEmployeeListModule);
    return AddEmployeeListModule;
}());



/***/ })

});
//# sourceMappingURL=add-employee-list.module.chunk.js.map