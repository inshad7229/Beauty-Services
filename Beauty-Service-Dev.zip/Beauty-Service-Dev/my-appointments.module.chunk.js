webpackJsonp(["my-appointments.module"],{

/***/ "../../../../../src/app/header-four-layout/my-appointments/my-appointments-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MyAppointmentsRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__my_appointments_component__ = __webpack_require__("../../../../../src/app/header-four-layout/my-appointments/my-appointments.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__my_appointments_component__["a" /* MyAppointmentsComponent */]
    }
];
var MyAppointmentsRoutingModule = (function () {
    function MyAppointmentsRoutingModule() {
    }
    MyAppointmentsRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], MyAppointmentsRoutingModule);
    return MyAppointmentsRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-four-layout/my-appointments/my-appointments.component.html":
/***/ (function(module, exports) {

module.exports = "\r\n      <div class=\"page-content-wrapper\">\r\n        <div class=\"page-content\">\r\n          <ul class=\"page-breadcrumb breadcrumb hide\">\r\n            <li>\r\n              <a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n            </li>\r\n            <li class=\"active\">\r\n               Dashboard\r\n            </li>\r\n          </ul>\r\n          <!-- BEGIN PAGE CONTENT INNER -->\r\n          <div class=\"emp-list-sec\">\r\n            <div class=\"col-md-12 col-sm-12 p-0\">\r\n              <!-- BEGIN PORTLET-->\r\n              <div class=\"booking-section\"><!-- like that wrap class -->\r\n                <div class=\"portlet light\">\r\n                  <div class=\"portlet-title\">\r\n                    <div class=\"caption caption-md\">\r\n                      <i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n                      <span class=\"caption-subject theme-font-color bold uppercase\">My Appointments</span>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"portlet-body services-list\">\r\n                    <div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                      <div class=\"my-appoint-sec\">\r\n                        <div class=\"appoint-inner-sec\">\r\n                          <ul class=\"appointment-ul\" *ngIf=\"appointment\">\r\n                            <li *ngFor=\"let apoint of appointment | paginate: { itemsPerPage: 3, currentPage: p }; let i=index \">\r\n                              <div class=\"salon-li\">\r\n                                <img *ngIf=\"!apoint.requestedSaloonyCustomer.image \" src=\"assets/img/saloon.svg\" class=\"salon-logo\" alt=\"salon-logo\">\r\n                                <img *ngIf=\"apoint.requestedSaloonyCustomer.image\" [src]=\"imagePath(apoint.requestedSaloonyCustomer.image)\" class=\"salon-logo\" alt=\"salon-logo\">\r\n                                <span class=\"salon-span\">\r\n                                  <h3><span>{{apoint.requestedSaloonyCustomer.saloon_name}}</span></h3>  \r\n                                  <small> <span>{{apoint.requestedSaloonyCustomer.city}}</span></small>\r\n                                  <span *ngIf=\"apoint.requestedSaloonyCustomer.saloonRating.length>0\" class=\"rating-salon pull-right\">\r\n                                    <i class=\"{{getRatingClass(apoint.requestedSaloonyCustomer.saloonRating,1)}}\"></i>\r\n                                    <i class=\"{{getRatingClass(apoint.requestedSaloonyCustomer.saloonRating,2)}}\"></i>\r\n                                    <i class=\"{{getRatingClass(apoint.requestedSaloonyCustomer.saloonRating,3)}}\"></i>\r\n                                    <i class=\"{{getRatingClass(apoint.requestedSaloonyCustomer.saloonRating,4)}}\"></i>\r\n                                    <i class=\"{{getRatingClass(apoint.requestedSaloonyCustomer.saloonRating,5)}}\"></i>\r\n                                  </span>\r\n                                  <span *ngIf=\"apoint.requestedSaloonyCustomer.saloonRating.length<1\" class=\"rating-salon pull-right\">\r\n                                    <i class=\"fa fa-star-o\"></i>\r\n                                    <i class=\"fa fa-star-o\"></i>\r\n                                    <i class=\"fa fa-star-o\"></i>\r\n                                    <i class=\"fa fa-star-o\"></i>\r\n                                    <i class=\"fa fa-star-o\"></i>\r\n                                  </span>\r\n                                </span>\r\n                                <div class=\"service-des\">     \r\n                                  <img *ngIf=\"!apoint.requestedServiceByCustomer.image \" src=\"assets/img/service-1.jpg\" class=\"\" alt=\"service\">\r\n                                  <img *ngIf=\"apoint.requestedServiceByCustomer.image \" [src]=\"imagePath(apoint.requestedServiceByCustomer.image)\" class=\"\" alt=\"service\">\r\n                                  <h4>\r\n                                    <span>{{apoint.requestedServiceByCustomer.services_eng}}</span>\r\n                                    <!-- <small class=\"timeing\">\r\n                                      <i class=\"fa fa-clock-o\"></i>\r\n                                      {{apoint.start_time}} - {{apoint.end_time}}, {{apoint.date}}\r\n                                    </small> -->\r\n                                  </h4>\r\n                                  <span class=\"price-span\">AED {{apoint.amount}}</span> \r\n                                </div>\r\n                                <div class=\"your-professional\">\r\n                                  <img *ngIf=\"!apoint.requestedServiceByCustomer.employee_image\" src=\"assets/img/user-pro-1.jpg\" alt=\"professional\">\r\n                                  <img *ngIf=\"apoint.requestedServiceByCustomer.employee_image\" [src]=\"imagePath(apoint.requestedServiceByCustomer.employee_image)\" alt=\"professional\">\r\n                                  <h4><span>{{apoint.employeeRequestedByCustomer.first_name}} {{apoint.employeeRequestedByCustomer.last_name}} </span> <small>Your Professional</small></h4>\r\n                                </div>\r\n                                <div class=\"date-status\">\r\n                                  <ul class=\"booking-datetime\">\r\n                                    <li class=\"date-book\">\r\n                                      <i class=\"fa fa-clock-o\"></i>{{getHours(apoint.start_time)}} : {{getMin(apoint.start_time)}} {{getAmPm(apoint.start_time)}} - {{getHours(apoint.end_time)}} : {{getMin(apoint.end_time)}} {{getAmPm(apoint.end_time)}}\r\n                                    </li>\r\n                                    <li class=\"time-book\">\r\n                                      <i class=\"fa fa-calendar\"></i>\r\n                                      {{apoint.date}}\r\n                                    </li>\r\n                                    <li class=\"time-book\">\r\n                                      <i class=\"fa fa-credit-card\"></i>\r\n                                      <label>Payment Type:</label>  {{apoint.payment_type}}\r\n                                    </li>\r\n                                  </ul>\r\n                                  <div class=\"status-div\">\r\n                                    <h4><label>Status:</label> {{getStatus(apoint.appointment_status)}}</h4>\r\n                                  </div>\r\n                                </div>\r\n                              <!--   <div class=\"status-sec\">\r\n                                  <h4><label>Status:</label> Pending</h4>\r\n                                </div> -->\r\n                              </div>\r\n                            </li>\r\n                          </ul>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n                        <div class=\"table-pagination\">\r\n                          <div class=\"pagination\">\r\n                             <pagination-controls (pageChange)=\"p = $event\"  previousLabel=\"\"  nextLabel=\"\" ></pagination-controls>\r\n                          </div>\r\n                        </div>\r\n              <!-- END PORTLET-->\r\n            </div>\r\n          </div>\r\n          <!-- END PAGE CONTENT INNER -->\r\n        </div>\r\n      </div>\r\n      <!-- END CONTENT-->"

/***/ }),

/***/ "../../../../../src/app/header-four-layout/my-appointments/my-appointments.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".btn.cus-btn {\n  background-color: #d5275a;\n  border-radius: unset;\n  color: #fff;\n  margin-right: 11px;\n  min-width: 130px; }\n\n.month-name h3 {\n  color: #d5275a; }\n\n.week-sec .cal-month-view .cal-day-cell {\n  min-height: 70px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-four-layout/my-appointments/my-appointments.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MyAppointmentsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_customer_service__ = __webpack_require__("../../../../../src/app/providers/customer.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var MyAppointmentsComponent = (function () {
    function MyAppointmentsComponent(router, fb, vcr, toastr, customerService) {
        this.router = router;
        this.fb = fb;
        this.toastr = toastr;
        this.customerService = customerService;
        this.userDetail = JSON.parse(localStorage['customerdetails']);
        this.toastr.setRootViewContainerRef(vcr);
    }
    MyAppointmentsComponent.prototype.ngOnInit = function () {
        this.getAppointment();
        $("#row2").hide();
        $("#row6").hide();
        //      $(document).ready(function() {
        //            $('.multiselect').multiselect();
        //           });
        // $("#row2").hide();
        //         $(document).ready(function(){
        //           $("#show1").click(function(){
        //               $("#row1").hide(600);
        //               $("#row2").show(600);
        //           });
        //       });
        //  $("#row6").hide();
        //       $(document).ready(function(){
        //         $("#show3").click(function(){
        //             $("#row5").hide(500);
        //             $("#row6").show(500);
        //         });
        //       });
        Metronic.init(); // init metronic core componets
        Layout.init(); // init layout
        Demo.init(); // init demo features 
        /*Index.init(); // init index page*/
        Tasks.initDashboardWidget(); // init tash dashboard widget  
    };
    MyAppointmentsComponent.prototype.getAppointment = function () {
        var _this = this;
        this.customerService.CustomerAppointment(this.userDetail.id)
            .subscribe(function (data) {
            // alert(data)
            console.log(data);
            if (data.response) {
                _this.appointment = data.data;
                _this.toastr.success(data.message, 'success', { toastLife: 1000, showCloseButton: true });
            }
            else if (data.message == 'Unable to update Password') {
                _this.toastr.error('Unable to update Password', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else if (data.message == 'current password is incorrect') {
                _this.toastr.error('current password is incorrect', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    MyAppointmentsComponent.prototype.getHours = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[0]);
        if (value3 > 12) {
            var a = value3 - 12;
            return '0' + a;
        }
        else {
            if (value3 < 10) {
                return '0' + value3;
            }
            else {
                return value3;
            }
        }
    };
    MyAppointmentsComponent.prototype.getMin = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[1]);
        if (value3 < 10) {
            return '0' + value3;
        }
        else {
            return value3;
        }
    };
    MyAppointmentsComponent.prototype.getAmPm = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[0]);
        if (value3 > 11) {
            return 'Pm';
        }
        else {
            return 'Am';
        }
    };
    MyAppointmentsComponent.prototype.getStatus = function (status) {
        if (status == 0) {
            return 'Pending';
        }
        else if (status == 1) {
            return 'Complete';
        }
        else if (status == 2) {
            return 'Canceled';
        }
    };
    MyAppointmentsComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.221.208.210/public/beauty-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    MyAppointmentsComponent.prototype.getRatingClass = function (rating, flag) {
        var count = 0;
        var avg = 0;
        for (var i = 0; i < rating.length; ++i) {
            // code...rating
            if (rating[i].rating) {
                // code...
                count = count + parseInt(rating[i].rating);
            }
        }
        avg = count / rating.length;
        if (flag == 1) {
            if (avg < 1) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
        else if (flag == 2) {
            if (avg < 2) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
        else if (flag == 3) {
            if (avg < 3) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
        else if (flag == 4) {
            if (avg < 4) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
        else if (flag == 5) {
            if (avg < 5) {
                return 'fa fa-star-half-o';
            }
            else {
                return 'fa fa-star';
            }
        }
    };
    MyAppointmentsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-my-appointments',
            template: __webpack_require__("../../../../../src/app/header-four-layout/my-appointments/my-appointments.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-four-layout/my-appointments/my-appointments.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["b" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_4__providers_customer_service__["a" /* CustomerService */]])
    ], MyAppointmentsComponent);
    return MyAppointmentsComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-four-layout/my-appointments/my-appointments.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyAppointmentsModule", function() { return MyAppointmentsModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_material_select__ = __webpack_require__("../../../material/esm5/select.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__my_appointments_routing_module__ = __webpack_require__("../../../../../src/app/header-four-layout/my-appointments/my-appointments-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__my_appointments_component__ = __webpack_require__("../../../../../src/app/header-four-layout/my-appointments/my-appointments.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__providers_customer_service__ = __webpack_require__("../../../../../src/app/providers/customer.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var MyAppointmentsModule = (function () {
    function MyAppointmentsModule() {
    }
    MyAppointmentsModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_9_ngx_pagination__["a" /* NgxPaginationModule */], __WEBPACK_IMPORTED_MODULE_6__my_appointments_routing_module__["a" /* MyAppointmentsRoutingModule */], __WEBPACK_IMPORTED_MODULE_2__angular_forms__["e" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["j" /* ReactiveFormsModule */], __WEBPACK_IMPORTED_MODULE_3__angular_material_select__["a" /* MatSelectModule */], __WEBPACK_IMPORTED_MODULE_4__angular_common_http__["b" /* HttpClientModule */], __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__["ToastModule"].forRoot()],
            declarations: [__WEBPACK_IMPORTED_MODULE_7__my_appointments_component__["a" /* MyAppointmentsComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_8__providers_customer_service__["a" /* CustomerService */]]
        })
    ], MyAppointmentsModule);
    return MyAppointmentsModule;
}());



/***/ })

});
//# sourceMappingURL=my-appointments.module.chunk.js.map