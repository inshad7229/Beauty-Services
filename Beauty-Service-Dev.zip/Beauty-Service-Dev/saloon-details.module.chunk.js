webpackJsonp(["saloon-details.module"],{

/***/ "../../../../../src/app/header-two-layout/saloon-details/saloon-details-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaloonDetailsRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__saloon_details_component__ = __webpack_require__("../../../../../src/app/header-two-layout/saloon-details/saloon-details.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__saloon_details_component__["a" /* SaloonDetailsComponent */]
    }
];
var SaloonDetailsRoutingModule = (function () {
    function SaloonDetailsRoutingModule() {
    }
    SaloonDetailsRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], SaloonDetailsRoutingModule);
    return SaloonDetailsRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/saloon-details/saloon-details.component.html":
/***/ (function(module, exports) {

module.exports = "         <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n             <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n        </div>\r\n        <section class=\"salon-slider\" >\r\n            <div class=\"owl-demo1 owl-theme\" *ngIf=\"saloonData\">\r\n                <!-- <div class=\"item\" *ngFor=\"let img of saloonData.SaloonImages \" id=\"{{i}}\">\r\n                    <img src=\"http://18.216.88.154/public/beauti-service/{{img.image}}\" alt=\"slideimag\" class=\"img-responsive\">\r\n                </div> -->\r\n                <div class=\"item\" *ngIf=\"saloonData.SaloonImages.length>0\">\r\n                    <img [src]=\"getimage1()\" alt=\"slideimag\" class=\"img-responsive\">\r\n                </div>\r\n                <div class=\"item\" *ngIf=\"saloonData.SaloonImages.length>1\">\r\n                    <img [src]=\"getimage2()\" alt=\"slideimag\" class=\"img-responsive\">\r\n                </div>\r\n                <div class=\"item\" *ngIf=\"saloonData.SaloonImages.length>2\">\r\n                    <img [src]=\"getimage3()\" alt=\"slideimag\" class=\"img-responsive\">\r\n                </div>\r\n                <div class=\"item\" *ngIf=\"saloonData.SaloonImages.length>3\">\r\n                    <img [src]=\"getimage4()\" alt=\"slideimag\" class=\"img-responsive\">\r\n                </div>\r\n                <div class=\"item\" *ngIf=\"saloonData.SaloonImages.length>4\">\r\n                    <img [src]=\"getimage5()\" alt=\"slideimag\" class=\"img-responsive\">\r\n                </div>\r\n                <div class=\"item\" *ngIf=\"saloonData.SaloonImages.length>5\">\r\n                    <img [src]=\"getimage6()\" alt=\"slideimag\" class=\"img-responsive\">\r\n                </div>\r\n            </div>\r\n            <div class=\"salon-details-header\">\r\n                <ul class=\"breadcrumb\">\r\n                    <li>\r\n                        <a href=\"index.php\">Home</a>\r\n                    </li>\r\n                    <li>\r\n                        <a href=\"#\">USA</a>\r\n                    </li>\r\n                </ul>\r\n                <span *ngIf=\"saloonData\">{{saloonData.saloon_name}}</span>\r\n            </div>\r\n        </section>\r\n        <section class=\"Salon-details-sec\" *ngIf=\"saloonData\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                    <div class=\"row wrap-salon-dp\">\r\n                        <div class=\"col-md-9 col-sm-12 col-xs-12 p-l-0 salon-d\">\r\n                            <div class=\"salon-des-consec\">\r\n                                <!-- Wizard container -->\r\n                                <div class=\"wizard-container\">\r\n                                    <div class=\"card wizard-card\" data-color=\"red\" id=\"wizard\">\r\n                                        <div class=\"wizard-navigation\">\r\n                                            <ul class=\"custome-tab\">\r\n                                                <li class=\"active\">\r\n                                                    <a href=\"#details\" data-toggle=\"tab\">About</a>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <a href=\"#captain\" data-toggle=\"tab\">Services</a>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <a href=\"#description\" data-toggle=\"tab\">Review</a>\r\n                                                </li>\r\n                                            </ul>\r\n                                        </div>\r\n                                        <div class=\"tab-content\">\r\n                                            <div class=\"tab-pane active\" id=\"details\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                    <div class=\"about-us-sec\">\r\n                                                        <p>\r\n                                                            {{saloonData.description_eng}}\r\n                                                        </p>\r\n                                                        <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>\r\n                                                        <p> Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\n                                                            proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n                                                        </p> -->\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"tab-pane\" id=\"captain\">\r\n                                                <div class=\"services-tab-sec\">\r\n                                                    <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                        <div class=\"service-listwrap\" *ngFor=\"let cat of saloonData.saloonCategory\" >\r\n                                                            <a href=\"javascript:void(0)\" #ref (click)=\"openCategory(ref)\">\r\n                                                                <span class=\"right-icon\">\r\n                                                                    <i class=\"fa fa-angle-up\"></i>\r\n                                                                </span>\r\n                                                                {{cat.categoryData.category_eng}} ({{cat.categoryData.categoryServices.length}})\r\n                                                            </a>\r\n                                                            <div class=\"sub-menulist\" style=\"display: none\">\r\n                                                                <div class=\"list-content gray-line\" *ngFor=\"let ser of cat.categoryData.categoryServices\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>{{ser.servicesData.services_eng}}</h4>\r\n                                                                        <small><a href=\"javascript:void(0)\">Show Details</a> <span>{{getTime(ser.time)}}</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED {{ser.cost_eng}}</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"javascript:void(0)\" (click)=\"onselectService(ser)\">\r\n                                                                                    <i *ngIf=\"getStatus(ser)==false\" class=\"fa fa-plus\"></i>\r\n                                                                                    <i *ngIf=\"getStatus(ser)==true\" class=\"fa fa-minus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <!-- <div class=\"list-content\">fa fa-minus\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>Perm Cut</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>45 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 190</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div> -->\r\n                                                            </div>\r\n                                                        </div>\r\n                                                      <!--   <div class=\"service-listwrap\">\r\n                                                            <a href=\"javascript:void(0)\">\r\n                                                                <span class=\"right-icon\">\r\n                                                                    <i class=\"fa fa-angle-up\"></i>\r\n                                                                </span>\r\n                                                                African Hair cornrow (2)\r\n                                                            </a>\r\n                                                            <div class=\"sub-menulist\">\r\n                                                                <div class=\"list-content gray-line\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>African Lines with Own Extentions</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>30 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 180</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <div class=\"list-content\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>Perm Cut</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>45 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 190</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                        <div class=\"service-listwrap\">\r\n                                                            <a href=\"javascript:void(0)\">\r\n                                                                <span class=\"right-icon\">\r\n                                                                    <i class=\"fa fa-angle-up\"></i>\r\n                                                                </span>\r\n                                                                Afro Hair Below Dry & Styling (2)\r\n                                                            </a>\r\n                                                            <div class=\"sub-menulist\">\r\n                                                                <div class=\"list-content gray-line\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>Hot Iron Styling OR Styling</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>45 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 60</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <div class=\"list-content\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>Wash & Below Dry</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>45 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 190</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                        <div class=\"service-listwrap\">\r\n                                                            <a href=\"javascript:void(0)\">\r\n                                                                <span class=\"right-icon\">\r\n                                                                    <i class=\"fa fa-angle-up\"></i>\r\n                                                                </span>\r\n                                                                Afro Hair Braiding (2)\r\n                                                            </a>\r\n                                                            <div class=\"sub-menulist\">\r\n                                                                <div class=\"list-content gray-line\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>Big size with Own Extension (Short Hair)</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>30 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 50</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <div class=\"list-content\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>Perm Cut</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>45 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 190</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                        <div class=\"service-listwrap\">\r\n                                                            <a href=\"javascript:void(0)\">\r\n                                                                <span class=\"right-icon\">\r\n                                                                    <i class=\"fa fa-angle-up\"></i>\r\n                                                                </span>\r\n                                                                Afro Haircut (2)\r\n                                                            </a>\r\n                                                            <div class=\"sub-menulist\">\r\n                                                                <div class=\"list-content gray-line\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>Blow Dry</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>30 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 50</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <div class=\"list-content\">\r\n                                                                    <div class=\"col-sm-8 p-0 service-bt\">\r\n                                                                        <h4>Perm Cut</h4>\r\n                                                                        <small><a href=\"#\">Show Details</a><span>45 Min</span></small>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-sm-4 p-0 service-prl\">\r\n                                                                        <div class=\"price-value\">\r\n                                                                            <span class=\"aed-total\"><h6>AED 190</h6></span>\r\n                                                                            <span class=\"add-cart-icon\">\r\n                                                                                <a href=\"#\">\r\n                                                                                    <i class=\"fa fa-plus\"></i>\r\n                                                                                </a>\r\n                                                                            </span>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                        </div> -->\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"tab-pane\" id=\"description\">\r\n                                                <div class=\"review-wrap\">\r\n                                                    <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                        <div class=\"review-heading\">\r\n                                                            <h4>Review</h4>\r\n                                                            <span class=\"add-rating\">\r\n                                                                <a href=\"#\"><i class=\"fa fa-plus-circle\"></i>Rating</a>\r\n                                                            </span>\r\n                                                        </div>\r\n                                                        <div class=\"col-md-4 col-sm-4 col-xs-4 text-center\">\r\n                                                            <h1 class=\"rating-num\">\r\n                                                                4.0</h1>\r\n                                                            <div class=\"rating\">\r\n                                                                <i class=\"fa fa-star\"></i>\r\n                                                                <i class=\"fa fa-star\"></i>\r\n                                                                <i class=\"fa fa-star\"></i>\r\n                                                                <i class=\"fa fa-star\"></i>\r\n                                                                <i class=\"fa fa-star-half-o\"></i>\r\n                                                            </div>\r\n                                                            <div class=\"total-starpoint\">\r\n                                                                 <i class=\"fa fa-user\"></i> 1,050,008 total\r\n                                                            </div>\r\n                                                        </div>\r\n                                                        <div class=\"col-md-8 col-sm-8 col-xs-8\">\r\n                                                            <div class=\"rating-desc\">\r\n                                                                <div class=\"row\">\r\n                                                                    <div class=\"col-xs-3 col-md-3 text-right\">\r\n                                                                        <i class=\"fa fa-star\"></i>5 \r\n                                                                    </div>\r\n                                                                    <div class=\"col-xs-8 col-md-9\">\r\n                                                                        <div class=\"progress progress-striped\">\r\n                                                                            <div class=\"progress-bar progress-bar-success\" role=\"progressbar\" aria-valuenow=\"20\"\r\n                                                                                aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: 80%\">\r\n                                                                                <span class=\"sr-only\">80%</span>\r\n                                                                            </div>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <!-- end 5 -->\r\n                                                                <div class=\"row\">\r\n                                                                     <div class=\"col-xs-3 col-md-3 text-right\">\r\n                                                                        <i class=\"fa fa-star\"></i>4\r\n                                                                    </div>\r\n                                                                    <div class=\"col-xs-8 col-md-9\">\r\n                                                                        <div class=\"progress\">\r\n                                                                            <div class=\"progress-bar progress-bar-success\" role=\"progressbar\" aria-valuenow=\"20\"\r\n                                                                                aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: 60%\">\r\n                                                                                <span class=\"sr-only\">60%</span>\r\n                                                                            </div>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <!-- end 4 -->\r\n                                                                <div class=\"row\">\r\n                                                                    <div class=\"col-xs-3 col-md-3 text-right\">\r\n                                                                        <i class=\"fa fa-star\"></i>3\r\n                                                                    </div>\r\n                                                                    <div class=\"col-xs-8 col-md-9\">\r\n                                                                        <div class=\"progress\">\r\n                                                                            <div class=\"progress-bar progress-bar-info\" role=\"progressbar\" aria-valuenow=\"20\"\r\n                                                                                aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: 40%\">\r\n                                                                                <span class=\"sr-only\">40%</span>\r\n                                                                            </div>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <!-- end 3 -->\r\n                                                                <div class=\"row\">\r\n                                                                    <div class=\"col-xs-3 col-md-3 text-right\">\r\n                                                                        <i class=\"fa fa-star\"></i>2\r\n                                                                    </div>\r\n                                                                    <div class=\"col-xs-8 col-md-9\">\r\n                                                                        <div class=\"progress\">\r\n                                                                            <div class=\"progress-bar progress-bar-warning\" role=\"progressbar\" aria-valuenow=\"20\"\r\n                                                                                aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: 20%\">\r\n                                                                                <span class=\"sr-only\">20%</span>\r\n                                                                            </div>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <!-- end 2 -->\r\n                                                                <div class=\"row\">\r\n                                                                    <div class=\"col-xs-3 col-md-3 text-right\">\r\n                                                                        <i class=\"fa fa-star\"></i>1\r\n                                                                    </div>\r\n                                                                    <div class=\"col-xs-8 col-md-9\">\r\n                                                                        <div class=\"progress\">\r\n                                                                            <div class=\"progress-bar progress-bar-danger\" role=\"progressbar\" aria-valuenow=\"80\"\r\n                                                                                aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: 15%\">\r\n                                                                                <span class=\"sr-only\">15%</span>\r\n                                                                            </div>\r\n                                                                        </div>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                                <!-- end 1 -->\r\n                                                            </div>\r\n                                                            <!-- end row -->\r\n                                                        </div>\r\n                                                    </div>\r\n                                                    <div class=\"userlist-rating\">\r\n                                                        <div class=\"review-wrap-list\">\r\n                                                            <div class=\"col-md-1 col-sm-1 col-xs-2 p-0\">\r\n                                                                <div class=\"rating-user\">\r\n                                                                    <img src=\"img/user-pro-2.jpg\" alt=\"rating-img\" >\r\n                                                                </div>\r\n                                                            </div>\r\n                                                            <div class=\"col-md-11 col-sm-10 col-xs-10\">\r\n                                                                <div class=\"review-content\">\r\n                                                                    <h3>Barry Alen</h3>\r\n                                                                    <span class=\"user-star\">\r\n                                                                        <i class=\"fa fa-star\"></i>\r\n                                                                        <i class=\"fa fa-star\"></i>\r\n                                                                        <i class=\"fa fa-star\"></i>\r\n                                                                        <i class=\"fa fa-star\"></i>\r\n                                                                        <i class=\"fa fa-star-half-o\"></i>\r\n                                                                    </span>\r\n                                                                    <span class=\"time-day pull-right\">2 week ago</span>\r\n                                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                        <div class=\"review-wrap-list\">\r\n                                                            <div class=\"col-md-1 col-sm-1 col-xs-2 p-0\">\r\n                                                                <div class=\"rating-user\">\r\n                                                                    <img src=\"img/user-pro-1.jpg\" alt=\"rating-img\" >\r\n                                                                </div>\r\n                                                            </div>\r\n                                                            <div class=\"col-md-11 col-sm-10 col-xs-10\">\r\n                                                                <div class=\"review-content\">\r\n                                                                    <h3>Barry Alen</h3>\r\n                                                                    <span class=\"user-star\">\r\n                                                                        <i class=\"fa fa-star\"></i>\r\n                                                                        <i class=\"fa fa-star\"></i>\r\n                                                                        <i class=\"fa fa-star\"></i>\r\n                                                                        <i class=\"fa fa-star\"></i>\r\n                                                                        <i class=\"fa fa-star-half-o\"></i>\r\n                                                                    </span>\r\n                                                                    <span class=\"time-day pull-right\">2 week ago</span>\r\n                                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,</p>\r\n                                                                </div>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <!-- wizard container -->\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-md-3 col-sm-12 col-xs-12 p-l-0 salon-m\">\r\n                            <div class=\"salon-det-sidebar\">\r\n                                <div class=\"salon-add-map\" *ngIf=\"saloonData\">\r\n                                    <div  style=\"width:100%;height:200px;\">\r\n                                        <agm-map id=\"demo2\" [latitude]=\"getLat(saloonData.latitude)\" [longitude]=\"getLon(saloonData.longitude)\" [scrollwheel]=\"false\" [zoom]=\"zoom\">\r\n                                                                            <agm-marker [latitude]=\"getLat(saloonData.latitude)\" [longitude]=\"getLon(saloonData.longitude)\"></agm-marker>\r\n                                                                    </agm-map>\r\n                                    </div>\r\n                                    <div class=\"address-salon\">\r\n                                        <h4 >{{saloonData.saloon_name}}</h4>\r\n                                        <p class=\"addres-salon\">{{saloonData.city}}</p>\r\n                                        <div class=\"Opening-hours\">\r\n                                            <a id=\"opening\" href=\"javascript:void(0);\" #ref2 (click)=\"openCategory2(ref2)\">Opening Hours \r\n                                                <span class=\"pull-right\">\r\n                                                <i class=\"fa fa-plus-circle\"></i>  \r\n                                                </span>\r\n                                            </a>\r\n                                            <ul class=\"timing-ul\" style=\"display: none\">\r\n                                                <li>\r\n                                                    <span class=\"week-name\">Sunday</span>\r\n                                                    <span class=\"opening-time\">{{saloonData.opening_time}} - {{saloonData.closing_time}}</span>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <span class=\"week-name\">Monday</span>\r\n                                                    <span class=\"opening-time\">{{saloonData.opening_time}} - {{saloonData.closing_time}}</span>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <span class=\"week-name\">Tuesday</span>\r\n                                                    <span class=\"opening-time\">{{saloonData.opening_time}} - {{saloonData.closing_time}}</span>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <span class=\"week-name\">Wednesday</span>\r\n                                                    <span class=\"opening-time\">{{saloonData.opening_time}} - {{saloonData.closing_time}}</span>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <span class=\"week-name\">Thursday</span>\r\n                                                    <span class=\"opening-time\">{{saloonData.opening_time}} - {{saloonData.closing_time}}</span>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <span class=\"week-name\">Friday</span>\r\n                                                    <span class=\"opening-time\">{{saloonData.opening_time}} - {{saloonData.closing_time}}</span>\r\n                                                </li>\r\n                                                <li>\r\n                                                    <span class=\"week-name\">Saturday</span>\r\n                                                    <span class=\"opening-time\">{{saloonData.opening_time}} - {{saloonData.closing_time}}</span>\r\n                                                </li>\r\n                                            </ul>\r\n                                        </div>\r\n                                        <div class=\"credit-card-salon\" *ngIf=\"saloonData.cardPay\">\r\n                                            <span class=\"card-check\">\r\n                                                <i class=\"fa fa-credit-card\"></i>\r\n                                                <p><i class=\"fa fa-check-circle\"></i></p>\r\n                                            </span>\r\n                                            This saloon accepted credit Card\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"book-nowsec\">\r\n                                <div class=\"total-mony\">\r\n                                    <span class=\"booknow\">\r\n                                        <i class=\"fa fa-shopping-cart\"></i>\r\n                                        <span class=\"circle-value\">{{selectedServices.length}}</span>\r\n                                    </span>\r\n                                    <span class=\"price-span\">AED {{totalAmount}}</span>\r\n                                </div>\r\n                                <div class=\"book-nowbtn\">\r\n                                    <button href=\"javascript:void(0);\" class=\"btn cut-btn\" [disabled]=\"totalAmount==0\" (click)=\"onSchedule()\">Schedule Appointment</button>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/saloon-details/saloon-details.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "agm-map {\n  height: 300px; }\n\n.salon-images-sec {\n  float: left;\n  width: 100%;\n  margin-top: 30px; }\n\n.custome-tab {\n  display: inline-block;\n  width: 100%;\n  padding-left: 0px; }\n\n.custome-tab li {\n  width: 33.33%;\n  float: left;\n  text-align: center;\n  display: inline-block;\n  background-color: #f8f8f8;\n  padding: 10px 10px; }\n\n.custome-tab li.active {\n  background-color: #d5275a; }\n\n.custome-tab li.active a {\n  color: #fff;\n  text-decoration: none; }\n\n.custome-tab li a {\n  font-size: 16px;\n  font-weight: 500;\n  color: #d5275a;\n  width: 100%;\n  display: inline-block; }\n\n.custome-tab li a:hover {\n  text-decoration: none;\n  outline: none; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/saloon-details/saloon-details.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaloonDetailsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__providers_app_provider__ = __webpack_require__("../../../../../src/app/providers/app.provider.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__agm_core__ = __webpack_require__("../../../../@agm/core/index.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var SaloonDetailsComponent = (function () {
    function SaloonDetailsComponent(router, saloonServices, vcr, toastr, commonService, appProvider, route, mapsAPILoader, ngZone) {
        this.router = router;
        this.saloonServices = saloonServices;
        this.toastr = toastr;
        this.commonService = commonService;
        this.appProvider = appProvider;
        this.route = route;
        this.mapsAPILoader = mapsAPILoader;
        this.ngZone = ngZone;
        this.selectedServices = [];
        this.totalAmount = 0;
        this.toastr.setRootViewContainerRef(vcr);
        this.id = +this.route.snapshot.paramMap.get('id');
        //alert(this.id)
        this.getSaloonData();
    }
    SaloonDetailsComponent.prototype.ngOnInit = function () {
        this.zoom = 4;
        this.latitude = 39.8282;
        this.longitude = -98.5795;
        //create search FormControl
        //set current position
        this.setCurrentPosition();
        //load Places Autocomplete
        // this.mapsAPILoader.load().then(() => {
        //   let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        //     types: ["address"]
        //   });
        //   autocomplete.addListener("place_changed", () => {
        //     this.ngZone.run(() => {
        //       //get the place result
        //       let place: google.maps.places.PlaceResult = autocomplete.getPlace();
        //      // alert(place.formatted_address)
        //       //verify result
        //       if (place.geometry === undefined || place.geometry === null) {
        //         return;
        //       }
        //       //set latitude, longitude and zoom
        //       // this.userDetail.city=place.formatted_address
        //       // this.userDetail.latitude = place.geometry.location.lat();
        //       // this.userDetail.longitude = place.geometry.location.lng();
        //       this.zoom = 12;
        //     });
        //   });
        // });
        // 	$(window).scroll(function() {
        //     if ($(this).scrollTop() > 1){  
        //         $('header').addClass("sticky");
        //     }
        //     else{
        //         $('header').removeClass("sticky");
        //     }
        // });
        // $(document).ready(function() {
        // Custom Navigation Events
        // });
        $('.sub-menulist').hide();
        $('.timing-ul').hide();
        // $(document).on('click','.service-listwrap  a',function(){
        //     $(this).toggleClass('active');
        //     $(this).next('.sub-menulist').slideToggle('500');
        //     $(this).find('i').toggleClass('fa-angle-up fa-angle-down')
        // });
        // $('.timing-ul').hide();
        // $(document).on('click','#opening',function(){
        //     $(this).next('.timing-ul').slideToggle('500');
        //     $(this).find('i').toggleClass('fa-plus-circle fa-minus-circle')
        // });
        // $(window).load(function() {
        //         $(".datetimepicker1");
        //     });
        // $('.datetimepicker1').datetimepicker({
        //         //lang:'ch',
        //          //yearOffset:200,       
        //         timepicker:false,
        //         format:'d-m-Y',
        //         formatDate:'d-m-Y',
        //         value:'Enter Date',
        //         step:10,
        //         minDate:'+1d',
        //         scrollMonth:false,
        //         scrollTime:false,
        //         scrollInput:true,
        //     });
        // var mySlider = $("#rane-slide").slider({
        //         'tooltip':'hide'
        //     });
        // Cal l a method on the slider
        // mySlider.on('change',function(){
        //     var value = mySlider.slider('getValue');
        //     $('.min-range').html('<b>$'+value[0]+'</b>');
        //     $('.max-range').html('<b>$'+value[1]+'</b>');
        // })
        this.getSaloonData();
    };
    SaloonDetailsComponent.prototype.setCurrentPosition = function () {
        var _this = this;
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(function (position) {
                _this.latitude = position.coords.latitude;
                _this.longitude = position.coords.longitude;
                _this.zoom = 12;
            });
        }
    };
    SaloonDetailsComponent.prototype.getLat = function (lat) {
        return parseInt(lat);
    };
    SaloonDetailsComponent.prototype.getLon = function (long) {
        return parseInt(long);
    };
    SaloonDetailsComponent.prototype.getSaloonData = function () {
        var _this = this;
        this.waitLoader = true;
        this.commonService.getAllSaloonData(this.id)
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.saloonData = data.data;
                var owl = $(".owl-demo1");
                owl.owlCarousel({
                    nav: true,
                    loop: true,
                    items: 4,
                    itemsDesktop: [1000, 3],
                    itemsDesktopSmall: [900, 3],
                    itemsTablet: [600, 2],
                    itemsMobile: false,
                    autoplay: true // itemsMobile disabled - inherit from itemsTablet option
                });
                console.log(_this.saloonData.description_eng);
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    SaloonDetailsComponent.prototype.getimage1 = function () {
        return 'http://18.216.88.154/public/beauti-service/' + this.saloonData.SaloonImages[0].image;
    };
    SaloonDetailsComponent.prototype.getimage2 = function () {
        return 'http://18.216.88.154/public/beauti-service/' + this.saloonData.SaloonImages[1].image;
    };
    SaloonDetailsComponent.prototype.getimage3 = function () {
        return 'http://18.216.88.154/public/beauti-service/' + this.saloonData.SaloonImages[2].image;
    };
    SaloonDetailsComponent.prototype.getimage4 = function () {
        return 'http://18.216.88.154/public/beauti-service/' + this.saloonData.SaloonImages[3].image;
    };
    SaloonDetailsComponent.prototype.getimage5 = function () {
        return 'http://18.216.88.154/public/beauti-service/' + this.saloonData.SaloonImages[4].image;
    };
    SaloonDetailsComponent.prototype.getimage6 = function () {
        return 'http://18.216.88.154/public/beauti-service/' + this.saloonData.SaloonImages[5].image;
    };
    SaloonDetailsComponent.prototype.getimage7 = function () {
        return 'http://18.216.88.154/public/beauti-service/' + this.saloonData.SaloonImages[6].image;
    };
    SaloonDetailsComponent.prototype.openCategory = function (ref) {
        $(ref).toggleClass('active');
        $(ref).next('.sub-menulist').slideToggle('500');
        $(ref).find('i').toggleClass('fa-angle-up fa-angle-down');
    };
    SaloonDetailsComponent.prototype.openCategory2 = function (ref) {
        $(ref).next('.timing-ul').slideToggle('500');
        $(ref).find('i').toggleClass('fa-plus-circle fa-minus-circle');
    };
    SaloonDetailsComponent.prototype.getTime = function (time) {
        var a;
        switch (time) {
            case "15":
                a = '15 Min';
                //alert(a)
                return a;
            case "30":
                a = '30 Min';
                return a;
            case "45":
                a = '45 Min';
                return a;
            case "60":
                a = '1 Hr';
                return a;
            case "75":
                a = '1 Hr 15 Min';
                return a;
            case "90":
                a = '1 Hr 30 Min';
                return a;
            case "105":
                a = '1 Hr 45 Min';
                return a;
            case "120":
                a = '2 Hr';
                return a;
            case "135":
                a = '2 Hr 15 Mi';
                return a;
            case "150":
                a = '2 Hr 30 Min';
                return a;
            case "165":
                a = '2 Hr 45 Min';
                return a;
            case "180":
                a = '3 Hr';
                return a;
            default:
                0;
                // alert(a)
                return a;
        }
    };
    SaloonDetailsComponent.prototype.onselectService = function (data) {
        if (this.selectedServices.map(function (img) { return img.service_id; }).indexOf(data.service_id) == -1) {
            this.selectedServices.push({
                saloon_id: data.saloon_id,
                category_id: data.category_id,
                service_id: data.service_id,
                cost_eng: data.cost_eng,
                cost_arb: data.cost_arb,
                description_eng: data.description_eng,
                description_arb: data.description_eng,
                time: data.time,
                services_eng: data.servicesData.services_eng,
                services_arb: data.servicesData.services_arb,
                image: data.servicesData.image,
                date: null,
                startTime: null,
                endTime: null,
                startTime1: null,
                endTime1: null,
                emp_id: null,
                appointment_id: null
            });
            this.totalAmount = this.totalAmount + parseInt(data.cost_eng);
            // code...
        }
        else {
            var index = this.selectedServices.map(function (img) { return img.service_id; }).indexOf(data.service_id);
            this.selectedServices.splice(index, 1);
            this.totalAmount = this.totalAmount - parseInt(data.cost_eng);
        }
    };
    SaloonDetailsComponent.prototype.getStatus = function (data) {
        if (this.selectedServices.length > 0) {
            if (this.selectedServices.map(function (img) { return img.service_id; }).indexOf(data.service_id) == -1) {
                return false;
            }
            else if (this.selectedServices.map(function (img) { return img.service_id; }).indexOf(data.service_id) != -1) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    };
    SaloonDetailsComponent.prototype.onSchedule = function () {
        localStorage['selectedServices'] = JSON.stringify(this.selectedServices);
        this.router.navigate(['/payment-process/' + this.id]);
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])("search"),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SaloonDetailsComponent.prototype, "searchElementRef", void 0);
    SaloonDetailsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-saloon-details',
            template: __webpack_require__("../../../../../src/app/header-two-layout/saloon-details/saloon-details.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/saloon-details/saloon-details.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */],
            __WEBPACK_IMPORTED_MODULE_3__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_4__providers_common_service__["a" /* CommonService */],
            __WEBPACK_IMPORTED_MODULE_5__providers_app_provider__["a" /* AppProvider */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* ActivatedRoute */],
            __WEBPACK_IMPORTED_MODULE_6__agm_core__["b" /* MapsAPILoader */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["NgZone"]])
    ], SaloonDetailsComponent);
    return SaloonDetailsComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/saloon-details/saloon-details.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaloonDetailsModule", function() { return SaloonDetailsModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__saloon_details_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/saloon-details/saloon-details-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__saloon_details_component__ = __webpack_require__("../../../../../src/app/header-two-layout/saloon-details/saloon-details.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_material_tabs__ = __webpack_require__("../../../material/esm5/tabs.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__agm_core__ = __webpack_require__("../../../../@agm/core/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var SaloonDetailsModule = (function () {
    function SaloonDetailsModule() {
    }
    SaloonDetailsModule.prototype.ngOnInit = function () {
    };
    SaloonDetailsModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__saloon_details_routing_module__["a" /* SaloonDetailsRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_4__angular_material_tabs__["a" /* MatTabsModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_common_http__["b" /* HttpClientModule */],
                __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_7__agm_core__["a" /* AgmCoreModule */].forRoot({
                    apiKey: "AIzaSyCSqtRTdfc2DOAYpOut4KEwS1xL5or4ekI",
                    libraries: ["places"]
                }),
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__saloon_details_component__["a" /* SaloonDetailsComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_8__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_9__providers_common_service__["a" /* CommonService */]]
        })
    ], SaloonDetailsModule);
    return SaloonDetailsModule;
}());



/***/ })

});
//# sourceMappingURL=saloon-details.module.chunk.js.map