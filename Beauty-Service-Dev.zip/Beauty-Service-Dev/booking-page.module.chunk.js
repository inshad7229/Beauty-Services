webpackJsonp(["booking-page.module"],{

/***/ "../../../../../src/app/header-three-layout/booking-page/booking-page-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BookingPageRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__booking_page_component__ = __webpack_require__("../../../../../src/app/header-three-layout/booking-page/booking-page.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__booking_page_component__["a" /* BookingPageComponent */]
    }
];
var BookingPageRoutingModule = (function () {
    function BookingPageRoutingModule() {
    }
    BookingPageRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], BookingPageRoutingModule);
    return BookingPageRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/booking-page/booking-page.component.html":
/***/ (function(module, exports) {

module.exports = "<!-- BEGIN CONTENT -->\r\n\t\t\t<div class=\"page-content-wrapper\">\r\n\t\t\t\t<div class=\"page-content\">\r\n\t\t\t\t\t<ul class=\"page-breadcrumb breadcrumb hide\">\r\n\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t<a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<li class=\"active\">\r\n\t\t\t\t\t\t\t Dashboard\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t\t<!-- BEGIN PAGE CONTENT INNER -->\r\n\t\t\t\t\t<div class=\"emp-list-sec\">\r\n\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 p-0\">\r\n\t\t\t\t\t\t\t<!-- BEGIN PORTLET-->\r\n\t\t\t\t\t\t\t<div class=\"booking-section\">\r\n\t\t\t\t\t\t\t\t<div class=\"portlet light\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-title\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"caption caption-md\">\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"caption-subject theme-font-color bold uppercase\">Booking List</span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-body\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"add-emp-form\">\r\n\t\t\t\t\t\t\t\t            \t<div class=\"table-responsive\">\r\n\t\t\t\t\t                                <table class=\"table table-bordered\">\r\n\t\t\t\t\t                                    <thead>\r\n\t\t\t\t\t                                    \t<tr>\r\n\t\t\t\t\t                                    \t\t<td colspan=\"9\">\r\n\t\t\t\t\t\t                                    \t\t<div class=\"cutome-th\" style=\"background-color:rgba(194, 24, 91, 0.698);\">\r\n\t\t\t\t\t\t                                    \t\t\t<span class=\"pull-left\">\r\n\t\t\t\t\t\t\t                                    \t\t\t<a href=\"#\"><i class=\"fa fa-angle-left\"></i></a>\r\n\t\t\t\t\t\t\t                                    \t\t</span>\r\n\t\t\t\t\t\t\t                                    \t\t\tNovember 10, 2017\r\n\t\t\t\t\t\t                                    \t\t\t<span class=\"pull-right\">\r\n\t\t\t\t\t\t\t                                    \t\t\t<a href=\"#\">\r\n\t\t\t\t\t\t\t                                    \t\t\t<i class=\"fa fa-angle-right\"></i>\r\n\t\t\t\t\t\t\t                                    \t\t\t</a>\r\n\t\t\t\t\t\t\t                                    \t\t</span>\r\n\t\t\t\t\t\t                                    \t\t</div>\r\n\t\t\t\t\t                                    \t\t</td>\r\n\t\t\t\t\t                                    \t</tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                        \t<th>Sr No</th>\r\n\t\t\t\t\t                                        \t<th>Appointment Date</th>\r\n\t\t\t\t\t                                            <th>Customer Name</th>\r\n\t\t\t\t\t                                            <th>Customer Number</th>\r\n\t\t\t\t\t                                            <th>Employee Name</th>\r\n\t\t\t\t\t                                            <th>Service Name</th>\r\n\t\t\t\t\t                                            <th>Time</th>\r\n\t\t\t\t\t                                            <th>Status</th>\r\n\t\t\t\t\t                                            <th>Action</th>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                    </thead>\r\n\t\t\t\t\t                                    <tbody>\r\n\t\t\t\t\t                                        <tr *ngFor=\"let appointment of appointMents| paginate: { itemsPerPage: 3, currentPage: p }; let i =index\">\r\n\t\t\t\t\t                                        \t<td>{{i+1}}</td>\r\n\t\t\t\t\t                                        \t<td>{{appointment.date}}</td>\r\n\t\t\t\t\t                                           <td><img *ngIf=\"appointment.customerRequestForAppointment.image\" class=\"user-view\" [src]=\"imagePath(appointment.customerRequestForAppointment.image)\">\r\n                                                                <img *ngIf=\"!appointment.customerRequestForAppointment.image\" class=\"user-view\" src=\"assets/img/5.jpg\">\r\n\t\t\t\t\t                                            {{appointment.customerRequestForAppointment.first_name}}</td>\r\n\t\t\t\t\t                                            <td>{{appointment.customerRequestForAppointment.contact_number}}</td>\r\n\t\t\t\t\t                                            <td class=\"emp-link\">\r\n\t\t\t\t\t                                            \t<a href=\"javascript:void(0);\">{{appointment.employeeRequestedByCustomer.first_name}}</a>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                            <td>{{appointment.requestedServiceByCustomer.services_eng}}</td>\r\n\t\t\t\t\t                                             <td>{{getHours(appointment.start_time)}} : {{getMin(appointment.start_time)}} {{getAmPm(appointment.start_time)}} - {{getHours(appointment.end_time)}} : {{getMin(appointment.end_time)}} {{getAmPm(appointment.end_time)}}</td>\r\n\t\t\t\t\t                                            <td *ngIf=\"appointment.appointment_status==0\">Pending</td>\r\n\t\t\t\t\t                                            <td *ngIf=\"appointment.appointment_status==1\">Complete</td>\r\n\t\t\t\t\t                                            <td *ngIf=\"appointment.appointment_status==2\">Cancelled</td>\r\n\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-bookinglist\" (click)=\"onEdit(appointment)\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#view-bookinglist\" title=\"View\" (click)=\"onView(appointment)\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                    </tbody>\r\n\t\t\t\t\t                                </table>\r\n\t\t\t\t\t                            </div>\r\n\t\t\t\t                                <div class=\"table-pagination\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"pagination\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <!-- <a href=\"#\"><i class=\"fa fa-angle-left\"></i></a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\">1</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\" class=\"active\">2</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\">3</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"#\"><i class=\"fa fa-angle-right\"></i></a> -->\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <pagination-controls (pageChange)=\"p = $event\"  previousLabel=\"\"  nextLabel=\"\" ></pagination-controls>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t            </div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<!-- END PORTLET-->\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<!-- END PAGE CONTENT INNER -->\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<!-- END CONTENT -->\r\n\t\t\r\n\t\t<div class=\"modal fade custom-modal\" id=\"edit-bookinglist\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" *ngIf=\"appointMentData\">\r\n\t\t\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t\t\t    <div class=\"modal-content\">\r\n\t\t\t        <div class=\"modal-header\">\r\n\t\t\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t            \t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t            </button>\r\n\t\t\t            <h4 class=\"modal-title\" id=\"myModalLabel\">Edit Booking List</h4>\r\n\t\t\t        </div>\r\n\t\t\t        <div class=\"modal-body\">\r\n\t\t\t            <div class=\"add-emp-form\">\r\n\t\t\t            \t<form class=\"img-responsive\">\r\n\t\t            \t\t\t<div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t\t            \t\t\t\t<div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Customer Name <small class=\"manidatory\">*</small></label>\r\n\t                                        <input disabled=\"\" type=\"text\" [value]=\"appointMentData.customerRequestForAppointment.first_name\" class=\"form-control\">\r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Customer Number<small class=\"manidatory\">*</small></label>\r\n\t                                        <input disabled=\"\" type=\"text\" [value]=\"appointMentData.customerRequestForAppointment.contact_number\" class=\"form-control\">\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                \t<div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Employee Name<small class=\"manidatory\">*</small></label>\r\n\t                                        <div class=\"custom-select\">\r\n                                                <select [(ngModel)]=\"selectedEmployee\" class=\"form-control\" placeholder=\"Select Employee\"  (change)=\"onEmployeeChange(selectedEmployee)\" [ngModelOptions]=\"{standalone: true}\">\r\n                                                    <option *ngFor=\"let employee of employeeList\"  [value]=\"employee.employeeDetails.id\" >{{employee.employeeDetails.first_name}}</option>\r\n                                                    <!-- <option name=\"vic\">Mary</option>\r\n                                                    <option name=\"qld\" selected=\"selected\">Robert</option>\r\n                                                    <option name=\"qld\">Jennifer</option>\r\n                                                    <option name=\"qld\">Patricia</option> -->\r\n                                                </select>\r\n                                                <span class=\"caret\"></span>\r\n                                            </div>\r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Employee Email <small class=\"manidatory\">*</small></label>\r\n\t                                        <input disabled=\"\" type=\"email\" [value]=\"appointMentData.customerRequestForAppointment.email\" class=\"form-control\">\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Select Gender<small class=\"manidatory\">*</small></label>\r\n                                            <div class=\"custom-radio\"*ngIf=\"appointMentData.customerRequestForAppointment.gender=='Male'|| appointMentData.customerRequestForAppointment.gender=='male'\">\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input checked=\"checked\" type=\"radio\" id=\"radio01\" name=\"radio\" />\r\n                                                    <label for=\"radio01\">\r\n                                                        <span><span></span></span>Male\r\n                                                    </label>\r\n                                                </div>\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input type=\"radio\" id=\"radio02\" name=\"radio\" disabled=\"\" />\r\n                                                    <label for=\"radio02\">\r\n                                                        <span><span></span></span>Female\r\n                                                    </label>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"custom-radio\"*ngIf=\"appointMentData.customerRequestForAppointment.gender=='Female' || appointMentData.customerRequestForAppointment.gender=='female'\">\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input disabled=\"\" type=\"radio\" id=\"radio01\" name=\"radio\" />\r\n                                                    <label for=\"radio01\">\r\n                                                        <span><span></span></span>Male\r\n                                                    </label>\r\n                                                </div>\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input checked=\"checked\" type=\"radio\" id=\"radio02\" name=\"radio\" />\r\n                                                    <label for=\"radio02\">\r\n                                                        <span><span></span></span>Female\r\n                                                    </label>\r\n                                                </div>\r\n                                            </div>\r\n\t                                    </div>\r\n\t                                     <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Select Employee Services<small class=\"manidatory\">*</small></label>\r\n\t                                        <div class=\"custom-select\">\r\n                                               <input disabled=\"\" type=\"text\" [value]=\"appointMentData.requestedServiceByCustomer.services_eng\" class=\"form-control\">\r\n                                            </div>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Date <small class=\"manidatory\">*</small></label>\r\n\t                                       <mat-form-field>\r\n\t\t\t\t\t\t\t\t\t\t\t  <input matInput [matDatepicker]=\"picker\" placeholder=\"Choose a date\" [(ngModel)]=\"selectedDate\"  [ngModelOptions]=\"{standalone: true}\" (ngModelChange)=\"onDateChange()\">\r\n\t\t\t\t\t\t\t\t\t\t\t  <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n\t\t\t\t\t\t\t\t\t\t\t  <mat-datepicker #picker></mat-datepicker>\r\n\t\t\t\t\t\t\t\t\t\t\t</mat-form-field>\r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Change Time<small class=\"manidatory\">*</small></label>\r\n\t                                        <div class=\"input-icon\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-clock-o\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t\t <select class=\"form-control\" [(ngModel)]=\"selectedTime\" placeholder=\"Select Employee\" (change)=\"onTimeSelection(selectedTime)\" [ngModelOptions]=\"{standalone: true}\">\r\n                                                    <!-- <option disabled=\"\">{{selectedSlot()}}</option> -->\r\n                                                    <option *ngFor=\"let times of timeSlot;let i=index\" name=\"nsw\" [disabled]=\"getClass(times,selectedDate)==true\" [value]=\"times.start\">{{getHoursForSlots(times.start)}}:{{getMintForSlots(times.start)}} {{getAmPmForSlots(times.start)}} - {{getHoursForSlots(times.end)}}:{{getMintForSlots(times.end)}} {{getAmPmForSlots(times.end)}}</option>\r\n                                                    <!-- <option name=\"vic\">Mary</option>\r\n                                                    <option name=\"qld\" selected=\"selected\">Robert</option>\r\n                                                    <option name=\"qld\">Jennifer</option>\r\n                                                    <option name=\"qld\">Patricia</option> -->\r\n                                                </select>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t\t            \t\t\t</div>\r\n\t\t\t\t\t          \t<div class=\"modal-footerbtn\">\r\n\t\t\t\t\t\t          \t<span class=\"save-bt\">\r\n\t\t\t\t\t\t          \t\t<button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\" aria-label=\"Close\" (click)=\"onConfirm()\">\r\n\t\t\t\t\t\t          \t\t Confirm\r\n\t\t\t\t\t\t          \t\t</button>\r\n\t\t\t\t\t\t          \t</span>\r\n\t\t\t\t\t          \t</div>\r\n\t\t\t            \t</form>\r\n\t\t\t            </div>\r\n\t\t\t        </div>\r\n\t\t\t    </div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\r\n\r\n\t\t<div class=\"modal fade custom-modal\" id=\"view-bookinglist\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" *ngIf=\"appointMentData\">\r\n\t\t\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t\t\t    <div class=\"modal-content\">\r\n\t\t\t        <div class=\"modal-header\">\r\n\t\t\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t            \t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t            </button>\r\n\t\t\t            <h4 class=\"modal-title\" id=\"myModalLabel\">Edit Booking List</h4>\r\n\t\t\t        </div>\r\n\t\t\t        <div class=\"modal-body\">\r\n\t\t\t            <div class=\"add-emp-form\">\r\n\t\t\t            \t<form class=\"img-responsive\">\r\n\t\t            \t\t\t<div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t\t            \t\t\t\t<div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Customer Name <small class=\"manidatory\">*</small></label>\r\n\t                                        <input disabled=\"\" type=\"text\" [value]=\"appointMentData.customerRequestForAppointment.first_name\" class=\"form-control\">\r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Customer Number<small class=\"manidatory\">*</small></label>\r\n\t                                        <input disabled=\"\" type=\"text\" [value]=\"appointMentData.customerRequestForAppointment.contact_number\" class=\"form-control\">\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                \t<div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Employee Name<small class=\"manidatory\">*</small></label>\r\n\t                                        <div class=\"custom-select\">\r\n                                                <select disabled=\"\" class=\"form-control\" placeholder=\"Select Employee\">\r\n                                                    <option disabled=\"\">Select Employee</option>\r\n                                                    <option name=\"nsw\" selected=\"selected\">James</option>\r\n                                                    <option name=\"vic\">Mary</option>\r\n                                                    <option name=\"qld\" selected=\"selected\">Robert</option>\r\n                                                    <option name=\"qld\">Jennifer</option>\r\n                                                    <option name=\"qld\">Patricia</option>\r\n                                                </select>\r\n                                                <span class=\"caret\"></span>\r\n                                            </div>\r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Employee Email <small class=\"manidatory\">*</small></label>\r\n\t                                        <input disabled=\"\" type=\"email\" [value]=\"appointMentData.customerRequestForAppointment.email\" class=\"form-control\">\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Select Gender<small class=\"manidatory\">*</small></label>\r\n                                            <div class=\"custom-radio\"*ngIf=\"appointMentData.customerRequestForAppointment.gender=='Male' || appointMentData.customerRequestForAppointment.gender=='male'\">\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input checked=\"checked\" type=\"radio\" id=\"radio01\" name=\"radio\" />\r\n                                                    <label for=\"radio01\">\r\n                                                        <span><span></span></span>Male\r\n                                                    </label>\r\n                                                </div>\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input type=\"radio\" id=\"radio02\" name=\"radio\" disabled=\"\" />\r\n                                                    <label for=\"radio02\">\r\n                                                        <span><span></span></span>Female\r\n                                                    </label>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"custom-radio\"*ngIf=\"appointMentData.customerRequestForAppointment.gender=='Female' || appointMentData.customerRequestForAppointment.gender=='female'\">\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input disabled=\"\" type=\"radio\" id=\"radio01\" name=\"radio\" />\r\n                                                    <label for=\"radio01\">\r\n                                                        <span><span></span></span>Male\r\n                                                    </label>\r\n                                                </div>\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input checked=\"checked\" type=\"radio\" id=\"radio02\" name=\"radio\" />\r\n                                                    <label for=\"radio02\">\r\n                                                        <span><span></span></span>Female\r\n                                                    </label>\r\n                                                </div>\r\n                                            </div>\r\n\t                                    </div>\r\n\t                                     <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Select Employee Services<small class=\"manidatory\">*</small></label>\r\n\t                                        <div class=\"custom-select\">\r\n                                                <input disabled=\"\" type=\"text\" [value]=\"appointMentData.requestedServiceByCustomer.services_eng\" class=\"form-control\">\r\n                                            </div>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Date <small class=\"manidatory\">*</small></label>\r\n\t                                       <input disabled=\"\" class=\"form-control input-medium date-picker\" size=\"16\" type=\"text\" [value]=\"appointMentData.date\"/>\r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Change Time<small class=\"manidatory\">*</small></label>\r\n\t                                        <div class=\"input-icon\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-clock-o\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<input disabled=\"\" type=\"text\" class=\"form-control timepicker timepicker-24\">\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t\t            \t\t\t</div>\r\n\t\t\t\t\t          \t<div class=\"modal-footerbtn\">\r\n\t\t\t\t\t\t          \t<span class=\"save-bt\">\r\n\t\t\t\t\t\t          \t\t<button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t\t\t\t          \t\t Confirm\r\n\t\t\t\t\t\t          \t\t</button>\r\n\t\t\t\t\t\t          \t</span>\r\n\t\t\t\t\t          \t</div>\r\n\t\t\t            \t</form>\r\n\t\t\t            </div>\r\n\t\t\t        </div>\r\n\t\t\t    </div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\r\n\r\n"

/***/ }),

/***/ "../../../../../src/app/header-three-layout/booking-page/booking-page.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-three-layout/booking-page/booking-page.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BookingPageComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var BookingPageComponent = (function () {
    function BookingPageComponent(commonService, saloonService) {
        this.commonService = commonService;
        this.saloonService = saloonService;
        this.p = 1;
        this.saloonDetails = JSON.parse(localStorage['userdetails']);
        this.saloonId = this.saloonDetails.id;
    }
    BookingPageComponent.prototype.ngOnInit = function () {
        this.getAppointMentList();
        this.getAllSaloonData();
    };
    BookingPageComponent.prototype.getAppointMentList = function () {
        var _this = this;
        this.saloonService.getAppointmentDetailsForSaloon(this.saloonId).subscribe(function (data) {
            _this.appointMents = data.data;
        }, function (err) {
        });
    };
    BookingPageComponent.prototype.onEdit = function (appointMentData) {
        this.appointmentId = appointMentData.id;
        this.appointMentData = appointMentData;
        console.log(appointMentData);
        this.serviceIdForEdit = appointMentData.services_id;
        this.getEmployeesForRelatedService(appointMentData.services_id, appointMentData.emp_id);
        this.selectedDate = appointMentData.date;
        var start_time = appointMentData.start_time.split(':');
        var time1 = parseInt(start_time[0]) * 60 + parseInt(start_time[1]);
        this.selectedTime = time1;
        console.log("selectedTime" + this.selectedTime);
    };
    BookingPageComponent.prototype.onView = function (appointment) {
        this.appointMentData = appointment;
    };
    BookingPageComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.221.208.210/public/beauty-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    BookingPageComponent.prototype.getHours = function (value) {
        // console.log(value);
        var value2 = value.split(':');
        var value3 = parseInt(value2[0]);
        if (value3 > 12) {
            var a = value3 - 12;
            return '0' + a;
        }
        else {
            if (value3 < 10) {
                return '0' + value3;
            }
            else {
                return value3;
            }
        }
    };
    BookingPageComponent.prototype.getMin = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[1]);
        if (value3 < 10) {
            return '0' + value3;
        }
        else {
            return value3;
        }
    };
    BookingPageComponent.prototype.getAmPm = function (value) {
        var value2 = value.split(':');
        var value3 = parseInt(value2[0]);
        if (value3 > 11) {
            return 'Pm';
        }
        else {
            return 'Am';
        }
    };
    BookingPageComponent.prototype.getHoursForSlots = function (time) {
        var a = Math.floor(time / 60);
        if (a < 10) {
            return '0' + a;
        }
        else {
            if (a > 12) {
                var b = a - 12;
                return '0' + b; // code...
            }
            else {
                return a;
            }
        }
    };
    BookingPageComponent.prototype.getMintForSlots = function (time) {
        var a = Math.floor(time % 60);
        if (a < 10) {
            return '0' + a;
        }
        else {
            return a;
        }
    };
    BookingPageComponent.prototype.getAmPmForSlots = function (time) {
        var a = Math.floor(time / 60);
        if (a > 11) {
            return 'PM';
        }
        else {
            return 'AM';
        }
    };
    BookingPageComponent.prototype.getHoursForSlotsForSend = function (time) {
        var a = Math.floor(time / 60);
        if (a < 10) {
            return '0' + a;
        }
        else {
            return a;
        }
    };
    BookingPageComponent.prototype.getMintForSlotsForSend = function (time) {
        var a = Math.floor(time % 60);
        if (a < 10) {
            return '0' + a;
        }
        else {
            return a;
        }
    };
    // getEmployeeList(){
    //   this.saloonService.getEmployeeById(this.saloonId).subscribe(data=>{
    //       this.employeeList=data.data
    //   },err=>{
    //   })
    // }
    // getserviceList(){
    //     this.saloonService.getservicesById(this.saloonId)
    //     .subscribe((data)=>{
    //         console.log(data);
    //         if(data.response){
    //             this.serviceList=data.data
    //             for (var i = 0; i < this.serviceList.length; ++i) {
    //                list.push({id:this.serviceList[i].servicesData.id,name:this.serviceList[i].servicesData.services_eng})
    //             }
    //             this.myOptions2=list
    //           // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
    //           // this.router.navigate(['/header-three-layout/service-list']);
    //         }
    //      }) 
    // }
    BookingPageComponent.prototype.getAllSaloonData = function () {
        var _this = this;
        this.commonService.getAllServiceBySaloon(this.saloonId).subscribe(function (data) {
            _this.allSaloonData = data.data;
        }, function (err) {
            console.log(err);
        });
    };
    BookingPageComponent.prototype.getEmployeesForRelatedService = function (serviceId, empId) {
        console.log(serviceId);
        console.log(empId);
        var saloonData = this.allSaloonData.saloonServices.filter(function (f) { return f.service_id == serviceId; });
        if (saloonData.length > 0) {
            // console.log(JSON.stringify(saloonData[0].servicesData.serByEmplnServiceData))
            this.employeeList = saloonData[0].servicesData.serByEmplnServiceData;
            this.serviceTime = saloonData[0].time;
            var employee = this.employeeList.filter(function (arg) { return arg.employee_id == empId; });
            console.log(employee);
            var appointment = void 0;
            if (employee.length > 0) {
                this.selectedEmployee = employee[0].employeeDetails.first_name;
                console.log(this.selectedEmployee);
                this.employeeAppointment = employee[0].employeeDetails.Appointment;
            }
            this.onTimeSelect();
        }
    };
    BookingPageComponent.prototype.onTimeSelect = function () {
        this.timeSlot = [];
        console.log(this.timeSlot.length);
        var openingTime = this.allSaloonData.opening_time.split(':');
        var closingTime = this.allSaloonData.closing_time.split(':');
        var time1 = parseInt(openingTime[0]) * 60 + parseInt(openingTime[1]);
        var time2 = parseInt(closingTime[0]) * 60 + parseInt(closingTime[1]);
        var length = (time2 - time1) / parseInt(this.serviceTime);
        if (length > 0) {
            var time3 = time1;
            var time4 = time3 + parseInt(this.serviceTime);
            for (var i = 0; i < length; ++i) {
                if (time3 < time2 && time4 < time2) {
                    this.timeSlot.push({ start: time3, end: time4, checkStatus: false });
                    time3 = time3 + parseInt(this.serviceTime);
                    time4 = time4 + parseInt(this.serviceTime);
                }
            }
        }
    };
    BookingPageComponent.prototype.onTimeSelection = function (selectedTime) {
        console.log(selectedTime);
        this.startTimeForEdit = selectedTime;
        this.startTimeForEdit = this.getHoursForSlotsForSend(this.startTimeForEdit) + ":" + this.getMintForSlotsForSend(this.startTimeForEdit);
        this.endTimeForEdit = parseInt(selectedTime) + parseInt(this.serviceTime);
        this.endTimeForEdit = this.getHoursForSlotsForSend(this.endTimeForEdit) + ":" + this.getMintForSlotsForSend(this.endTimeForEdit);
        console.log(this.endTimeForEdit + "endTimeForEdit");
        console.log(this.startTimeForEdit + "startTimeForEdit");
    };
    BookingPageComponent.prototype.onDateChange = function () {
        var selecteddate = this.selectedDate.getDate();
        var selectedMonth = this.selectedDate.getMonth() + 1;
        var selectedyear = this.selectedDate.getFullYear();
        var date1;
        var month1;
        var year;
        if (selecteddate < 10) {
            date1 = '0' + selecteddate;
        }
        else {
            date1 = selecteddate;
        }
        if (selectedMonth < 10) {
            month1 = '0' + selectedMonth;
        }
        else {
            month1 = selectedMonth;
        }
        this.selectedDate = selectedyear + '-' + month1 + '-' + date1;
        console.log(this.selectedDate);
    };
    BookingPageComponent.prototype.getClass = function (time, date) {
        if (this.employeeAppointment.length > 0) {
            var currentDate_appontment = this.employeeAppointment.filter(function (arg) { return arg.date == date; });
            for (var i = 0; i < currentDate_appontment.length; ++i) {
                var time1 = currentDate_appontment[i].start_time.split(':');
                var time2 = currentDate_appontment[i].end_time.split(':');
                var time3 = parseInt(time1[0]) * 60 + parseInt(time1[1]);
                var time4 = parseInt(time2[0]) * 60 + parseInt(time2[1]);
                // console.log('time3',time3)
                // console.log('time4',time4)
                // console.log('start',time.start)
                // console.log('end',time.end)
                if (time.start < time3 && time.end <= time3) {
                    // return ''
                }
                else if (time.start > time4 && time.end > time4) {
                    // return ''
                }
                else if (time.start <= time3 && time.end <= time4) {
                    // this.timeSlot[index].checkStatus=true
                    return true;
                }
                else if (time.start > time3 && time.end <= time4) {
                    // this.timeSlot[index].checkStatus=true
                    return true;
                }
                else if (time.start < time3 && time.end > time4) {
                    // code...
                    // this.timeSlot[index].checkStatus=true
                    return true;
                }
                else if (time.start < time4 && time.end > time4) {
                    // this.timeSlot[index].checkStatus=true
                    return true;
                }
                // }
            }
        }
    };
    BookingPageComponent.prototype.selectedSlot = function () {
        var startTimehr = this.getHours(this.appointMentData.start_time);
        var startTimemin = this.getMin(this.appointMentData.start_time);
        var startTimeamPm = this.getAmPm(this.appointMentData.start_time);
        var endTimehr = this.getHours(this.appointMentData.end_time);
        var endTimemin = this.getMin(this.appointMentData.end_time);
        var endTimeamPm = this.getAmPm(this.appointMentData.end_time);
        var aa = startTimehr + ":" + startTimemin + " " + startTimeamPm + " " + "-" + " " + endTimehr + ":" + endTimemin + " " + endTimeamPm;
        return aa;
    };
    BookingPageComponent.prototype.onEmployeeChange = function (id) {
        console.log(id);
        this.selectedEmployeeIdForEdit = id;
        this.getEmployeesForRelatedService(this.serviceIdForEdit, id);
    };
    BookingPageComponent.prototype.onConfirm = function () {
        var _this = this;
        console.log("sdfnbdsnh");
        var editAppointmentData = {
            emp_id: this.selectedEmployeeIdForEdit,
            date: this.selectedDate,
            start_time: this.startTimeForEdit,
            end_time: this.endTimeForEdit
        };
        this.saloonService.editAppointmentByCustomer(this.appointmentId, editAppointmentData).subscribe(function (data) {
            console.log(data);
            if (data.response == 1) {
                _this.ngOnInit();
            }
        }, function (err) {
            console.log(err);
        });
    };
    BookingPageComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-booking-page',
            template: __webpack_require__("../../../../../src/app/header-three-layout/booking-page/booking-page.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-three-layout/booking-page/booking-page.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__providers_common_service__["a" /* CommonService */], __WEBPACK_IMPORTED_MODULE_1__providers_saloon_service__["a" /* SaloonService */]])
    ], BookingPageComponent);
    return BookingPageComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/booking-page/booking-page.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingPageModule", function() { return BookingPageModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__booking_page_routing_module__ = __webpack_require__("../../../../../src/app/header-three-layout/booking-page/booking-page-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__booking_page_component__ = __webpack_require__("../../../../../src/app/header-three-layout/booking-page/booking-page.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__angular_material_datepicker__ = __webpack_require__("../../../material/esm5/datepicker.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__angular_material_form_field__ = __webpack_require__("../../../material/esm5/form-field.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__angular_material__ = __webpack_require__("../../../material/esm5/material.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};













var BookingPageModule = (function () {
    function BookingPageModule() {
    }
    BookingPageModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_10__angular_forms__["e" /* FormsModule */], __WEBPACK_IMPORTED_MODULE_9__angular_material__["a" /* MatInputModule */], __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__booking_page_routing_module__["a" /* BookingPageRoutingModule */], __WEBPACK_IMPORTED_MODULE_5_ngx_pagination__["a" /* NgxPaginationModule */], __WEBPACK_IMPORTED_MODULE_7__angular_material_datepicker__["a" /* MatDatepickerModule */], __WEBPACK_IMPORTED_MODULE_8__angular_material_form_field__["c" /* MatFormFieldModule */], __WEBPACK_IMPORTED_MODULE_9__angular_material__["b" /* MatNativeDateModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__booking_page_component__["a" /* BookingPageComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_4__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_6__providers_common_service__["a" /* CommonService */], __WEBPACK_IMPORTED_MODULE_9__angular_material__["d" /* NativeDateAdapter */]]
        })
    ], BookingPageModule);
    return BookingPageModule;
}());



/***/ })

});
//# sourceMappingURL=booking-page.module.chunk.js.map