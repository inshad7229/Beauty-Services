webpackJsonp(["home-page.module"],{

/***/ "../../../../../src/app/header-one-layout/home-page/home-page-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HomePageRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__home_page_component__ = __webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__home_page_component__["a" /* HomePageComponent */]
    }
];
var HomePageRoutingModule = (function () {
    function HomePageRoutingModule() {
    }
    HomePageRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], HomePageRoutingModule);
    return HomePageRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-one-layout/home-page/home-page.component.html":
/***/ (function(module, exports) {

module.exports = "        \r\n       \r\n <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n         <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n </div>\r\n        <section class=\"slider-sec\">\r\n            <div data-pause=\"false\" data-ride=\"carousel\" class=\"banner carousel slide carousel-fade\" id=\"slider\">\r\n                <!-- Wrapper for slides -->\r\n                <div role=\"listbox\" class=\"carousel-inner\">\r\n                     <div style=\"background-image:url(assets/img/slider-1.png);\" class=\"item active\">\r\n                        <div class=\"caption-info\">\r\n                            <div class=\"container\">\r\n                                <div class=\"row\">\r\n                                    <div class=\"col-sm-12 col-md-10 col-md-offset-1\">\r\n                                        <div class=\"caption-info-inner text-center\">\r\n                                            <h1 class=\"animated flipInX\">We Make People Awesome</h1>\r\n                                            <p class=\"animated lightSpeedIn\">Lorem Ipsum is simply dummy text of the printing and typeseatting industry. Lorem Ipsum has been the industry's</p>\r\n                                            <a class=\"animated fadeIn btn-primary page-scroll\" href=\"#contact-us\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div style=\"background-image:url(assets/img/slider-2.jpg);\" class=\"item\">\r\n                        <div class=\"caption-info\">\r\n                            <div class=\"container\">\r\n                                <div class=\"row\">\r\n                                    <div class=\"col-sm-12 col-md-10 col-md-offset-1\">\r\n                                        <div class=\"caption-info-inner text-center\">\r\n                                            <h1 class=\"animated fadeInDown\">Saloons that Suits your personality</h1>\r\n                                            <p class=\"animated fadeInUp\">Lorem Ipsum is simply dummy text of the printing and typeseatting industry. Lorem Ipsum has been the industry's</p>\r\n                                            <a class=\"animated fadeInUp btn-primary page-scroll\" href=\"#packages\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div style=\"background-image:url(assets/img/slider-3.jpg);\" class=\"item\">\r\n                        <div class=\"caption-info\">\r\n                            <div class=\"container\">\r\n                                <div class=\"row\">\r\n                                    <div class=\"col-sm-12 col-md-10 col-md-offset-1\">\r\n                                        <div class=\"caption-info-inner text-center\">\r\n                                            <h1 class=\"animated fadeInLeft\">Find your Stylist Today</h1>\r\n                                            <p class=\"animated fadeInLeft\">Lorem Ipsum is simply dummy text of the printing and typeseatting industry. Lorem Ipsum has been the industry's</p>\r\n                                            <a class=\"animated fadeInLeft btn-primary page-scroll\" href=\"#hot-deals\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <!--end carousel-inner-->\r\n                <!-- Controls -->\r\n                <a data-slide=\"prev\" href=\"#slider\" class=\"control left\"><i class=\"fa fa-arrow-left\"></i></a>\r\n                <a data-slide=\"next\" href=\"#slider\" class=\"right control\"><i class=\"fa fa-arrow-right\"></i></a>\r\n            </div>\r\n            <div class=\"search-form\">\r\n                <div class=\"container\">\r\n                    <form class=\"horizontal-form customize\">\r\n                        <div class=\"col-md-12 col-sm-12\">\r\n                            <div class=\"col-md-5 col-sm-5 col-xs-12 no-padding\">\r\n                                <input  type=\"text\" class=\"form-control input1\" name=\"password\" placeholder=\"Find a service or saloon\">\r\n                            </div>\r\n                            <div class=\"col-md-5 col-sm-5 col-xs-12 no-padding\">\r\n                                <input type=\"text\" class=\"form-control input2\"  placeholder=\"Enter your area\">\r\n                            </div>\r\n                            <div class=\"col-md-2 col-sm-2 col-xs-12 no-padding\">\r\n                                <a class=\"btn custom-btn\" href=\"javascript:void(0);\">Search</a>\r\n                            </div>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"how-it-works-sec\">\r\n            <div class=\"section-title text-center\">\r\n                <h2>How it <span class=\"pink\">Works</span></h2>\r\n            </div>\r\n            <div class=\"container\">\r\n                <div class=\"col-md-4 col-sm-4 col-xs-12\">\r\n                    <div class=\"step-works wow fadeInLeft\" wow-data-delay=\"0.4s\">\r\n                        <div class=\"content-section\">\r\n                            <div class=\"works-img\">\r\n                                <img src=\"assets/img/businesswoman.svg\" alt=\"images\">\r\n                            </div>\r\n                            <h4>Professionals</h4>\r\n                            <p>Select best, experienced, friendly, and background-checked professionals </p>              \r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-md-4 col-sm-4 col-xs-12\">\r\n                    <div class=\"step-works wow fadeInLeft\" wow-data-delay=\"0.6s\">\r\n                        <div class=\"content-section book-sec\">\r\n                            <div class=\"works-img\">\r\n                                <img src=\"assets/img/book.svg\" alt=\"images\">\r\n                            </div>\r\n                            <h4>Book</h4>\r\n                            <p>One-stop online platform for both men and women to book all the appointments.</p>                     \r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-md-4 col-sm-4 col-xs-12\">\r\n                    <div class=\"step-works wow fadeInLeft\" wow-data-delay=\"0.8s\">\r\n                        <div class=\"content-section\">\r\n                            <div class=\"works-img enjoy\">\r\n                                <img src=\"assets/img/enjoy.svg\" alt=\"images\">\r\n                            </div>\r\n                            <h4>Enjoy a hassle free service</h4>\r\n                            <p>Relax and Enjoy our service provided by the fully-equipped professionals</p>          \r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"our-services\">\r\n            <div id=\"services\" class=\"services item\">\r\n                <div class=\"section-title text-center\">\r\n                    <h2>Our <span class=\"pink\">Services</span></h2>\r\n                </div>\r\n                <div class=\"container\">\r\n                    <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/massage-therapy.jpg\">\r\n                                        <div class=\"img-content\">\r\n                                            Massage Treatments <i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/facials.jpg\">\r\n                                        <div class=\"img-content\">\r\n                                            Top Facial Treatments <i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/img-7.png\">\r\n                                        <div class=\"img-content\">\r\n                                            Elite Hair Wash <i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/img-1.png\">\r\n                                        <div class=\"img-content\">\r\n                                            Nail Treatment <i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/color.png\">\r\n                                        <div class=\"img-content\">\r\n                                            Top Hair Color Salons<i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/img-4.png\">\r\n                                        <div class=\"img-content\">\r\n                                            Top Hair Cut Salons<i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"trading-style\">\r\n            <div class=\"section-title text-center\">\r\n                <h2>TRENDING <span class=\"pink\">STYLES</span></h2>\r\n            </div>\r\n            <div class=\"container\">\r\n                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                    <div class=\"owl_otr_div wow fadeInLeft\" data-wow-delay=\"0.5s\">\r\n                        <div class=\"owl-demo1 owl-carousel\">\r\n                            <div class=\"item\">\r\n                                <div class=\"news_blk\">\r\n                                    <img src=\"assets/img/1-.jpg\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\">\r\n                                <div class=\"news_blk\">\r\n                                    <img src=\"assets/img/2-.jpg\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\">\r\n                                <div class=\"news_blk\">\r\n                                    <img src=\"assets/img/3-.jpg\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\">\r\n                                <div class=\"news_blk\">\r\n                                    <img src=\"assets/img/4-.jpg\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\">\r\n                                <div class=\"news_blk\">\r\n                                    <img src=\"assets/img/5.jpg\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\">\r\n                                <div class=\"news_blk\">\r\n                                    <img src=\"assets/img/6.jpg\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div> \r\n                            <div class=\"item\">\r\n                                <div class=\"news_blk\">\r\n                                    <img src=\"assets/img/7.jpg\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\">\r\n                                <div class=\"news_blk\">\r\n                                    <img src=\"assets/img/8.jpg\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>                                               \r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"professional-section\">\r\n            <div class=\"container\">\r\n                <div class=\"row\">\r\n                    <div class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                        <div class=\"stats-bottom text-center\">\r\n                            <div class=\"col-lg-3 col-md-3 col-sm-3 col-xs-6 p-0\">\r\n                                <div class=\"wrap-count\">\r\n                                    <h3>Appointments</h3>\r\n                                    <span class=\"count\" data-counter=\"counterup\" data-value=\"2450\">2450</span>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-md-3 col-sm-3 col-xs-6 p-0\">\r\n                                <div class=\"wrap-count\">\r\n                                    <h3>Saloons</h3>\r\n                                    <span class=\"count\" data-counter=\"counterup\" data-value=\"51750\">51750</span>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-md-3 col-sm-3 col-xs-6 p-0\">\r\n                                <div class=\"wrap-count\">\r\n                                    <h3>Satisfied Customers</h3>\r\n                                    <span class=\"count\" data-counter=\"counterup\" data-value=\"1,205,000\">1,205,000</span>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-md-3 col-sm-3 col-xs-6 p-0\">\r\n                                <div class=\"wrap-count\">\r\n                                    <h3>Average Rating</h3>\r\n                                    <span class=\"count\" data-counter=\"counterup\" data-value=\"4.5\">4.5</span><span class=\"rate-star\">Star</span>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"mobile-app-sec\">\r\n            <div class=\"container\">\r\n                <div class=\"section-title text-center\">\r\n                    <h2>Book on the <span class=\"pink\">Go</span></h2>\r\n                </div>\r\n                <div class=\"slider-outer\">\r\n                    <div id=\"demo\" class=\"app-custom-slider\">\r\n                        <div class=\"span12\">\r\n                            <div class=\"main-slider wow bounceInUp\">\r\n                                <div class=\"iphone-frame\">\r\n                                    <img src=\"assets/img/iphone.png\" alt=\"Iphone\">\r\n                                </div>\r\n                                <div id=\"sync1\" class=\"owl-carousel test main-img-outer\">\r\n                                    <div class=\"item\">\r\n                                        <div class=\"slider-main-img\" style=\"\">                                   \r\n                                            <img src=\"assets/img/search.jpg\">\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item\">\r\n                                        <div class=\"slider-main-img\" style=\"\">                                   \r\n                                            <img src=\"assets/img/call.jpg\">\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item\">\r\n                                        <div class=\"slider-main-img\" style=\"\">                                   \r\n                                            <img src=\"assets/img/near-map.jpg\">\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item\">\r\n                                        <div class=\"slider-main-img\" style=\"\">                                   \r\n                                            <img src=\"assets/img/plans.jpg\">\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"thumbnail-slider\">\r\n                                <div id=\"sync2\" class=\"owl-carousel thumbnail-outer\">\r\n                                    <div class=\"item wow bounceInLeft\" data-wow-duration=\"0.8s\" >\r\n                                        <div class=\"slider-thumbnail-img\">\r\n                                            <i class=\"icon icon-map\"></i>\r\n                                            <h4>Find Professionals</h4>                                \r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item wow bounceInUp\" data-wow-duration=\"1.4s\" >\r\n                                        <div class=\"slider-thumbnail-img\">\r\n                                            <i class=\"icon icon-call-out\"></i>\r\n                                            <h4>Book</h4>                                     \r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item wow bounceInRight\" data-wow-duration=\"2.6s\" >\r\n                                        <div class=\"slider-thumbnail-img\">\r\n                                            <i class=\"icon icon-people\"></i>\r\n                                            <h4>Nearest Saloons</h4>                                       \r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item wow bounceInDown\" data-wow-duration=\"2.0s\" >\r\n                                        <div class=\"slider-thumbnail-img\">\r\n                                            <i class=\"icon icon-credit-card\"></i>\r\n                                            <h4>Pay Online</h4>                                       \r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class=\"content-slider wow fadeIn\" data-wow-delay=\"0.6s\" >\r\n                                    <div id=\"sync1_copy\" class=\"owl-carousel\">\r\n                                        <div class=\"item\">\r\n                                            <div class=\"slider-con\" style=\"\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                <p class=\"left-big\">Browse our selection of vetted-professional beauty therapists, hairdressers and makeup artists</p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"item\">\r\n                                            <div class=\"slider-con\" style=\"\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                <p class=\"left-big\">You're booked! Simply wait for your therapist, hair stylist or makeup artist to arrive at the scheduled time and enjoy your treatment</p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"item\">\r\n                                            <div class=\"slider-con\" style=\"\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                <p class=\"left-big\">Find the best and fully equipped saloons near you.</p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"item\">\r\n                                            <div class=\"slider-con\" style=\"\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                <p class=\"left-big\">We'll confirm your appointment and take care of payment electronically and securely.</p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"download-link\">\r\n                                        <a href=\"#\" class=\"link-download\">\r\n                                            <img src=\"assets/img/app-store.png\" alt=\"app-store\" class=\"img-responsive\">\r\n                                        </a>\r\n                                        <a href=\"#\" class=\"link-download\">\r\n                                            <img src=\"assets/img/google-play.png\" alt=\"play-store\" class=\"img-responsive\">\r\n                                        </a>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-one-layout/home-page/home-page.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-one-layout/home-page/home-page.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HomePageComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var HomePageComponent = (function () {
    function HomePageComponent(commonServices) {
        this.commonServices = commonServices;
    }
    HomePageComponent.prototype.ngOnInit = function () {
        var sync1 = $("#sync1");
        var sync2 = $("#sync2");
        var sync1_copy = $("#sync1_copy");
        sync1.owlCarousel({
            singleItem: true,
            slideSpeed: 1000,
            navigation: false,
            pagination: false,
            afterAction: syncPosition,
            responsiveRefreshRate: 200,
            autoPlay: true,
        });
        sync1_copy.owlCarousel({
            singleItem: true,
            slideSpeed: 1000,
            navigation: false,
            pagination: false,
            afterAction: syncPosition,
            responsiveRefreshRate: 200,
            autoPlay: true,
        });
        sync2.owlCarousel({
            items: 4,
            itemsDesktop: [1199, 4],
            itemsDesktopSmall: [979, 4],
            itemsTablet: [768, 4],
            itemsMobile: [479, 4],
            pagination: false,
            responsiveRefreshRate: 100,
            afterInit: function (el) {
                el.find(".owl-item").eq(0).addClass("synced");
            }
        });
        function syncPosition(el) {
            var current = this.currentItem;
            $("#sync2")
                .find(".owl-item")
                .removeClass("synced")
                .eq(current)
                .addClass("synced");
            if ($("#sync2").data("owlCarousel") !== undefined) {
                center(current);
            }
        }
        $("#sync2").on("click", ".owl-item", function (e) {
            e.preventDefault();
            var number = $(this).data("owlItem");
            sync1.trigger("owl.goTo", number);
        });
        $("#sync2").on("click", ".owl-item", function (e) {
            e.preventDefault();
            var number = $(this).data("owlItem");
            sync1_copy.trigger("owl.goTo", number);
        });
        function center(number) {
            var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
            var num = number;
            var found = false;
            for (var i in sync2visible) {
                if (num === sync2visible[i]) {
                    var found = true;
                }
            }
            if (found === false) {
                if (num > sync2visible[sync2visible.length - 1]) {
                    sync2.trigger("owl.goTo", num - sync2visible.length + 2);
                }
                else {
                    if (num - 1 === -1) {
                        num = 0;
                    }
                    sync2.trigger("owl.goTo", num);
                }
            }
            else if (num === sync2visible[sync2visible.length - 1]) {
                sync2.trigger("owl.goTo", sync2visible[1]);
            }
            else if (num === sync2visible[0]) {
                sync2.trigger("owl.goTo", num - 1);
            }
        }
        var owl = $(".owl-demo1");
        owl.owlCarousel({
            items: 4,
            itemsDesktop: [1000, 3],
            itemsDesktopSmall: [900, 3],
            itemsTablet: [600, 2],
            itemsMobile: [480, 1] // itemsMobile disabled - inherit from itemsTablet option
        });
        var wow = new WOW({
            animateClass: 'animated',
            offset: 100,
            callback: function (box) {
                console.log("WOW: animating <" + box.tagName.toLowerCase() + ">");
            }
        });
        wow.init();
        jQuery(document).ready(function ($) {
            $('.count').counterUp({
                delay: 10,
                time: 1000
            });
        });
        this.getserviceList();
    };
    HomePageComponent.prototype.getserviceList = function () {
        var _this = this;
        this.waitLoader = true;
        this.commonServices.getCategoryWithServices()
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.categoryList = data.data;
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    HomePageComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-home-page',
            template: __webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__providers_common_service__["a" /* CommonService */]])
    ], HomePageComponent);
    return HomePageComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-one-layout/home-page/home-page.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__home_page_routing_module__ = __webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__home_page_component__ = __webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var HomePageModule = (function () {
    function HomePageModule() {
    }
    HomePageModule.prototype.ngOnInit = function () {
    };
    HomePageModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__home_page_routing_module__["a" /* HomePageRoutingModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__home_page_component__["a" /* HomePageComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_4__providers_common_service__["a" /* CommonService */]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ })

});
//# sourceMappingURL=home-page.module.chunk.js.map