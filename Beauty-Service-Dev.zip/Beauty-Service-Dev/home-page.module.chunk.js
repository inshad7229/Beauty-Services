webpackJsonp(["home-page.module"],{

/***/ "../../../../../src/app/header-one-layout/home-page/home-page-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HomePageRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__home_page_component__ = __webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__home_page_component__["a" /* HomePageComponent */]
    }
];
var HomePageRoutingModule = (function () {
    function HomePageRoutingModule() {
    }
    HomePageRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], HomePageRoutingModule);
    return HomePageRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-one-layout/home-page/home-page.component.html":
/***/ (function(module, exports) {

module.exports = "        \r\n       \r\n <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n         <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n </div>\r\n        <section class=\"slider-sec\">\r\n            <div data-pause=\"false\" data-ride=\"carousel\" class=\"banner carousel slide carousel-fade\" id=\"slider\">\r\n                <!-- Wrapper for slides -->\r\n                <div role=\"listbox\" class=\"carousel-inner\">\r\n                     <div style=\"background-image:url(assets/img/slider-1.png);\" class=\"item active\">\r\n                        <div class=\"caption-info\">\r\n                            <div class=\"container\">\r\n                                <div class=\"row\">\r\n                                    <div class=\"col-sm-12 col-md-10 col-md-offset-1\">\r\n                                        <div class=\"caption-info-inner text-center\">\r\n                                            <h1 class=\"animated flipInX\">We Make People Awesome</h1>\r\n                                            <p class=\"animated lightSpeedIn\">Lorem Ipsum is simply dummy text of the printing and typeseatting industry. Lorem Ipsum has been the industry's</p>\r\n                                            <a class=\"animated fadeIn btn-primary page-scroll\" href=\"#contact-us\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div style=\"background-image:url(assets/img/slider-2.jpg);\" class=\"item\">\r\n                        <div class=\"caption-info\">\r\n                            <div class=\"container\">\r\n                                <div class=\"row\">\r\n                                    <div class=\"col-sm-12 col-md-10 col-md-offset-1\">\r\n                                        <div class=\"caption-info-inner text-center\">\r\n                                            <h1 class=\"animated fadeInDown\">Saloons that Suits your personality</h1>\r\n                                            <p class=\"animated fadeInUp\">Lorem Ipsum is simply dummy text of the printing and typeseatting industry. Lorem Ipsum has been the industry's</p>\r\n                                            <a class=\"animated fadeInUp btn-primary page-scroll\" href=\"#packages\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div style=\"background-image:url(assets/img/slider-3.jpg);\" class=\"item\">\r\n                        <div class=\"caption-info\">\r\n                            <div class=\"container\">\r\n                                <div class=\"row\">\r\n                                    <div class=\"col-sm-12 col-md-10 col-md-offset-1\">\r\n                                        <div class=\"caption-info-inner text-center\">\r\n                                            <h1 class=\"animated fadeInLeft\">Find your Stylist Today</h1>\r\n                                            <p class=\"animated fadeInLeft\">Lorem Ipsum is simply dummy text of the printing and typeseatting industry. Lorem Ipsum has been the industry's</p>\r\n                                            <a class=\"animated fadeInLeft btn-primary page-scroll\" href=\"#hot-deals\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <!--end carousel-inner-->\r\n                <!-- Controls -->\r\n                <a data-slide=\"prev\" href=\"#slider\" class=\"control left\"><i class=\"fa fa-arrow-left\"></i></a>\r\n                <a data-slide=\"next\" href=\"#slider\" class=\"right control\"><i class=\"fa fa-arrow-right\"></i></a>\r\n            </div>\r\n            <div class=\"search-form\">\r\n                <div class=\"container\">\r\n                    <form class=\"horizontal-form customize\">\r\n                        <div class=\"col-md-12 col-sm-12\">\r\n                            <div class=\"col-md-5 col-sm-5 col-xs-12 no-padding\">\r\n                                <input  type=\"text\" matInput [matAutocomplete]=\"auto\" class=\"form-control input1\" name=\"password\" placeholder=\"Find a saloon\" [formControl]=\"myControl\">\r\n                                <mat-autocomplete #auto=\"matAutocomplete\">\r\n                                  <mat-option *ngFor=\"let option of filteredSalons | async\" [value]=\"option.saloon_name\" (click)=\"onSelectedSalon(option)\">\r\n                                    {{ option.saloon_name }}\r\n                                  </mat-option>\r\n                                </mat-autocomplete>\r\n                            </div>\r\n                            <div class=\"col-md-5 col-sm-5 col-xs-12 no-padding\">\r\n                                <input type=\"text\" matInput  class=\"form-control input2\"  placeholder=\"Enter your area\" [formControl]=\"myControlCities\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"off\"   #search >\r\n                               <!--  <mat-autocomplete #city=\"matAutocomplete\">\r\n                                  <mat-option *ngFor=\"let option of filteredCity | async\" [value]=\"option.city\" (click)=\"onCitySelection(option.city)\">\r\n                                    {{ option.city }}\r\n                                  </mat-option>\r\n                                </mat-autocomplete> -->\r\n                            </div>\r\n                            <div class=\"col-md-2 col-sm-2 col-xs-12 no-padding\">\r\n                                <a class=\"btn custom-btn\" (click)=\"onSearch()\">Search</a>\r\n                            </div>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"how-it-works-sec\">\r\n            <div class=\"section-title text-center\">\r\n                <h2>How it <span class=\"pink\">Works</span></h2>\r\n            </div>\r\n            <div class=\"container\">\r\n                <div class=\"col-md-4 col-sm-4 col-xs-12\">\r\n                    <div class=\"step-works wow fadeInLeft\" wow-data-delay=\"0.4s\">\r\n                        <div class=\"content-section\">\r\n                            <div class=\"works-img\">\r\n                                <img src=\"assets/img/businesswoman.svg\" alt=\"images\">\r\n                            </div>\r\n                            <h4>Professionals</h4>\r\n                            <p>Select best, experienced, friendly, and background-checked professionals </p>              \r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-md-4 col-sm-4 col-xs-12\">\r\n                    <div class=\"step-works wow fadeInLeft\" wow-data-delay=\"0.6s\">\r\n                        <div class=\"content-section book-sec\">\r\n                            <div class=\"works-img\">\r\n                                <img src=\"assets/img/book.svg\" alt=\"images\">\r\n                            </div>\r\n                            <h4>Book</h4>\r\n                            <p>One-stop online platform for both men and women to book all the appointments.</p>                     \r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-md-4 col-sm-4 col-xs-12\">\r\n                    <div class=\"step-works wow fadeInLeft\" wow-data-delay=\"0.8s\">\r\n                        <div class=\"content-section\">\r\n                            <div class=\"works-img enjoy\">\r\n                                <img src=\"assets/img/enjoy.svg\" alt=\"images\">\r\n                            </div>\r\n                            <h4>Enjoy a hassle free service</h4>\r\n                            <p>Relax and Enjoy our service provided by the fully-equipped professionals</p>          \r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"our-services\" *ngIf=\"serviceList\">\r\n            <div id=\"services\" class=\"services item\">\r\n                <div class=\"section-title text-center\">\r\n                    <h2>Our <span class=\"pink\">Services</span></h2>\r\n                </div>\r\n                <div class=\"container\">\r\n                    <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\" *ngFor=\"let service of serviceList;let i=index\">\r\n                                <div class=\"service\" >\r\n                                    <a (click)=\"services(service.services_eng)\">\r\n                                        <img alt=\"...\" src=\"http://18.221.208.210/public/beauty-service/{{service.image}}\" >\r\n                                        <div class=\"img-content\">\r\n                                            {{service.services_eng}} <i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                           <!--  <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/facials.jpg\">\r\n                                        <div class=\"img-content\">\r\n                                            Top Facial Treatments <i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/img-7.png\">\r\n                                        <div class=\"img-content\">\r\n                                            Elite Hair Wash <i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n                                </div>\r\n                            </div> -->\r\n                        </div>\r\n                        <!-- <div class=\"row\">\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/img-1.png\">\r\n                                        <div class=\"img-content\">\r\n                                            Nail Treatment <i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/color.png\">\r\n                                        <div class=\"img-content\">\r\n                                            Top Hair Color Salons<i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-xs-12 col-sm-4 col-md-4 padding-lr-0 item\">\r\n                                <div class=\"service\">\r\n                                    <a href=\"#\">\r\n                                        <img alt=\"...\" src=\"assets/img/img-4.png\">\r\n                                        <div class=\"img-content\">\r\n                                            Top Hair Cut Salons<i class=\"fa fa-angle-right\"></i>\r\n                                        </div>\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                        </div> -->\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"trading-style\" >\r\n            <div class=\"section-title text-center\">\r\n                <h2>TRENDING <span class=\"pink\">STYLES</span></h2>\r\n            </div>\r\n            <div class=\"container\">\r\n                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                    <div class=\"owl_otr_div wow fadeInLeft\" data-wow-delay=\"0.5s\">\r\n                        <div class=\"owl-demo1 owl-carousel\">\r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>0\">\r\n                                    <img [src]=\"getimage1()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                    \r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>1\">\r\n                                    <img [src]=\"getimage2()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>2\">\r\n                                    <img [src]=\"getimage3()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>3\">\r\n                                    <img [src]=\"getimage4()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>4\">\r\n                                    <img [src]=\"getimage5()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>5\">\r\n                                    <img [src]=\"getimage6()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div> \r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>6\">\r\n                                    <img [src]=\"getimage7()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>7\">\r\n                                    <img [src]=\"getimage8()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>\r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>8\">\r\n                                    <img [src]=\"getimage9()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div> \r\n                            <div class=\"item\" >\r\n                                <div class=\"news_blk\" *ngIf=\"trendingStyles.length>9\">\r\n                                    <img [src]=\"getimage10()\" alt=\"Owl Image\" class=\"img-responsive\">\r\n                                </div>  \r\n                            </div>                                                \r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"professional-section\" *ngIf=\"homePageContent\">\r\n            <div class=\"container\">\r\n                <div class=\"row\">\r\n                    <div class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                        <div class=\"stats-bottom text-center\">\r\n                            <div class=\"col-lg-3 col-md-3 col-sm-3 col-xs-6 p-0\">\r\n                                <div class=\"wrap-count\">\r\n                                    <h3>Appointments</h3>\r\n                                    <span class=\"count\" >{{appointments | async  }}</span>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-md-3 col-sm-3 col-xs-6 p-0\">\r\n                                <div class=\"wrap-count\">\r\n                                    <h3>Saloons</h3>\r\n                                    <span class=\"count\" >{{totalSalons | async }}</span>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-md-3 col-sm-3 col-xs-6 p-0\">\r\n                                <div class=\"wrap-count\">\r\n                                    <h3>Satisfied Customers</h3>\r\n                                    <span class=\"count\" >{{totalCustomers | async }}</span>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-md-3 col-sm-3 col-xs-6 p-0\">\r\n                                <div class=\"wrap-count\">\r\n                                    <h3>Average Rating</h3>\r\n                                    <span class=\"count\" data-counter=\"counterup\" data-value=\"4.5\">{{averageRating | async }}</span><span class=\"rate-star\">Star</span>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>\r\n        <section class=\"mobile-app-sec\">\r\n            <div class=\"container\">\r\n                <div class=\"section-title text-center\">\r\n                    <h2>Book on the <span class=\"pink\">Go</span></h2>\r\n                </div>\r\n                <div class=\"slider-outer\">\r\n                    <div id=\"demo\" class=\"app-custom-slider\">\r\n                        <div class=\"span12\">\r\n                            <div class=\"main-slider wow bounceInUp\">\r\n                                <div class=\"iphone-frame\">\r\n                                    <img src=\"assets/img/iphone.png\" alt=\"Iphone\">\r\n                                </div>\r\n                                <div id=\"sync1\" class=\"owl-carousel test main-img-outer\">\r\n                                    <div class=\"item\">\r\n                                        <div class=\"slider-main-img\" style=\"\">                                   \r\n                                            <img src=\"assets/img/search.jpg\">\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item\">\r\n                                        <div class=\"slider-main-img\" style=\"\">                                   \r\n                                            <img src=\"assets/img/call.jpg\">\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item\">\r\n                                        <div class=\"slider-main-img\" style=\"\">                                   \r\n                                            <img src=\"assets/img/near-map.jpg\">\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item\">\r\n                                        <div class=\"slider-main-img\" style=\"\">                                   \r\n                                            <img src=\"assets/img/plans.jpg\">\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"thumbnail-slider\">\r\n                                <div id=\"sync2\" class=\"owl-carousel thumbnail-outer\">\r\n                                    <div class=\"item wow bounceInLeft\" data-wow-duration=\"0.8s\" >\r\n                                        <div class=\"slider-thumbnail-img\">\r\n                                            <i class=\"icon icon-map\"></i>\r\n                                            <h4>Find Professionals</h4>                                \r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item wow bounceInUp\" data-wow-duration=\"1.4s\" >\r\n                                        <div class=\"slider-thumbnail-img\">\r\n                                            <i class=\"icon icon-call-out\"></i>\r\n                                            <h4>Book</h4>                                     \r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item wow bounceInRight\" data-wow-duration=\"2.6s\" >\r\n                                        <div class=\"slider-thumbnail-img\">\r\n                                            <i class=\"icon icon-people\"></i>\r\n                                            <h4>Nearest Saloons</h4>                                       \r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"item wow bounceInDown\" data-wow-duration=\"2.0s\" >\r\n                                        <div class=\"slider-thumbnail-img\">\r\n                                            <i class=\"icon icon-credit-card\"></i>\r\n                                            <h4>Pay Online</h4>                                       \r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class=\"content-slider wow fadeIn\" data-wow-delay=\"0.6s\" >\r\n                                    <div id=\"sync1_copy\" class=\"owl-carousel\">\r\n                                        <div class=\"item\">\r\n                                            <div class=\"slider-con\" style=\"\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                <p class=\"left-big\">Browse our selection of vetted-professional beauty therapists, hairdressers and makeup artists</p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"item\">\r\n                                            <div class=\"slider-con\" style=\"\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                <p class=\"left-big\">You're booked! Simply wait for your therapist, hair stylist or makeup artist to arrive at the scheduled time and enjoy your treatment</p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"item\">\r\n                                            <div class=\"slider-con\" style=\"\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                <p class=\"left-big\">Find the best and fully equipped saloons near you.</p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"item\">\r\n                                            <div class=\"slider-con\" style=\"\">\r\n                                                <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                                <p class=\"left-big\">We'll confirm your appointment and take care of payment electronically and securely.</p>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"download-link\">\r\n                                        <a href=\"#\" class=\"link-download\">\r\n                                            <img src=\"assets/img/app-store.png\" alt=\"app-store\" class=\"img-responsive\">\r\n                                        </a>\r\n                                        <a href=\"#\" class=\"link-download\">\r\n                                            <img src=\"assets/img/google-play.png\" alt=\"play-store\" class=\"img-responsive\">\r\n                                        </a>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-one-layout/home-page/home-page.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-one-layout/home-page/home-page.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HomePageComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_rxjs_Observable__ = __webpack_require__("../../../../rxjs/_esm5/Observable.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs_add_observable_timer__ = __webpack_require__("../../../../rxjs/_esm5/add/observable/timer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_rxjs_add_operator_map__ = __webpack_require__("../../../../rxjs/_esm5/add/operator/map.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_rxjs_add_operator_take__ = __webpack_require__("../../../../rxjs/_esm5/add/operator/take.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_rxjs_add_observable_forkJoin__ = __webpack_require__("../../../../rxjs/_esm5/add/observable/forkJoin.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_rxjs_operators_startWith__ = __webpack_require__("../../../../rxjs/_esm5/operators/startWith.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_rxjs_operators_map__ = __webpack_require__("../../../../rxjs/_esm5/operators/map.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__providers_app_provider__ = __webpack_require__("../../../../../src/app/providers/app.provider.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__agm_core__ = __webpack_require__("../../../../@agm/core/index.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};













var HomePageComponent = (function () {
    function HomePageComponent(router, appProvider, commonServices, mapsAPILoader, ngZone) {
        this.router = router;
        this.appProvider = appProvider;
        this.commonServices = commonServices;
        this.mapsAPILoader = mapsAPILoader;
        this.ngZone = ngZone;
        this.tick = .5;
        //trendingStyles=[{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'},{image:'assets/img/color.png'}];
        this.trendingStyles = [];
        this.myControl = new __WEBPACK_IMPORTED_MODULE_11__angular_forms__["c" /* FormControl */]();
        this.myControlCities = new __WEBPACK_IMPORTED_MODULE_11__angular_forms__["c" /* FormControl */]();
    }
    HomePageComponent.prototype.ngOnInit = function () {
        var _this = this;
        var sync1 = $("#sync1");
        var sync2 = $("#sync2");
        var sync1_copy = $("#sync1_copy");
        sync1.owlCarousel({
            singleItem: true,
            slideSpeed: 1000,
            navigation: false,
            pagination: false,
            afterAction: syncPosition,
            responsiveRefreshRate: 200,
            autoPlay: true,
        });
        sync1_copy.owlCarousel({
            singleItem: true,
            slideSpeed: 1000,
            navigation: false,
            pagination: false,
            afterAction: syncPosition,
            responsiveRefreshRate: 200,
            autoPlay: true,
        });
        sync2.owlCarousel({
            items: 4,
            itemsDesktop: [1199, 4],
            itemsDesktopSmall: [979, 4],
            itemsTablet: [768, 4],
            itemsMobile: [479, 4],
            pagination: false,
            responsiveRefreshRate: 100,
            afterInit: function (el) {
                el.find(".owl-item").eq(0).addClass("synced");
            }
        });
        function syncPosition(el) {
            var current = this.currentItem;
            $("#sync2")
                .find(".owl-item")
                .removeClass("synced")
                .eq(current)
                .addClass("synced");
            if ($("#sync2").data("owlCarousel") !== undefined) {
                center(current);
            }
        }
        $("#sync2").on("click", ".owl-item", function (e) {
            e.preventDefault();
            var number = $(this).data("owlItem");
            sync1.trigger("owl.goTo", number);
        });
        $("#sync2").on("click", ".owl-item", function (e) {
            e.preventDefault();
            var number = $(this).data("owlItem");
            sync1_copy.trigger("owl.goTo", number);
        });
        function center(number) {
            var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
            var num = number;
            var found = false;
            for (var i in sync2visible) {
                if (num === sync2visible[i]) {
                    var found = true;
                }
            }
            if (found === false) {
                if (num > sync2visible[sync2visible.length - 1]) {
                    sync2.trigger("owl.goTo", num - sync2visible.length + 2);
                }
                else {
                    if (num - 1 === -1) {
                        num = 0;
                    }
                    sync2.trigger("owl.goTo", num);
                }
            }
            else if (num === sync2visible[sync2visible.length - 1]) {
                sync2.trigger("owl.goTo", sync2visible[1]);
            }
            else if (num === sync2visible[0]) {
                sync2.trigger("owl.goTo", num - 1);
            }
        }
        var owl = $(".owl-demo1");
        owl.owlCarousel({
            items: 4,
            itemsDesktop: [1000, 3],
            itemsDesktopSmall: [900, 3],
            itemsTablet: [600, 2],
            itemsMobile: [480, 1] // itemsMobile disabled - inherit from itemsTablet option
        });
        var wow = new WOW({
            animateClass: 'animated',
            offset: 100,
            callback: function (box) {
                console.log("WOW: animating <" + box.tagName.toLowerCase() + ">");
            }
        });
        wow.init();
        jQuery(document).ready(function ($) {
            $('.count').counterUp({
                delay: 10,
                time: 1000
            });
        });
        this.getserviceList();
        this.getHomePageContent();
        this.mapsAPILoader.load().then(function () {
            var autocomplete = new google.maps.places.Autocomplete(_this.searchElementRef.nativeElement, {
                types: ['(cities)'],
            });
            autocomplete.addListener("place_changed", function () {
                _this.ngZone.run(function () {
                    //get the place result
                    var place = autocomplete.getPlace();
                    alert(JSON.stringify(place.address_components[0].long_name));
                    //verify result
                    if (place.geometry === undefined || place.geometry === null) {
                        return;
                    }
                    _this.appProvider.current.selectedCity = place.address_components[0].long_name;
                    //set latitude, longitude and zoom
                    // this.accountCreationModel.city=place.formatted_address
                    // this.accountCreationModel.latitude = place.geometry.location.lat();
                    // this.accountCreationModel.longitude = place.geometry.location.lng();
                    // this.zoom = 12;
                });
            });
        });
    };
    HomePageComponent.prototype.filter = function (val) {
        return this.allSalonData.filter(function (option) {
            return option.saloon_name.toLowerCase().indexOf(val.toLowerCase()) === 0;
        });
    };
    HomePageComponent.prototype.filtercities = function (val) {
        return this.allSalonData.filter(function (option) {
            return option.city.toLowerCase().indexOf(val.toLowerCase()) === 0;
        });
    };
    HomePageComponent.prototype.getserviceList = function () {
        var _this = this;
        this.waitLoader = true;
        this.commonServices.getCategoryWithServices()
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.categoryList = data.data;
                console.log(_this.serviceList + "mukul");
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    HomePageComponent.prototype.getHomePageContent = function () {
        var _this = this;
        __WEBPACK_IMPORTED_MODULE_2_rxjs_Observable__["a" /* Observable */].forkJoin([this.commonServices.homePageContent(), this.commonServices.getServices(), this.commonServices.getTrendingStyles(), this.commonServices.getAllSaloonList()]).subscribe(function (results) {
            if (results[0].response == true) {
                _this.homePageContent = results[0];
                _this.getAppointmentCount(results[0].totalAppointments);
                _this.getSalons(results[0].totalSalons);
                _this.getaverageRating(results[0].averageRating);
                _this.gettotalCustomers(results[0].totalCustomers);
            }
            if (results[1].response == true) {
                _this.serviceList = results[1].data.slice(0, 6);
            }
            if (results[2].success == true) {
                _this.trendingStyles = results[2].trendingStylesData;
                // alert(JSON.stringify(this.trendingStyles))
            }
            if (results[3].response == true) {
                _this.allSalonData = results[3].data;
                _this.filteredSalons = _this.myControl.valueChanges
                    .pipe(Object(__WEBPACK_IMPORTED_MODULE_7_rxjs_operators_startWith__["a" /* startWith */])(''), Object(__WEBPACK_IMPORTED_MODULE_8_rxjs_operators_map__["a" /* map */])(function (val) { return _this.filter(val); }));
                _this.filteredCity = _this.myControlCities.valueChanges
                    .pipe(Object(__WEBPACK_IMPORTED_MODULE_7_rxjs_operators_startWith__["a" /* startWith */])(''), Object(__WEBPACK_IMPORTED_MODULE_8_rxjs_operators_map__["a" /* map */])(function (val) { return _this.filtercities(val); }));
            }
        }, function (error) {
        });
    };
    // getHomePageContent(){
    //   this.commonServices.homePageContent().subscribe(data=>{
    //     if (data.response==true) {
    //       this.homePageContent=data;
    //       this.getAppointmentCount(data.totalAppointments);
    //       this.getSalons(data.totalSalons);
    //       this.getaverageRating(data.averageRating);
    //       this.gettotalCustomers(data.totalCustomers);
    //     }
    //   },err=>{
    //   })
    // }
    HomePageComponent.prototype.getAppointmentCount = function (data) {
        var totalSec = 0;
        this.appointments = __WEBPACK_IMPORTED_MODULE_2_rxjs_Observable__["a" /* Observable */].timer(0, this.tick)
            .take(data)
            .map(function () { return ++totalSec; });
        console.log(this.appointments);
    };
    HomePageComponent.prototype.getSalons = function (data) {
        var totalSec = 0;
        this.totalSalons = __WEBPACK_IMPORTED_MODULE_2_rxjs_Observable__["a" /* Observable */].timer(0, this.tick)
            .take(data)
            .map(function () { return ++totalSec; });
        console.log(this.totalSalons);
    };
    HomePageComponent.prototype.getaverageRating = function (data) {
        var totalSec = 0;
        this.averageRating = __WEBPACK_IMPORTED_MODULE_2_rxjs_Observable__["a" /* Observable */].timer(0, this.tick)
            .take(data)
            .map(function () { return ++totalSec; });
        console.log(this.totalSalons);
    };
    HomePageComponent.prototype.gettotalCustomers = function (data) {
        var totalSec = 0;
        this.totalCustomers = __WEBPACK_IMPORTED_MODULE_2_rxjs_Observable__["a" /* Observable */].timer(0, this.tick)
            .take(data)
            .map(function () { return ++totalSec; });
        console.log(this.totalSalons);
    };
    HomePageComponent.prototype.getimage1 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[0].image;
    };
    HomePageComponent.prototype.getimage2 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[1].image;
    };
    HomePageComponent.prototype.getimage3 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[2].image;
    };
    HomePageComponent.prototype.getimage4 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[3].image;
    };
    HomePageComponent.prototype.getimage5 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[4].image;
    };
    HomePageComponent.prototype.getimage6 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[5].image;
    };
    HomePageComponent.prototype.getimage7 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[6].image;
    };
    HomePageComponent.prototype.getimage8 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[7].image;
    };
    HomePageComponent.prototype.getimage9 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[8].image;
    };
    HomePageComponent.prototype.getimage10 = function () {
        return 'http://18.221.208.210/public/beauty-service/' + this.trendingStyles[9].image;
    };
    HomePageComponent.prototype.services = function (ser) {
        // alert(ser)
        this.appProvider.current.serviceSearched = ser;
        this.appProvider.current.selectedCity = null;
        // this.router.navigate(['/header-three-layout/saloon-dashboard']);
        this.router.navigate(["/header-two-layout/searched-saloon"]);
    };
    HomePageComponent.prototype.onSelectedSalon = function (option) {
        // alert(JSON.stringify(option))
        this.idForSearchSalon = option.id;
    };
    HomePageComponent.prototype.onCitySelection = function (selectedCity) {
        //alert(selectedCity);
        this.appProvider.current.selectedCity = selectedCity;
    };
    HomePageComponent.prototype.onSearch = function () {
        if (this.idForSearchSalon) {
            this.router.navigate(["/header-two-layout/saloon-details/" + this.idForSearchSalon]);
        }
        else if (this.appProvider.current.selectedCity) {
            // alert('hl;o')
            this.router.navigate(["/header-two-layout/searched-saloon"]);
        }
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])("search"),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], HomePageComponent.prototype, "searchElementRef", void 0);
    HomePageComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-home-page',
            template: __webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page.component.scss")],
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_10__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_9__providers_app_provider__["a" /* AppProvider */], __WEBPACK_IMPORTED_MODULE_1__providers_common_service__["a" /* CommonService */], __WEBPACK_IMPORTED_MODULE_12__agm_core__["b" /* MapsAPILoader */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["NgZone"]])
    ], HomePageComponent);
    return HomePageComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-one-layout/home-page/home-page.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__home_page_routing_module__ = __webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__home_page_component__ = __webpack_require__("../../../../../src/app/header-one-layout/home-page/home-page.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_material_autocomplete__ = __webpack_require__("../../../material/esm5/autocomplete.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_material_input__ = __webpack_require__("../../../material/esm5/input.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__angular_material_form_field__ = __webpack_require__("../../../material/esm5/form-field.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var HomePageModule = (function () {
    function HomePageModule() {
    }
    HomePageModule.prototype.ngOnInit = function () {
    };
    HomePageModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__home_page_routing_module__["a" /* HomePageRoutingModule */], __WEBPACK_IMPORTED_MODULE_5__angular_material_autocomplete__["a" /* MatAutocompleteModule */], __WEBPACK_IMPORTED_MODULE_6__angular_material_input__["b" /* MatInputModule */], __WEBPACK_IMPORTED_MODULE_7__angular_material_form_field__["c" /* MatFormFieldModule */], __WEBPACK_IMPORTED_MODULE_8__angular_forms__["e" /* FormsModule */], __WEBPACK_IMPORTED_MODULE_8__angular_forms__["j" /* ReactiveFormsModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__home_page_component__["a" /* HomePageComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_4__providers_common_service__["a" /* CommonService */]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ })

});
//# sourceMappingURL=home-page.module.chunk.js.map