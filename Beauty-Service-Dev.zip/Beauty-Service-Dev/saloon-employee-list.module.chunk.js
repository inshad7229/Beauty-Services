webpackJsonp(["saloon-employee-list.module"],{

/***/ "../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaloonEmployeeListRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__saloon_employee_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__saloon_employee_list_component__["a" /* SaloonEmployeeListComponent */]
    }
];
var SaloonEmployeeListRoutingModule = (function () {
    function SaloonEmployeeListRoutingModule() {
    }
    SaloonEmployeeListRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], SaloonEmployeeListRoutingModule);
    return SaloonEmployeeListRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list.component.html":
/***/ (function(module, exports) {

module.exports = "\t<!-- END SIDEBAR -->\r\n\t\t\t<!-- BEGIN CONTENT -->\r\n <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n         <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n </div>\r\n\t\t\t<div class=\"page-content-wrapper\">\r\n\t\t\t\t<div class=\"page-content\">\r\n\t\t\t\t\t<ul class=\"page-breadcrumb breadcrumb hide\">\r\n\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t<a href=\"#\">Home</a><i class=\"fa fa-circle\"></i>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<li class=\"active\">\r\n\t\t\t\t\t\t\t Dashboard\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t\t<!-- BEGIN PAGE CONTENT INNER -->\r\n\t\t\t\t\t<div class=\"emp-list-sec\">\r\n\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 p-0\">\r\n\t\t\t\t\t\t\t<!-- BEGIN PORTLET-->\r\n\t\t\t\t\t\t\t<div class=\"booking-section\">\r\n\t\t\t\t\t\t\t\t<div class=\"portlet light\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-title\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"caption caption-md\">\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"icon-bar-chart theme-font-color hide\"></i>\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"caption-subject theme-font-color bold uppercase\">Employee List</span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"portlet-body\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 p-0\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"emp-list-sec\">\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"add-employee\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<a routerLink=\"/header-three-layout/add-employee-list\" class=\"btn cus-btn\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-plus\"></i> Add Employee\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"table-responsive\">\r\n\t\t\t\t\t                                <table class=\"table table-bordered\">\r\n\t\t\t\t\t                                    <thead>\r\n\t\t\t\t\t                                        <tr class=\"emp-tr\">\r\n\t\t\t\t\t                                            <th>Sr No</th>\r\n\t\t\t\t\t                                            <th>Employee Name</th>\r\n\t\t\t\t\t                                            <th>Employee Description</th>\r\n\t\t\t\t\t                                            <th>Contact Number</th>\r\n\t\t\t\t\t                                            <th>Email</th>\r\n\t\t\t\t\t                                            <th>Services</th>\r\n\t\t\t\t\t                                            <th>Gender</th>\r\n\t\t\t\t\t                                            <th>Action</th>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                    </thead>\r\n\t\t\t\t\t                                    <tbody>\r\n\t\t\t\t\t                                       <tr *ngFor=\"let data of employeeList | paginate: { itemsPerPage: 3, currentPage: p }; let i=index  \">\r\n\t\t\t\t\t                                            <td>{{i+1}}</td> \r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t <img *ngIf=\"!data.employee_image || data.employee_image==null\" src=\"assets/img/user-pro-1.jpg\" class=\"user-view\" alt=\"NO-IMAGES\">\r\n\t\t\t\t\t\t\t\t                            \t\t\t<img class=\"user-view\" *ngIf=\"data.employee_image\" [src]=\"imagePath(data.employee_image)\" >\r\n\t\t\t\t\t                                            \t{{data.first_name}} {{data.last_name}}\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t                                            <td>{{data.details}}</td>\r\n\t\t\t\t\t                                            <td>{{data.contact_number}}</td>\r\n\t\t\t\t\t                                            <td>{{data.email}}</td>\r\n\t\t\t\t\t                                            <td *ngIf=\"data.services && serviceList\">\r\n\t\t\t\t\t                                            \t<span *ngFor=\"let a of data.services.split(',')\">{{getServiceName(a)}}, </span>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                            <td>{{data.gender}}</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-employee\" (click)=\"onEdit(data)\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#view-employee\" (click)=\"onview(data)\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"#conformation-modal\" data-toggle=\"modal\" (click)=\"ondelete(data)\" >\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                       <!--  <tr>\r\n\t\t\t\t\t                                            <td>2</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<img class=\"user-view\" src=\"img/user-pro-3.jpg\">\r\n\t\t\t\t\t                                            \tAndrea Smith\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t                                            <td>Lorem Ipsum is dummy text</td>\r\n\t\t\t\t\t                                            <td>+918009890712</td>\r\n\t\t\t\t\t                                            <td>andrea@gmail.com</td>\r\n\t\t\t\t\t                                            <td>Hair Cutting</td>\r\n\t\t\t\t\t                                            <td>Male</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-employee\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#view-employee\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                            <td>3</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<img class=\"user-view\" src=\"img/user-pro-2.jpg\">\r\n\t\t\t\t\t                                            \tAlexa Andrzejewski\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t                                            <td>Lorem Ipsum is dummy text</td>\r\n\t\t\t\t\t                                            <td>+918009890712</td>\r\n\t\t\t\t\t                                            <td>andrea@gmail.com</td>\r\n\t\t\t\t\t                                            <td>Hair Cutting</td>\r\n\t\t\t\t\t                                            <td>Female</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-employee\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#view-employee\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr>\r\n\t\t\t\t\t                                        <tr>\r\n\t\t\t\t\t                                            <td>4</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<img class=\"user-view\" src=\"img/user-pro-1.jpg\">\r\n\t\t\t\t\t                                            \tAndrea Smith\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t                                            <td>Lorem Ipsum is dummy text</td>\r\n\t\t\t\t\t                                            <td>+918009890712</td>\r\n\t\t\t\t\t                                            <td>andrea@gmail.com</td>\r\n\t\t\t\t\t                                            <td>Hair Cutting</td>\r\n\t\t\t\t\t                                            <td>Male</td>\r\n\t\t\t\t\t                                            <td>\r\n\t\t\t\t\t                                            \t<ul class=\"action-icon\">\r\n\t\t\t\t\t                                                    <li class=\"edit-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#edit-employee\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-pencil\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"view-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"modal\" data-target=\"#view-employee\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-eye\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                    <li class=\"close-ic\">\r\n\t\t\t\t\t                                                        <a href=\"javascript:void(0);\" data-toggle=\"tooltip\"  title=\"Close\">\r\n\t\t\t\t\t                                                            <i class=\"fa fa-times\"></i>\r\n\t\t\t\t\t                                                        </a>\r\n\t\t\t\t\t                                                    </li>\r\n\t\t\t\t\t                                                </ul>\r\n\t\t\t\t\t                                            </td>\r\n\t\t\t\t\t                                        </tr> -->\r\n\t\t\t\t\t                                    </tbody>\r\n\t\t\t\t\t                                </table>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"table-pagination\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"pagination\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <!-- <a href=\"javascript:void(0)\"\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t   (click)=\"onPrevious()\" ><i class=\"fa fa-angle-left\"></i></a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"javascript:void(0)\" \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t   (click)=\"onLeft()\" class=\"{{activeLeft}}\">{{left}}</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <a (click)=\"onMiddle()\" href=\"javascript:void(0)\" class=\"{{activeMiddle}}\">{{middle}}</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <a (click)=\"onRigth()\" href=\"javascript:void(0)\" class=\"{{activeRigth}}\">{{right}}</a>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t  <a href=\"javascript:void(0)\" \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t   (click)=\"onNext()\"><i class=\"fa fa-angle-right\"></i></a> -->\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t   <pagination-controls (pageChange)=\"p = $event\"  previousLabel=\"\"  nextLabel=\"\" ></pagination-controls>\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<!-- <pagination-controls (pageChange)=\"p = $event\"></pagination-controls> -->\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<!-- END PORTLET-->\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<!-- END PAGE CONTENT INNER -->\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<!-- END CONTENT -->\r\n\t\t\r\n\t\t<!-- add-employe modal -->\r\n\t\t<div class=\"modal fade custom-modal\" id=\"edit-employee\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n\t\t\t<div class=\"modal-dialog modal-lg\" role=\"document\">\r\n\t\t\t    <div class=\"modal-content\">\r\n\t\t\t        <div class=\"modal-header\">\r\n\t\t\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t            \t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t            </button>\r\n\t\t\t            <h4 class=\"modal-title\" id=\"myModalLabel\">Edit Employee Details</h4>\r\n\t\t\t        </div>\r\n\t\t\t        <div class=\"modal-body\">\r\n\t\t\t            <div class=\"add-emp-form\">\r\n\t\t\t            \t<form class=\"img-responsive\" [formGroup]=\"updateEmployeeForm\">\r\n\t\t            \t\t\t<div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t\t            \t\t\t\t<div class=\"row add-emppic\">\r\n                                        <div class=\"col-md-offset-3 col-md-6 col-sm-6 col-xs-12 text-center\">\r\n                                            <div class=\"form-group custom-upload\">\r\n                                                <div class=\"file-previewimg\">\r\n                                                    <!-- <img src=\"img/user-pro-1.jpg\" class=\"img-responsive\" alt=\"NO-IMAGES\"> -->\r\n                                                    <img *ngIf=\"!addEmployee.employee_image || addEmployee.employee_image==null\" src=\"assets/img/user-pro-1.jpg\" class=\"img-responsive\" alt=\"NO-IMAGES\">\r\n\t\t\t\t\t\t\t\t                    <img class=\"img-responsive\" *ngIf=\"addEmployee.employee_image\" [src]=\"imagePath(addEmployee.employee_image)\" >\r\n                                                </div>\r\n                                                <div class=\"profile-upload\">\r\n                                                    <div class=\"input-btn\">\r\n                                                        <input type=\"file\" (change)=\"imageUploadEvent($event)\" accept=\"image/gif, image/jpeg, image/png\" />\r\n                                                        <button class=\"btn cus-btn\"> \r\n                                                        <i class=\"fa fa-file-image-o\"></i> Employee Image</button>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n\t\t            \t\t\t\t<div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Employee First Name In English<small class=\"manidatory\">*</small></label>\r\n\t                                        <input type=\"text\" placeholder=\"Employee First Name In English\" class=\"form-control\" [formControl]=\"updateEmployeeForm.controls['firstNameEng']\" [(ngModel)]=\"addEmployee.first_name\">\r\n\t\t                                        <p  *ngIf=\"updateEmployeeForm.controls['firstNameEng'].hasError('required') && updateEmployeeForm.controls['firstNameEng'].touched\">\r\n                                                      Employee First Name In English is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['firstNameEng'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['firstNameEng'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p> \r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Employee First Name In Arabic<small class=\"manidatory\">*</small></label>\r\n\t                                        <input type=\"text\" placeholder=\"Employee First Name In Arabic\" class=\"form-control\" [formControl]=\"updateEmployeeForm.controls['firstNameArb']\" [(ngModel)]=\"addEmployee.first_name_arb\">\r\n\t                                         <p  *ngIf=\"updateEmployeeForm.controls['firstNameArb'].hasError('required') && updateEmployeeForm.controls['firstNameArb'].touched\">\r\n                                                     Employee First Name In Arabic is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['firstNameArb'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['firstNameArb'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Employee Last Name In English<small class=\"manidatory\">*</small></label>\r\n\t                                        <input type=\"text\" placeholder=\"Employee Last Name In English\" class=\"form-control\" [formControl]=\"updateEmployeeForm.controls['lastNameEng']\" [(ngModel)]=\"addEmployee.last_name\">\r\n\t                                        <p  *ngIf=\"updateEmployeeForm.controls['lastNameEng'].hasError('required') && updateEmployeeForm.controls['lastNameEng'].touched\">\r\n                                                     Employee Last Name In English is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['lastNameEng'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['lastNameEng'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Employee Last Name In Arabic<small class=\"manidatory\">*</small></label>\r\n\t                                        <input type=\"text\" placeholder=\"Employee First Name In Arabic\" class=\"form-control\" [formControl]=\"updateEmployeeForm.controls['lastNameArb']\" [(ngModel)]=\"addEmployee.last_name_arb\">\r\n\t                                         <p  *ngIf=\"updateEmployeeForm.controls['lastNameArb'].hasError('required') && updateEmployeeForm.controls['lastNameArb'].touched\">\r\n                                                     Employee Last Name In Arabic is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['lastNameArb'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['lastNameArb'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                \t<div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Contact Number<small class=\"manidatory\">*</small></label>\r\n\t                                        <input type=\"text\" placeholder=\"Enter Number\" class=\"form-control\" [formControl]=\"updateEmployeeForm.controls['contactNumber']\" [(ngModel)]=\"addEmployee.contact_number\">\r\n\t                                        <p  *ngIf=\"updateEmployeeForm.controls['contactNumber'].hasError('required') && updateEmployeeForm.controls['contactNumber'].touched\">\r\n                                                     Contact Number is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['contactNumber'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['contactNumber'].hasError('maxlength')\">\r\n                                                           max length is 12\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Email <small class=\"manidatory\">*</small></label>\r\n\t                                        <input type=\"email\" placeholder=\"Enter Employee Email\" class=\"form-control\" [formControl]=\"updateEmployeeForm.controls['email']\" [(ngModel)]=\"addEmployee.email\">\r\n\t                                        <p  *ngIf=\"updateEmployeeForm.controls['email'].hasError('required') && updateEmployeeForm.controls['email'].touched\">\r\n                                                    Email is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['email'].hasError('pattern')\">\r\n                                                          Enter Valid email id\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['email'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                    <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Select Gender<small class=\"manidatory\">*</small></label>\r\n                                            <div class=\"custom-radio\">\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input type=\"radio\" value=\"male\" id=\"radio01\" name=\"radio\"  [formControl]=\"updateEmployeeForm.controls['gender']\" [(ngModel)]=\"addEmployee.gender\" >\r\n                                                    <label for=\"radio01\">\r\n                                                        <span><span></span></span>Male\r\n                                                    </label>\r\n                                                </div>\r\n                                                <div class=\"radio-inline\">\r\n                                                    <input type=\"radio\" value=\"female\" id=\"radio02\" name=\"radio\"  [formControl]=\"updateEmployeeForm.controls['gender']\" [(ngModel)]=\"addEmployee.gender\">\r\n                                                    <label for=\"radio02\">\r\n                                                        <span><span></span></span>Female\r\n                                                    </label>\r\n                                                </div>\r\n                                            </div>\r\n                                            <p  *ngIf=\"updateEmployeeForm.controls['gender'].hasError('required') && updateEmployeeForm.controls['gender'].touched\">\r\n                                                    Gender is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['gender'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['gender'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                     <div class=\"form-group col-md-6 col-sm-6 col-xs-12\">\r\n\t                                        <label>Select Employee Services<small class=\"manidatory\">*</small></label>\r\n\t                                         <div class=\"custom-select\">\r\n                                                 <ss-multiselect-dropdown [options]=\"myOptions2\" [(ngModel)]=\"optionsModel2\" (ngModelChange)=\"onChange2($event)\" [formControl]=\"updateEmployeeForm.controls['services']\" ></ss-multiselect-dropdown>\r\n                                            </div>\r\n                                            <p  *ngIf=\"updateEmployeeForm.controls['services'].hasError('required') && updateEmployeeForm.controls['services'].touched\">\r\n                                                    Employee Services is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['services'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['services'].hasError('maxlength')\">\r\n                                                           max length is 100\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <div class=\"row\">\r\n\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t                                        <label>\r\n\t                                        \tEnter Employee Details English <small class=\"manidatory\">*</small>\r\n\t                                        </label>\r\n\t                                        <textarea class=\"cus-textarea form-control\" col=\"8\" rows=\"10\" [formControl]=\"updateEmployeeForm.controls['detailsEng']\" [(ngModel)]=\"addEmployee.details\"></textarea>\r\n\t                                        <p  *ngIf=\"updateEmployeeForm.controls['detailsEng'].hasError('required') && updateEmployeeForm.controls['detailsEng'].touched\">\r\n                                                    Employee Details English is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['detailsEng'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['detailsEng'].hasError('maxlength')\">\r\n                                                           max length is 1000\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                 <div class=\"row\">\r\n\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t                                        <label>\r\n\t                                        \tEnter Employee Details Arabic <small class=\"manidatory\">*</small>\r\n\t                                        </label>\r\n\t                                        <textarea class=\"cus-textarea form-control\" col=\"8\" rows=\"10\" [formControl]=\"updateEmployeeForm.controls['detailsArb']\" [(ngModel)]=\"addEmployee.details_arb\"></textarea>\r\n\t                                        <p  *ngIf=\"updateEmployeeForm.controls['detailsArb'].hasError('required') && updateEmployeeForm.controls['detailsArb'].touched\">\r\n                                                    Employee Details Arabic is <strong>required</strong>\r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['detailsArb'].hasError('pattern')\">\r\n                                                           only alphabets are acceptable \r\n                                                </p>\r\n                                                <p  *ngIf=\"updateEmployeeForm.controls['detailsArb'].hasError('maxlength')\">\r\n                                                           max length is 1000\r\n                                                </p>\r\n\t                                    </div>\r\n\t                                </div>\r\n\t                                <!-- <div class=\"row\">\r\n\t                                \t<div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n\t                                \t\t<label>\r\n\t                                        \tUpload Employee Id <small class=\"manidatory\">*</small>\r\n\t                                        </label>\r\n\t                                \t\t<div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n\t                                \t\t\t<div class=\"row add-emppic\">\r\n\t\t                                            <div class=\"form-group custom-upload\">\r\n\t\t                                                <div class=\"file-previewimg\">\r\n\t\t                                                     <img *ngIf=\"!addEmployee.employee_Ids\" src=\"assets/img/no-img.png\" class=\"img-responsive\" alt=\"NO-IMAGES\">\r\n\t\t\t\t\t                            \t\t\t<img *ngIf=\"addEmployee.employee_Ids\" [src]=\"imagePath(addEmployee.employee_Ids)\" >\r\n\t\t                                                </div>\r\n\t\t                                                <div class=\"profile-upload\">\r\n\t\t                                                    <div class=\"input-btn\">\r\n\t\t                                                        <input type=\"file\"  [formControl]=\"updateEmployeeForm.controls['employeeId']\" (change)=\"idUploadEvent($event)\" />\r\n\t\t                                                        <button class=\"btn cus-btn\"> \r\n\t\t                                                        <i class=\"fa fa-address-card\"></i> Upload Id</button>\r\n\t\t                                                    </div>\r\n\t\t                                                    <p  *ngIf=\"updateEmployeeForm.controls['employeeId'].hasError('required') && updateEmployeeForm.controls['employeeId'].touched\">\r\n\t\t\t                                                    Employee Id is <strong>required</strong>\r\n\t\t\t                                                </p>\r\n\t\t\t                                                <p  *ngIf=\"updateEmployeeForm.controls['employeeId'].hasError('pattern')\">\r\n\t\t\t                                                           only alphabets are acceptable \r\n\t\t\t                                                </p>\r\n\t\t\t                                                <p  *ngIf=\"updateEmployeeForm.controls['employeeId'].hasError('maxlength')\">\r\n\t\t\t                                                           max length is 100\r\n\t\t\t                                                </p>\r\n\t\t                                                </div>\r\n\t\t                                            </div>\r\n\t\t\t                                    </div>\r\n\t                                \t\t</div>\r\n\t                                \t</div>\r\n\t                                </div> -->\r\n\t\t            \t\t\t</div>\r\n\t\t\t\t\t          \t<div class=\"modal-footerbtn\">\r\n\t\t\t\t\t          \t\t<span class=\"back-bt\">\r\n\t\t\t\t\t\t          \t\t<button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\">Close</button>\r\n\t\t\t\t\t\t          \t</span>\r\n\t\t\t\t\t\t          \t<span class=\"save-bt\">\r\n\t\t\t\t\t\t          \t\t<button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\" aria-label=\"Close\" [disabled]=\"!updateEmployeeForm.valid\" (click)=\"onUpdate()\">\r\n\t\t\t\t\t\t          \t\t <i class=\"fa fa-check\"></i> Save Change\r\n\t\t\t\t\t\t          \t\t</button>\r\n\t\t\t\t\t\t          \t</span>\r\n\t\t\t\t\t          \t</div>\r\n\t\t\t            \t</form>\r\n\t\t\t            </div>\r\n\t\t\t        </div>\r\n\t\t\t    </div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<!-- ========== view employe list details-->\r\n\t\t<div class=\"modal fade custom-modal\" id=\"view-employee\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n\t\t\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t\t\t    <div class=\"modal-content\">\r\n\t\t\t        <div class=\"modal-header\">\r\n\t\t\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t            \t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t            </button>\r\n\t\t\t            <h4 class=\"modal-title\" id=\"myModalLabel\">Employee Details</h4>\r\n\t\t\t        </div>\r\n\t\t\t        <div class=\"modal-body\">\r\n\t\t\t            <div class=\"view-emp-detail\">\r\n\t\t\t            \t<form class=\"img-responsive\">\r\n\t\t            \t\t\t<div class=\"col-lg-12 col-sm-12 col-md-12 col-xs-12\">\r\n\t\t            \t\t\t\t<div class=\"col-md-12 col-sm-12 col-xs-12 text-center\">\r\n\t\t            \t\t\t\t\t<div class=\"emp-viewimg\">\r\n\t\t            \t\t\t\t\t\t <img *ngIf=\"!addEmployee.employee_image || addEmployee.employee_image==null\" src=\"assets/img/user-pro-1.jpg\"  class=\"img-responsive\" alt=\"NO-IMAGES\">\r\n\t\t\t\t\t\t\t\t             <img  class=\"img-responsive\" *ngIf=\"addEmployee.employee_image\" [src]=\"imagePath(addEmployee.employee_image)\" >\r\n\t\t            \t\t\t\t\t</div>\r\n\t\t            \t\t\t\t</div>\r\n                                    <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                                    \t<div class=\"employe-details\">\r\n\t                                    \t<div class=\"info-list\">\r\n\r\n\r\n\r\n\r\n\r\n\r\n\t\t\t\t                          \t\t<dl class=\"dl-horizontal\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Employee Name</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addEmployee.first_name}} {{addEmployee.last_name}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Email</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addEmployee.email}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Contact Number</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addEmployee.contact_number}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Gender</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addEmployee.gender}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Saloon Service</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd *ngIf=\"addEmployee.services\"><!-- {{addEmployee.services}} -->\r\n\t\t\t\t\t\t\t\t\t\t\t\t  \t<span *ngFor=\"let a of addEmployee.services.split(',')\">{{getServiceName(a)}}, </span>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  </dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <!-- <dt>Employee Address</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>Headquarters 1120 N Street Sacramento 916-654-5266</dd> -->\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dt>Description</dt>\r\n\t\t\t\t\t\t\t\t\t\t\t\t  <dd>{{addEmployee.details}}</dd>\r\n\t\t\t\t\t\t\t\t\t\t\t\t</dl>\r\n\t\t\t\t                          \t</div>\r\n\t                                    </div>\r\n                                    </div>\r\n\t\t            \t\t\t</div>\r\n\t\t\t\t\t          \t<div class=\"modal-footerbtn\">\r\n\t\t\t\t\t\t          \t<div class=\"col-md-12 col-sm-12 col-xs-12 text-center\">\r\n\t\t\t\t\t\t\t          \t\t<button type=\"button\" class=\"btn cut-btn\" data-dismiss=\"modal\" aria-label=\"Close\"> OK\r\n\t\t\t\t\t\t\t          \t\t</button>\r\n\t\t\t\t\t\t          \t</div>\r\n\t\t\t\t\t          \t</div>\r\n\t\t\t            \t</form>\r\n\t\t\t            </div>\r\n\t\t\t        </div>\r\n\t\t\t    </div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"modal fade custom-modal\" id=\"conformation-modal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n\t\t\t<div class=\"modal-dialog modal-md\" role=\"document\">\r\n\t\t\t    <div class=\"modal-content\">\r\n\t\t\t        <!-- <div class=\"modal-header\">\r\n\t\t\t            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t            \t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t            </button>\r\n\t\t\t            <h4 class=\"modal-title\" id=\"myModalLabel\">Employee Details</h4>\r\n\t\t\t        </div> -->\r\n\t\t\t        <div class=\"modal-body\">\r\n\t\t\t            <div class=\"view-emp-detail\">\r\n\t\t\t            \t<div class=\"confirm-info\">\r\n\t\t\t            \t\t<h4>Are you sure you want to delete this user ?</h4>\r\n\t\t\t            \t\t<div class=\"btn-conformation\">\r\n\t\t\t            \t\t\t<span class=\"yes-confirm\">\r\n\t\t\t            \t\t\t\t<button type=\"button\" data-dismiss=\"modal\" class=\"cut-btn btn\" (click)=\"onYes()\">Yes</button>\r\n\t\t\t            \t\t\t</span>\r\n\t\t\t            \t\t\t<span class=\"confirm-no2\">\r\n\t\t\t            \t\t\t\t<button type=\"button\" data-dismiss=\"modal\" class=\"cut-btn btn\">No</button>\r\n\t\t\t            \t\t\t</span>\r\n\t\t\t            \t\t</div>\r\n\t\t\t            \t</div>\r\n\t\t\t            </div>\r\n\t\t\t        </div>\r\n\t\t\t    </div>\r\n\t\t\t</div>\r\n\t\t</div>"

/***/ }),

/***/ "../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".yes-confirm {\n  margin-right: 20px; }\n\n.btn-conformation {\n  margin-top: 50px; }\n\n.confirm-info h4 {\n  font-size: 18px;\n  margin: 10px 0; }\n\n.confirm-info {\n  float: left;\n  width: 100%;\n  padding: 50px 0 60px 0px;\n  text-align: center; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaloonEmployeeListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__models_employee__ = __webpack_require__("../../../../../src/app/models/employee.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__providers_app_provider__ = __webpack_require__("../../../../../src/app/providers/app.provider.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var SaloonEmployeeListComponent = (function () {
    function SaloonEmployeeListComponent(router, fb, vcr, toastr, translate, saloonServices, appProvider) {
        this.router = router;
        this.fb = fb;
        this.toastr = toastr;
        this.translate = translate;
        this.saloonServices = saloonServices;
        this.appProvider = appProvider;
        this.userDetail = JSON.parse(localStorage['userdetails']);
        this.optionsModel2 = [];
        this.addEmployee = new __WEBPACK_IMPORTED_MODULE_5__models_employee__["a" /* AddEmployee */]();
        this.left = 1;
        this.middle = 2;
        this.right = 3;
        this.activeLeft = 'active';
        this.activeMiddle = '';
        this.activeRigth = '';
        this.toastr.setRootViewContainerRef(vcr);
        this.updateEmployeeForm = fb.group({
            'firstNameEng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'firstNameArb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'lastNameEng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'lastNameArb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'contactNumber': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(12)])],
            'email': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100), __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].pattern(EMAIL_REGEX)])],
            'gender': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'services': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(100)])],
            'detailsEng': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(1000)])],
            'detailsArb': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(1000)])]
        });
        this.updateEmployeeForm.controls['email'].disable();
    }
    SaloonEmployeeListComponent.prototype.ngOnInit = function () {
        //this.appProvider.current.waitLoader=true
        this.getDetails();
        this.getserviceList();
        this.myOptions2 = [
            { id: 1, name: 'Option 1' },
            { id: 2, name: 'Option 2' },
            { id: 3, name: 'Option 3' },
            { id: 4, name: 'Option 4' },
            { id: 5, name: 'Option 5' },
            { id: 6, name: 'Option 6' },
        ];
    };
    SaloonEmployeeListComponent.prototype.getDetails = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonServices.getEmployeeById(this.userDetail.id)
            .subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response) {
                _this.toastr.success('All employee list fetched successfully', 'Success', { toastLife: 1000, showCloseButton: true });
                _this.employeeList = data.data;
                // this.router.navigate(['/header-three-layout/saloon-employee-list']);
            }
            else if (data.message == 'Employee not find') {
                _this.toastr.error('Employee not find', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Employee Registration Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    SaloonEmployeeListComponent.prototype.getserviceList = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonServices.getservicesById(this.userDetail.id)
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.serviceList = data.data;
                for (var i = 0; i < _this.serviceList.length; ++i) {
                    list.push({ id: _this.serviceList[i].servicesData.id, name: _this.serviceList[i].servicesData.services_eng });
                }
                _this.myOptions2 = list;
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    SaloonEmployeeListComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.216.88.154/public/beauti-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    SaloonEmployeeListComponent.prototype.onEdit = function (data) {
        this.optionsModel2 = [];
        var b = data.services.split(',');
        //console.log('services',data.services)
        for (var i = 0; i < b.length; ++i) {
            if (+b[i] != NaN) {
                if (this.serviceList.map(function (img) { return img.servicesData.id; }).indexOf(+b[i]) != -1) {
                    this.optionsModel2.push(+b[i]);
                    // code...
                }
                // code...
            }
            // code...
        }
        this.addEmployee = Object.assign({}, data);
        // let a=Object.create(data);
    };
    SaloonEmployeeListComponent.prototype.onview = function (data) {
        this.addEmployee = data;
    };
    SaloonEmployeeListComponent.prototype.ondelete = function (data) {
        this.addEmployee = data;
    };
    SaloonEmployeeListComponent.prototype.onChange2 = function () {
        // console.log(this.optionsModel2);
    };
    SaloonEmployeeListComponent.prototype.onUpdate = function () {
        var _this = this;
        // console.log(this.addEmployee)
        // this.addEmployee=Object.assign(this.addEmployee);
        this.waitLoader = true;
        delete (this.addEmployee.created_at);
        delete (this.addEmployee.updated_at);
        delete (this.addEmployee.status);
        var a = this.optionsModel2.slice(0);
        this.addEmployee.services = a.toString();
        this.saloonServices.updateEmployee(this.addEmployee)
            .subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response) {
                _this.getDetails();
                _this.waitLoader = false;
                _this.toastr.success('Employee details updated successfully', 'Success', { toastLife: 1000, showCloseButton: true });
                /// this.employeeList=data.data
                // this.router.navigate(['/header-three-layout/saloon-employee-list']);
            }
            else if (data.message == 'Employee not find') {
                _this.toastr.error('Employee not find', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Employee Registration Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    SaloonEmployeeListComponent.prototype.onYes = function () {
        var _this = this;
        this.waitLoader = true;
        this.saloonServices.deleteEmployeeById(this.addEmployee.id)
            .subscribe(function (data) {
            _this.waitLoader = false;
            if (data.response) {
                _this.getDetails();
                _this.toastr.success('Employee deleted successfully', 'Success', { toastLife: 1000, showCloseButton: true });
                //this.employeeList=data.data
                // this.router.navigate(['/header-three-layout/saloon-employee-list']);
            }
            else if (data.message == 'Employee not find') {
                _this.toastr.error('Employee not find', 'Updation Failed', { toastLife: 1000, showCloseButton: true });
                // code...
            }
            else {
                _this.toastr.error('Something Went Wrong Please Try Again', 'Employee Registration Failed', { toastLife: 1000, showCloseButton: true });
            }
        });
    };
    SaloonEmployeeListComponent.prototype.getServiceName = function (a) {
        var data = this.serviceList.filter(function (arg) { return arg.servicesData.id == a; });
        if (data.length > 0) {
            return data[0].servicesData.services_eng;
        }
    };
    SaloonEmployeeListComponent.prototype.imageUploadEvent = function (evt) {
        var _this = this;
        if (!evt.target) {
            return;
        }
        if (!evt.target.files) {
            return;
        }
        if (evt.target.files.length !== 1) {
            return;
        }
        var file = evt.target.files[0];
        if (file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif' && file.type !== 'image/jpg') {
            return;
        }
        var fr = new FileReader();
        fr.onloadend = function (loadEvent) {
            _this.addEmployee.employee_image = fr.result;
            console.log(_this.addEmployee.employee_image);
        };
        fr.readAsDataURL(file);
    };
    SaloonEmployeeListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-saloon-employee-list',
            template: __webpack_require__("../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["a" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_4__ngx_translate_core__["c" /* TranslateService */],
            __WEBPACK_IMPORTED_MODULE_6__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_7__providers_app_provider__["a" /* AppProvider */]])
    ], SaloonEmployeeListComponent);
    return SaloonEmployeeListComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaloonEmployeeListModule", function() { return SaloonEmployeeListModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_angular_2_dropdown_multiselect__ = __webpack_require__("../../../../angular-2-dropdown-multiselect/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__saloon_employee_list_routing_module__ = __webpack_require__("../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__saloon_employee_list_component__ = __webpack_require__("../../../../../src/app/header-three-layout/saloon-employee-list/saloon-employee-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var SaloonEmployeeListModule = (function () {
    function SaloonEmployeeListModule() {
    }
    SaloonEmployeeListModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_8__saloon_employee_list_routing_module__["a" /* SaloonEmployeeListRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["c" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["h" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_5_angular_2_dropdown_multiselect__["a" /* MultiselectDropdownModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_common_http__["b" /* HttpClientModule */],
                __WEBPACK_IMPORTED_MODULE_4_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
                __WEBPACK_IMPORTED_MODULE_6__ngx_translate_core__["b" /* TranslateModule */],
                __WEBPACK_IMPORTED_MODULE_7_ngx_pagination__["a" /* NgxPaginationModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_9__saloon_employee_list_component__["a" /* SaloonEmployeeListComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_10__providers_saloon_service__["a" /* SaloonService */]]
        })
    ], SaloonEmployeeListModule);
    return SaloonEmployeeListModule;
}());



/***/ })

});
//# sourceMappingURL=saloon-employee-list.module.chunk.js.map