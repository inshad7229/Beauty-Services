webpackJsonp(["customer-login.module"],{

/***/ "../../../../../src/app/header-two-layout/customer-login/customer-login-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerLoginRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__customer_login_component__ = __webpack_require__("../../../../../src/app/header-two-layout/customer-login/customer-login.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__customer_login_component__["a" /* CustomerLoginComponent */]
    }
];
var CustomerLoginRoutingModule = (function () {
    function CustomerLoginRoutingModule() {
    }
    CustomerLoginRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], CustomerLoginRoutingModule);
    return CustomerLoginRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/customer-login/customer-login.component.html":
/***/ (function(module, exports) {

module.exports = "             <div class=\"loader-box\" *ngIf=\"waitLoader==true\">\r\n                 <img src=\"./assets/img/Loading_icon.gif\" class=\"img-responsive\" />\r\n            </div>\r\n             <section class=\"login-section\">\r\n            <div class=\"container\">\r\n                <div class=\"login-inner\">\r\n                    <form class=\"login-form common-form\">\r\n                        <h3 class=\"form-h\">Customer Login</h3>\r\n                        <div class=\"form-wrap\">\r\n                            <div class=\"row\">\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <input type=\"text\" placeholder=\"Enter Email\" class=\"form-control\">\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"row\">\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <input type=\"pass\" placeholder=\"Password\" class=\"form-control\">\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"row\">\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                    <div class=\"col-md-6 col-sm-6 col-xs-12\">\r\n                                        <label class=\"remember-me\">\r\n                                             <input type=\"checkbox\" checked=\"checked\"> Remember me\r\n                                             <span></span>\r\n                                        </label>\r\n                                    </div>\r\n                                    <div class=\"col-md-6 col-sm-6 col-xs-12 text-right\">\r\n                                        <a href=\"forgot-password.php\" class=\"link-forgot-password\">Forgot Password?</a>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                <div class=\"sign-inntn\">\r\n                                    <a href=\"#\" class=\"btn cut-btn\" >Login</a>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"line-div\"></div>\r\n                            <div class=\"social-mediad\">\r\n                                <ul class=\"social-ul\">\r\n                                    <li class=\"fb\">\r\n                                        <a href=\"javascript:void(0);\">\r\n                                            <i class=\"fa fa-facebook\" aria-hidden=\"true\"></i>\r\n                                            sign in with facebook\r\n                                        </a>\r\n                                    </li>\r\n                                    <li class=\"tw\">\r\n                                        <a href=\"javascript:void(0);\">\r\n                                            <i class=\"fa fa-twitter\" aria-hidden=\"true\"></i>\r\n                                            sign in with twitter\r\n                                        </a>\r\n                                    </li>\r\n                                    <li class=\"google\">\r\n                                        <a href=\"javascript:void(0);\">\r\n                                            <i class=\"fa fa-google-plus\" aria-hidden=\"true\"></i>\r\n                                            sign in with google \r\n                                        </a>\r\n                                    </li>\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"sign-up\">\r\n                                Don't have an account?\r\n                                <span>\r\n                                    <a href=\"#\">Sign Up</a>\r\n                                </span>\r\n                            </div>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/customer-login/customer-login.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/customer-login/customer-login.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerLoginComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CustomerLoginComponent = (function () {
    function CustomerLoginComponent(router) {
        this.router = router;
    }
    CustomerLoginComponent.prototype.ngOnInit = function () { };
    CustomerLoginComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-customer-login',
            template: __webpack_require__("../../../../../src/app/header-two-layout/customer-login/customer-login.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/customer-login/customer-login.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */]])
    ], CustomerLoginComponent);
    return CustomerLoginComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/customer-login/customer-login.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerLoginModule", function() { return CustomerLoginModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__customer_login_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/customer-login/customer-login-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__customer_login_component__ = __webpack_require__("../../../../../src/app/header-two-layout/customer-login/customer-login.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var CustomerLoginModule = (function () {
    function CustomerLoginModule() {
    }
    CustomerLoginModule.prototype.ngOnInit = function () {
    };
    CustomerLoginModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__customer_login_routing_module__["a" /* CustomerLoginRoutingModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__customer_login_component__["a" /* CustomerLoginComponent */]]
        })
    ], CustomerLoginModule);
    return CustomerLoginModule;
}());



/***/ })

});
//# sourceMappingURL=customer-login.module.chunk.js.map