webpackJsonp(["header-two-layout.module"],{

/***/ "../../../../../src/app/header-two-layout/header-two-layout-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HeaderTwoLayoutRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__header_two_layout_component__ = __webpack_require__("../../../../../src/app/header-two-layout/header-two-layout.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__header_two_layout_component__["a" /* HeaderTwoLayoutComponent */],
        children: [
            { path: '', redirectTo: 'saloon-signup' },
            { path: 'saloon-signup', loadChildren: './saloon-signup/saloon-signup.module#SaloonSignupModule' },
            { path: 'customer-signup', loadChildren: './customer-signup/customer-signup.module#CustomerSignupModule' },
            { path: 'create-new-password', loadChildren: './create-new-password/create-new-password.module#CreateNewPasswordModule' },
            { path: 'customer-login', loadChildren: './customer-login/customer-login.module#CustomerLoginModule' },
            { path: 'forgot-password', loadChildren: './forgot-password/forgot-password.module#ForgotPasswordModule' },
            { path: 'login', loadChildren: './login/login.module#LoginModule' },
            { path: 'searched-saloon', loadChildren: './searched-saloon/searched-saloon.module#SearchedSaloonModule' },
            { path: 'searched-services', loadChildren: './searched-services/searched-services.module#SearchedServicesModule' },
            { path: 'saloon-details', loadChildren: './saloon-details/saloon-details.module#SaloonDetailsModule' },
            { path: 'saloon-details/:id', loadChildren: './saloon-details/saloon-details.module#SaloonDetailsModule' },
            { path: 'about-us', loadChildren: './about-us/about-us.module#AboutUsModule' },
            { path: 'faq', loadChildren: './faq/faq.module#FaqModule' },
            { path: 'terms-and-condition', loadChildren: './terms-and-condition/terms-and-condition.module#TermsAndConditionModule' },
            { path: 'team', loadChildren: './team/team.module#TeamModule' },
            { path: 'contact-us', loadChildren: './contact-us/contact-us.module#ContactUsModule' }
        ]
    }
];
var HeaderTwoLayoutRoutingModule = (function () {
    function HeaderTwoLayoutRoutingModule() {
    }
    HeaderTwoLayoutRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], HeaderTwoLayoutRoutingModule);
    return HeaderTwoLayoutRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/header-two-layout.component.html":
/***/ (function(module, exports) {

module.exports = "<!-- <app-header></app-header>-->\r\n <app-header-two></app-header-two>\r\n<section >\r\n    <router-outlet></router-outlet>\r\n</section>\r\n"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/header-two-layout.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".main-container {\n  margin-top: 56px;\n  margin-left: 235px;\n  padding: 15px;\n  -ms-overflow-x: hidden;\n  overflow-x: hidden;\n  overflow-y: scroll;\n  position: relative;\n  overflow: hidden; }\n\n@media screen and (max-width: 992px) {\n  .main-container {\n    margin-left: 0px !important; } }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/header-two-layout.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HeaderTwoLayoutComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HeaderTwoLayoutComponent = (function () {
    function HeaderTwoLayoutComponent() {
    }
    HeaderTwoLayoutComponent.prototype.ngOnInit = function () { };
    HeaderTwoLayoutComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-header-two-layout',
            template: __webpack_require__("../../../../../src/app/header-two-layout/header-two-layout.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/header-two-layout.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], HeaderTwoLayoutComponent);
    return HeaderTwoLayoutComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/header-two-layout.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderTwoLayoutModule", function() { return HeaderTwoLayoutModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__header_two_layout_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/header-two-layout-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__header_two_layout_component__ = __webpack_require__("../../../../../src/app/header-two-layout/header-two-layout.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_layout_header_two_header_two_component__ = __webpack_require__("../../../../../src/app/shared-layout/header-two/header-two.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var HeaderTwoLayoutModule = (function () {
    function HeaderTwoLayoutModule() {
    }
    HeaderTwoLayoutModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3__header_two_layout_routing_module__["a" /* HeaderTwoLayoutRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_2__ngx_translate_core__["b" /* TranslateModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_4__header_two_layout_component__["a" /* HeaderTwoLayoutComponent */], __WEBPACK_IMPORTED_MODULE_5__shared_layout_header_two_header_two_component__["a" /* HeaderTwoComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_6__providers_common_service__["a" /* CommonService */]]
        })
    ], HeaderTwoLayoutModule);
    return HeaderTwoLayoutModule;
}());



/***/ }),

/***/ "../../../../../src/app/shared-layout/header-two/header-two.component.html":
/***/ (function(module, exports) {

module.exports = "<header class=\"header-sec page-header\">\r\n    <div class=\"top-header\">\r\n        <div class=\"wrap-pageh\">\r\n           <div class=\"col-md-3 col-sm-3 col-xs-4\">\r\n                <div class=\"logo-top\">\r\n                    <a class=\"navbar-brand\" routerLink=\"/header-one-layout/home-page\"><img src=\"assets/img/logo.png\" class=\"img-responsive\"></a>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-md-6 col-sm-6 col-xs-9\">\r\n                <div class=\"header-search-bar\">\r\n                    <form class=\"horizontal-form customize\">\r\n                        <div class=\"col-md-12 col-sm-12 p-0\">\r\n                            <div class=\"col-md-5 col-sm-5 col-xs-9 no-padding\">\r\n                                <input  type=\"text\" class=\"form-control input1\" name=\"password\" placeholder=\"{{ 'headerTwo.find_service_saloon' | translate }}\">\r\n                            </div>\r\n                            <div class=\"col-md-5 col-sm-5 col-xs-12 no-padding responsive-time\">\r\n                                <input type=\"text\" class=\"form-control input2\"  placeholder=\"{{ 'headerTwo.enter_your_area' | translate }}\">\r\n                            </div>\r\n                            <div class=\"col-md-2 col-sm-2 col-xs-3 no-padding\">\r\n                                <a class=\"btn custom-btn\" href=\"javascript:void(0);\">{{ 'headerTwo.search' | translate }}</a>\r\n                            </div>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n            <div class=\"col-md-3 col-sm-3 col-xs-3 order-2\">\r\n                <div class=\"pull-right left-navbar\">\r\n                   <ul class=\"right-login\" *ngIf=\"customer==null\">\r\n                        <li><a href=\"#\" data-toggle=\"modal\" data-target=\"#signupAs\">{{ 'headerTwo.SignUp' | translate }}</a></li>\r\n                        <li><a routerLink=\"/header-two-layout/login\">{{ 'headerTwo.logIn' | translate }}</a></li>\r\n                   </ul>\r\n                   <ul class=\"home-pro\" *ngIf=\"customer!=null\">\r\n                               <li class=\"dropdown dropdown-user dropdown-dark\">\r\n                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" data-hover=\"dropdown\" data-close-others=\"true\">\r\n                                        <div class=\"header-user\">\r\n                                            <img *ngIf=\"!customer.image || customer.image==null\" src=\"assets/img/user-pro-1.jpg\" class=\"img-circle\" alt=\"NO-IMAGES\">\r\n                                            <img class=\"img-circle\" *ngIf=\"customer.image\" [src]=\"imagePath(customer.image)\" >\r\n                                            <span class=\"username username-hide-on-mobile\">\r\n                                                {{customer.first_name}}  {{customer.last_name}}<i class=\"fa fa-angle-down\"></i></span>\r\n                                        </div>\r\n                                    </a>\r\n                                    <ul class=\"dropdown-menu dropdown-menu-default\">\r\n                                        <li (click)=\"oncustomerProfile()\">\r\n                                            <a href=\"javascript:void(0)\">\r\n                                            <i class=\"icon-user\"></i> My Profile </a>\r\n                                        </li>\r\n                                        <li (click)=\"onLogout()\">\r\n                                            <a href=\"javascript:void(0)\">\r\n                                            <i class=\"icon-key\"></i> Log Out </a>\r\n                                        </li>\r\n                                    </ul>\r\n                                </li>\r\n                           </ul>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <nav class=\"navbar\">\r\n        <!-- Brand and toggle get grouped for better mobile display -->\r\n        <div class=\"navbar-header\">\r\n            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">\r\n            <span class=\"sr-only\">Toggle navigation</span>\r\n            <span class=\"icon-bar\"></span>\r\n            <span class=\"icon-bar\"></span>\r\n            <span class=\"icon-bar\"></span>\r\n            </button>\r\n        </div>\r\n        <!-- Collect the nav links, forms, and other content for toggling -->  \r\n        <div class=\"bottom-header\">\r\n            <div class=\"col-md-12 col-sm-12 col-xs-12\">\r\n                <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">\r\n                    <ul class=\"nav navbar-nav cus-navbar custome-bar\">\r\n                        <li class=\"dropdown\" *ngFor=\"let cat of categoryList\">\r\n                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"><span>{{cat.category_eng}}</span></a>\r\n                            <ul class=\"sub-service dropdown-content dropdown-menu animated fadeInUp\">\r\n                               <li *ngFor=\"let ser of cat.servicesData\" (click)='services(ser.services_eng)'>\r\n                                    <a  href=\"javascript:void(0)\">{{ser.services_eng}}</a>\r\n                                </li>\r\n                                <li class=\"see-all\">\r\n                                        <a href=\"javascript:void(0);\">View {{cat.category_eng}} Treatment\r\n                                         <span class=\"icon-right-li\">\r\n                                            <i class=\"fa fa-angle-right\"></i>        \r\n                                        </span>\r\n                                    </a>\r\n                                </li>\r\n                            </ul>\r\n                        </li>\r\n<!--                         <li class=\"dropdown\">\r\n                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Nails</a>\r\n                            <ul class=\"sub-service dropdown-content dropdown-menu  animated fadeInUp\">\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Manicure</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Pedicure</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Gel Nails</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Acrylic Nails</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">French Manicure</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">French Pedicure</a>\r\n                                </li>\r\n                                <li class=\"see-all\">\r\n                                        <a href=\"javascript:void(0);\">View Nail Treatment\r\n                                         <span class=\"icon-right-li\">\r\n                                            <i class=\"fa fa-angle-right\"></i>        \r\n                                        </span>\r\n                                    </a>\r\n                                </li>\r\n                            </ul>\r\n                        </li>\r\n                       <li class=\"dropdown\">\r\n                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Massage</a>\r\n                            <ul class=\"sub-service dropdown-content dropdown-menu animated fadeInUp\">\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Bali Massage</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Relaxing Massage</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Full Body Massage</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Shoulder Massage</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Thai Massage</a>\r\n                                </li>\r\n                                <li class=\"see-all\">\r\n                                        <a href=\"javascript:void(0);\">View Massage Services\r\n                                         <span class=\"icon-right-li\">\r\n                                            <i class=\"fa fa-angle-right\"></i>        \r\n                                        </span>\r\n                                    </a>\r\n                                </li>\r\n                            </ul>\r\n                        </li>\r\n                       <li class=\"dropdown\">\r\n                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Spa</a>\r\n                            <ul class=\"sub-service dropdown-content dropdown-menu animated fadeInUp\">\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Hammam</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Body Scrub</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Cellulite Treatments</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Body Wrap</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Slimming Treatments</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Foot Scrub</a>\r\n                                </li>\r\n                                <li class=\"see-all\">\r\n                                        <a href=\"javascript:void(0);\">View spa Treatment\r\n                                         <span class=\"icon-right-li\">\r\n                                            <i class=\"fa fa-angle-right\"></i>        \r\n                                        </span>\r\n                                    </a>\r\n                                </li>\r\n                            </ul>\r\n                        </li>\r\n                       <li class=\"dropdown\">\r\n                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">barbers</a>\r\n                            <ul class=\"sub-service dropdown-content dropdown-menu animated fadeInUp\">\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Men Shave</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Beard trimming</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Clipper Cut</a>\r\n                                </li>\r\n                                <li>\r\n                                    <a href=\"javascript:void(0);\">Hot Towel Shave</a>\r\n                                </li>\r\n                                <li class=\"see-all\">\r\n                                        <a href=\"javascript:void(0);\">View Barber Services\r\n                                         <span class=\"icon-right-li\">\r\n                                            <i class=\"fa fa-angle-right\"></i>        \r\n                                        </span>\r\n                                    </a>\r\n                                </li>\r\n                            </ul>\r\n                        </li> -->\r\n                    </ul>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <!-- /.navbar-collapse -->\r\n    </nav>\r\n</header>\r\n<!-- End Header -->\r\n<!-- Modal -->\r\n<div class=\"modal fade signup\" id=\"signupAs\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\r\n  <div class=\"modal-dialog\" role=\"document\">\r\n    <div class=\"modal-content\">\r\n        <div class=\"modal-header\">\r\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n            <span aria-hidden=\"true\">&times;</span>\r\n            </button>\r\n            <h4 class=\"modal-title\" id=\"myModalLabel\">{{ 'headerTwo.signUpAs' | translate }}</h4>\r\n        </div>\r\n        <div class=\"modal-body\">\r\n            <div class=\"sign-selectoption\">\r\n                <div class=\"col-md-12 col-xs-12 col-sm-12 p-0\">\r\n                    <div class=\"col-md-6 col-xs-12  col-sm-6 right-border\">\r\n                        <div class=\"customer-img\">\r\n                            <img src=\"assets/img/saloon.svg\" class=\"img-responsive\">\r\n                        </div>\r\n                        <a  class=\"cus-btn btn\"  data-dismiss=\"modal\" routerLink=\"/header-two-layout/saloon-signup\" data-dismiss=\"modal\">{{ 'headerTwo.saloon' | translate }}</a>\r\n                    </div>\r\n                    <div class=\"col-md-6 col-xs-12  col-sm-6\">\r\n                        <div class=\"professional-img\">\r\n                            <div class=\"customer-img\">\r\n                                <img src=\"assets/img/professional.svg\" class=\"img-responsive\">\r\n                            </div>\r\n                        </div>\r\n                        <a class=\"cus-btn btn\"  data-dismiss=\"modal\" routerLink=\"/header-two-layout/customer-signup\" data-dismiss=\"modal\">{{ 'headerTwo.customer' | translate }}</a>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n <!-- <script type=\"text/javascript\">\r\n    $('.custome-bar > li.dropdown').hover(function(){\r\n       $(this).addClass('active').siblings('li.dropdown').removeClass('active');;\r\n    });\r\n</script> -->"

/***/ }),

/***/ "../../../../../src/app/shared-layout/header-two/header-two.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/shared-layout/header-two/header-two.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HeaderTwoComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__ngx_translate_core__ = __webpack_require__("../../../../@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__providers_common_service__ = __webpack_require__("../../../../../src/app/providers/common.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_app_provider__ = __webpack_require__("../../../../../src/app/providers/app.provider.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var HeaderTwoComponent = (function () {
    function HeaderTwoComponent(router, translate, commonServices, appProvider) {
        this.router = router;
        this.translate = translate;
        this.commonServices = commonServices;
        this.appProvider = appProvider;
        if (localStorage['customerdetails']) {
            // code...
            this.customer = JSON.parse(localStorage['customerdetails']);
        }
        else {
            this.customer = null;
        }
    }
    HeaderTwoComponent.prototype.ngOnInit = function () {
        if (localStorage['userdetails']) {
            // code...
            this.saloon = JSON.parse(localStorage['userdetails']);
        }
        else {
            this.saloon = null;
        }
        if (localStorage['customerdetails']) {
            // code...
            this.customer = JSON.parse(localStorage['customerdetails']);
        }
        else {
            this.customer = null;
        }
        this.getserviceList();
    };
    HeaderTwoComponent.prototype.onLogout = function () {
        localStorage['userdetails'] = 'null';
        this.saloon = null;
        localStorage['customerdetails'] = 'null';
        this.customer = null;
        localStorage.removeItem('isLoggedin');
        this.router.navigate(['/header-one-layout/home-page']);
    };
    HeaderTwoComponent.prototype.oncustomerProfile = function () {
        this.router.navigate(['/header-four-layout/customer-profile']);
    };
    HeaderTwoComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.221.208.210/public/beauty-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    HeaderTwoComponent.prototype.getserviceList = function () {
        var _this = this;
        this.waitLoader = true;
        this.commonServices.getCategoryWithServices()
            .subscribe(function (data) {
            var list = [];
            _this.waitLoader = false;
            console.log(data);
            if (data.response) {
                _this.categoryList = data.data;
                // this.toastr.success(data.message ,'Services Added successfully ',{toastLife: 1000, showCloseButton: true})
                // this.router.navigate(['/header-three-layout/service-list']);
            }
        });
    };
    HeaderTwoComponent.prototype.services = function (ser) {
        this.appProvider.current.serviceSearched = ser;
        // this.router.navigate(['/header-three-layout/saloon-dashboard']);
        this.router.navigate(["/header-two-layout/searched-saloon"]);
    };
    HeaderTwoComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-header-two',
            template: __webpack_require__("../../../../../src/app/shared-layout/header-two/header-two.component.html"),
            styles: [__webpack_require__("../../../../../src/app/shared-layout/header-two/header-two.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */],
            __WEBPACK_IMPORTED_MODULE_2__ngx_translate_core__["c" /* TranslateService */],
            __WEBPACK_IMPORTED_MODULE_3__providers_common_service__["a" /* CommonService */],
            __WEBPACK_IMPORTED_MODULE_4__providers_app_provider__["a" /* AppProvider */]])
    ], HeaderTwoComponent);
    return HeaderTwoComponent;
}());



/***/ })

});
//# sourceMappingURL=header-two-layout.module.chunk.js.map