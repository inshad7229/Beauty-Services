webpackJsonp(["create-new-password.module"],{

/***/ "../../../../../src/app/header-two-layout/create-new-password/create-new-password-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CreateNewPasswordRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__create_new_password_component__ = __webpack_require__("../../../../../src/app/header-two-layout/create-new-password/create-new-password.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__create_new_password_component__["a" /* CreateNewPasswordComponent */]
    }
];
var CreateNewPasswordRoutingModule = (function () {
    function CreateNewPasswordRoutingModule() {
    }
    CreateNewPasswordRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], CreateNewPasswordRoutingModule);
    return CreateNewPasswordRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/create-new-password/create-new-password.component.html":
/***/ (function(module, exports) {

module.exports = "        <section class=\"login-section\">\r\n            <div class=\"container\">\r\n                <div class=\"login-inner\">\r\n                    <form class=\"common-form forgot-password-page new-pass\">\r\n                        <h3 class=\"form-h\">Create New Password</h3>\r\n                        <div class=\"form-wrap\">\r\n                            <div class=\"row\">\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <input type=\"text\" placeholder=\"Current Password\" class=\"form-control\">\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"row\">\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <input type=\"text\" placeholder=\"New Password\" class=\"form-control\">\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"row\">\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <input type=\"text\" placeholder=\"Confirm New Password\" class=\"form-control\">\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                <div class=\"sign-inntn\">\r\n                                    <a href=\"#\" class=\"btn cut-btn\" >Submit</a>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/create-new-password/create-new-password.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/create-new-password/create-new-password.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CreateNewPasswordComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CreateNewPasswordComponent = (function () {
    function CreateNewPasswordComponent(router) {
        this.router = router;
    }
    CreateNewPasswordComponent.prototype.ngOnInit = function () { };
    CreateNewPasswordComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-create-new-password',
            template: __webpack_require__("../../../../../src/app/header-two-layout/create-new-password/create-new-password.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/create-new-password/create-new-password.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */]])
    ], CreateNewPasswordComponent);
    return CreateNewPasswordComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/create-new-password/create-new-password.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateNewPasswordModule", function() { return CreateNewPasswordModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__create_new_password_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/create-new-password/create-new-password-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__create_new_password_component__ = __webpack_require__("../../../../../src/app/header-two-layout/create-new-password/create-new-password.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var CreateNewPasswordModule = (function () {
    function CreateNewPasswordModule() {
    }
    CreateNewPasswordModule.prototype.ngOnInit = function () {
    };
    CreateNewPasswordModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__create_new_password_routing_module__["a" /* CreateNewPasswordRoutingModule */]],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__create_new_password_component__["a" /* CreateNewPasswordComponent */]]
        })
    ], CreateNewPasswordModule);
    return CreateNewPasswordModule;
}());



/***/ })

});
//# sourceMappingURL=create-new-password.module.chunk.js.map