webpackJsonp(["header-four-layout.module"],{

/***/ "../../../../../src/app/header-four-layout/header-four-layout-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HeaderFourLayoutRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__header_four_layout_component__ = __webpack_require__("../../../../../src/app/header-four-layout/header-four-layout.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__header_four_layout_component__["a" /* HeaderFourLayoutComponent */],
        children: [
            { path: '', redirectTo: 'customer-profile' },
            { path: 'customer-profile', loadChildren: './customer-profile/customer-profile.module#CustomerProfileModule' },
            { path: 'booking-details', loadChildren: './customer-booking-details/customer-booking-details.module#CustomerBookingDetailsModule' },
            { path: 'my-appointments', loadChildren: './my-appointments/my-appointments.module#MyAppointmentsModule' },
        ]
    }
];
var HeaderFourLayoutRoutingModule = (function () {
    function HeaderFourLayoutRoutingModule() {
    }
    HeaderFourLayoutRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], HeaderFourLayoutRoutingModule);
    return HeaderFourLayoutRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-four-layout/header-four-layout.component.html":
/***/ (function(module, exports) {

module.exports = "<!-- <app-header></app-header>-->\r\n <app-header-four></app-header-four>\r\n<section >\r\n\t<!-- END HEADER -->\r\n        <div class=\"clearfix\">\r\n        </div>\r\n        <!-- BEGIN CONTAINER -->\r\n        <div class=\"page-container\">\r\n\r\n            <!-- BEGIN SIDEBAR -->\r\n            <app-customer-sidebar></app-customer-sidebar>\r\n             <router-outlet></router-outlet>\r\n         </div>\r\n</section>\r\n"

/***/ }),

/***/ "../../../../../src/app/header-four-layout/header-four-layout.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".main-container {\n  margin-top: 56px;\n  margin-left: 235px;\n  padding: 15px;\n  -ms-overflow-x: hidden;\n  overflow-x: hidden;\n  overflow-y: scroll;\n  position: relative;\n  overflow: hidden; }\n\n@media screen and (max-width: 992px) {\n  .main-container {\n    margin-left: 0px !important; } }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-four-layout/header-four-layout.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HeaderFourLayoutComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HeaderFourLayoutComponent = (function () {
    function HeaderFourLayoutComponent() {
    }
    HeaderFourLayoutComponent.prototype.ngOnInit = function () { };
    HeaderFourLayoutComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-header-four-layout',
            template: __webpack_require__("../../../../../src/app/header-four-layout/header-four-layout.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-four-layout/header-four-layout.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], HeaderFourLayoutComponent);
    return HeaderFourLayoutComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-four-layout/header-four-layout.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderFourLayoutModule", function() { return HeaderFourLayoutModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__header_four_layout_routing_module__ = __webpack_require__("../../../../../src/app/header-four-layout/header-four-layout-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__header_four_layout_component__ = __webpack_require__("../../../../../src/app/header-four-layout/header-four-layout.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_layout_header_four_header_four_component__ = __webpack_require__("../../../../../src/app/shared-layout/header-four/header-four.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_layout_customer_sidebar_customer_sidebar_component__ = __webpack_require__("../../../../../src/app/shared-layout/customer-sidebar/customer-sidebar.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var HeaderFourLayoutModule = (function () {
    function HeaderFourLayoutModule() {
    }
    HeaderFourLayoutModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2__header_four_layout_routing_module__["a" /* HeaderFourLayoutRoutingModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__header_four_layout_component__["a" /* HeaderFourLayoutComponent */], __WEBPACK_IMPORTED_MODULE_4__shared_layout_header_four_header_four_component__["a" /* HeaderFourComponent */], __WEBPACK_IMPORTED_MODULE_5__shared_layout_customer_sidebar_customer_sidebar_component__["a" /* CustomerSidebarComponent */]]
        })
    ], HeaderFourLayoutModule);
    return HeaderFourLayoutModule;
}());



/***/ }),

/***/ "../../../../../src/app/shared-layout/customer-sidebar/customer-sidebar.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"page-sidebar-wrapper\">\r\n    <!-- DOC: Set data-auto-scroll=\"false\" to disable the sidebar from auto scrolling/focusing -->\r\n    <!-- DOC: Change data-auto-speed=\"200\" to adjust the sub menu slide up/down speed -->\r\n    <div class=\"page-sidebar navbar-collapse collapse\">\r\n        <!-- BEGIN SIDEBAR MENU -->\r\n        <ul class=\"page-sidebar-menu\" data-keep-expanded=\"false\" data-auto-scroll=\"true\" data-slide-speed=\"200\">\r\n            <li class=\"start active \">\r\n                <a routerLink=\"/header-four-layout/customer-profile\">\r\n                    <i class=\"icon-user\"></i>\r\n                    <span class=\"title\">My Profile</span>\r\n                </a>\r\n            </li>\r\n            <li class=\"start active \">\r\n                <a routerLink=\"/header-four-layout/my-appointments\">\r\n                    <i class=\"icon-user\"></i>\r\n                    <span class=\"title\">My Appointments</span>\r\n                </a>\r\n            </li>\r\n            <li class=\"start active \">\r\n                <a routerLink=\"/header-four-layout/booking-details\">\r\n                    <i class=\"icon-user\"></i>\r\n                    <span class=\"title\">Booking Details</span>\r\n                </a>\r\n            </li>\r\n        </ul>\r\n        <!-- END SIDEBAR MENU -->\r\n    </div>\r\n</div>\r\n<script type=\"text/javascript\">\r\n    var url = window.location;\r\n    $('ul.page-sidebar-menu a').filter(function() {\r\n        return this.href == url;\r\n    }).parent('li').addClass('active');\r\n</script>"

/***/ }),

/***/ "../../../../../src/app/shared-layout/customer-sidebar/customer-sidebar.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/shared-layout/customer-sidebar/customer-sidebar.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerSidebarComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CustomerSidebarComponent = (function () {
    function CustomerSidebarComponent(router) {
        this.router = router;
    }
    CustomerSidebarComponent.prototype.ngOnInit = function () {
        var url = window.location;
        $('.page-sidebar-menu a').filter(function () {
            return this.href == url;
        }).parent('li').addClass('active');
        jQuery(document).ready(function () {
            Metronic.init(); // init metronic core componets
            Layout.init(); // init layout
            Demo.init(); // init demo features 
            /*Index.init(); // init index page*/
            Tasks.initDashboardWidget(); // init tash dashboard widget  
        });
        /*layout*/
        var menu = $('.page-sidebar-menu');
        menu.find('li.active').removeClass('active');
        menu.find('li > a > .selected').remove();
        if (menu.hasClass('page-sidebar-menu-hover-submenu') === false) {
            menu.find('li.open').each(function () {
                if ($(this).children('.sub-menu').size() === 0) {
                    $(this).removeClass('open');
                    $(this).find('> a > .arrow.open').removeClass('open');
                }
            });
        }
        else {
            menu.find('li.open').removeClass('open');
        }
    };
    CustomerSidebarComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-customer-sidebar',
            template: __webpack_require__("../../../../../src/app/shared-layout/customer-sidebar/customer-sidebar.component.html"),
            styles: [__webpack_require__("../../../../../src/app/shared-layout/customer-sidebar/customer-sidebar.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */]])
    ], CustomerSidebarComponent);
    return CustomerSidebarComponent;
}());



/***/ }),

/***/ "../../../../../src/app/shared-layout/header-four/header-four.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"page-header navbar navbar-fixed-top\">\r\n    <!-- BEGIN HEADER INNER -->\r\n    <div class=\"page-header-inner\">\r\n        <!-- BEGIN LOGO -->\r\n        <div class=\"page-logo\">\r\n            <div class=\"col-md-5 col-sm-5 col-xs-12 p-0\">\r\n                <div class=\"menu-toggler sidebar-toggler\">\r\n                    <!-- DOC: Remove the above \"hide\" to enable the sidebar toggler button on header -->\r\n                </div>\r\n            </div>\r\n            <div class=\"col-md-7 col-sm-5 col-xs-12 p-0\">\r\n                <a routerLink=\"/header-one-layout/home-page\">\r\n                    <img src=\"assets/img/logo.png\" alt=\"logo\" class=\"logo-default\"/>\r\n                </a>\r\n            </div>\r\n        </div>\r\n        <!-- END LOGO -->\r\n        <!-- BEGIN RESPONSIVE MENU TOGGLER -->\r\n        <a href=\"javascript:;\" class=\"menu-toggler responsive-toggler\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">\r\n        </a>\r\n        <!-- BEGIN PAGE TOP -->\r\n        <div class=\"page-top\">\r\n            <div class=\"top-menu\">\r\n                <ul class=\"nav navbar-nav pull-right\">\r\n                    <li class=\"dropdown dropdown-user dropdown-dark\">\r\n                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" data-hover=\"dropdown\" data-close-others=\"true\">\r\n                            <div class=\"header-user\">\r\n                                <img *ngIf=\"!customer.image || customer.image==null\" src=\"assets/img/user-pro-1.jpg\" class=\"img-circle\" alt=\"NO-IMAGES\">\r\n                                <img class=\"img-circle\" *ngIf=\"customer.image\" [src]=\"imagePath(customer.image)\" >\r\n                                <span class=\"username username-hide-on-mobile\">Nick <i class=\"fa fa-angle-down\"></i></span>\r\n                            </div>\r\n                        </a>\r\n                        <ul class=\"dropdown-menu dropdown-menu-default\">\r\n                            <li>\r\n                                <a href=\"javascript:void(0)\" (click)=\"oncustomerProfile()\">\r\n                                <i class=\"icon-user\"></i> My Profile </a>\r\n                            </li>\r\n                            <li>\r\n                                <a (click)=\"onLogout()\">\r\n                                <i class=\"icon-key\"></i> Log Out </a>\r\n                            </li>\r\n                        </ul>\r\n                    </li>\r\n                    <!-- END USER LOGIN DROPDOWN -->\r\n                </ul>\r\n            </div>\r\n            <!-- END TOP NAVIGATION MENU -->\r\n        </div>\r\n        <!-- END PAGE TOP -->\r\n    </div>\r\n    <!-- END HEADER INNER -->\r\n</div>"

/***/ }),

/***/ "../../../../../src/app/shared-layout/header-four/header-four.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/shared-layout/header-four/header-four.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HeaderFourComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var HeaderFourComponent = (function () {
    function HeaderFourComponent(router) {
        this.router = router;
    }
    HeaderFourComponent.prototype.ngOnInit = function () {
        var url = window.location;
        $('.page-sidebar-menu a').filter(function () {
            return this.href == url;
        }).parent('li').addClass('active');
        jQuery(document).ready(function () {
            Metronic.init(); // init metronic core componets
            Layout.init(); // init layout
            Demo.init(); // init demo features 
            /*Index.init(); // init index page*/
            Tasks.initDashboardWidget(); // init tash dashboard widget  
        });
        /*layout*/
        var menu = $('.page-sidebar-menu');
        menu.find('li.active').removeClass('active');
        menu.find('li > a > .selected').remove();
        if (menu.hasClass('page-sidebar-menu-hover-submenu') === false) {
            menu.find('li.open').each(function () {
                if ($(this).children('.sub-menu').size() === 0) {
                    $(this).removeClass('open');
                    $(this).find('> a > .arrow.open').removeClass('open');
                }
            });
        }
        else {
            menu.find('li.open').removeClass('open');
        }
        if (localStorage['userdetails']) {
            // code...
            this.saloon = JSON.parse(localStorage['userdetails']);
        }
        else {
            this.saloon = null;
        }
        if (localStorage['customerdetails']) {
            // code...
            this.customer = JSON.parse(localStorage['customerdetails']);
        }
        else {
            this.customer = null;
        }
    };
    HeaderFourComponent.prototype.onLogout = function () {
        localStorage['userdetails'] = 'null';
        this.saloon = null;
        localStorage['customerdetails'] = 'null';
        this.customer = null;
        localStorage.removeItem('isLoggedin');
        this.router.navigate(['/header-one-layout/home-page']);
    };
    HeaderFourComponent.prototype.imagePath = function (path) {
        if (path.indexOf('base64') == -1) {
            return 'http://18.221.208.210/public/beauty-service/' + path;
            // code...
        }
        else {
            return path;
        }
    };
    HeaderFourComponent.prototype.oncustomerProfile = function () {
        this.router.navigate(['/header-four-layout/customer-profile']);
    };
    HeaderFourComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-header-four',
            template: __webpack_require__("../../../../../src/app/shared-layout/header-four/header-four.component.html"),
            styles: [__webpack_require__("../../../../../src/app/shared-layout/header-four/header-four.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */]])
    ], HeaderFourComponent);
    return HeaderFourComponent;
}());



/***/ })

});
//# sourceMappingURL=header-four-layout.module.chunk.js.map