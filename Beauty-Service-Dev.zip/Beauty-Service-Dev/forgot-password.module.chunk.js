webpackJsonp(["forgot-password.module"],{

/***/ "../../../../../src/app/header-two-layout/forgot-password/forgot-password-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ForgotPasswordRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__forgot_password_component__ = __webpack_require__("../../../../../src/app/header-two-layout/forgot-password/forgot-password.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__forgot_password_component__["a" /* ForgotPasswordComponent */]
    }
];
var ForgotPasswordRoutingModule = (function () {
    function ForgotPasswordRoutingModule() {
    }
    ForgotPasswordRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
        })
    ], ForgotPasswordRoutingModule);
    return ForgotPasswordRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/forgot-password/forgot-password.component.html":
/***/ (function(module, exports) {

module.exports = "\r\n        <section class=\"login-section\">\r\n            <div class=\"container\">\r\n                <div class=\"login-inner\">\r\n                    <form class=\"login-form common-form forgot-password-page\" [formGroup]=\"verifiactionForm\">\r\n                        <h3 class=\"form-h\">Forgot Password</h3>\r\n                        <div class=\"form-wrap\">\r\n                            <p class=\"forgot-info\">\r\n                                Don't worry! just fill in your email and we'll help you reset your password. \r\n                            </p>\r\n                            <div class=\"custom-radio\">\r\n                                <div class=\"radio-inline\">\r\n                                    <input [formControl]=\"verifiactionForm.controls['loginAS']\" [(ngModel)]=\"loginModel.loginAS\" checked=\"checked\" type=\"radio\" id=\"radio01\" value=\"saloon\" name=\"radio\" />\r\n                                    <label for=\"radio01\">\r\n                                        <span><span></span></span>Saloon\r\n                                    </label>\r\n                                </div>\r\n                                <div  class=\"radio-inline\">\r\n                                    <input type=\"radio\" id=\"radio02\" [formControl]=\"verifiactionForm.controls['loginAS']\" [(ngModel)]=\"loginModel.loginAS\" value=\"customer\" name=\"radio\" />\r\n                                    <label for=\"radio02\">\r\n                                        <span><span></span></span>Customer\r\n                                    </label>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"row\">\r\n                                <div class=\"form-group col-md-12 col-sm-12 col-xs-12\">\r\n                                    <input type=\"text\" [formControl]=\"verifiactionForm.controls['email']\" [(ngModel)]=\"loginModel.email\"  placeholder=\"Enter Email\" class=\"form-control\">\r\n                                      <p  *ngIf=\"verifiactionForm.controls['email'].hasError('required') && verifiactionForm.controls['email'].touched\">\r\n                                                       Email is <strong>required</strong>\r\n                                    </p>\r\n                                    <p  *ngIf=\"verifiactionForm.controls['email'].hasError('pattern')\">\r\n                                               Enter valid email id\r\n                                    </p>\r\n                                    <p  *ngIf=\"verifiactionForm.controls['email'].hasError('maxlength')\">\r\n                                               max length is 100\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"form-group col-md-12 col-sm-12 col-xs-12 p-0\">\r\n                                <div class=\"sign-inntn\">\r\n                                    <button class=\"btn cut-btn\" (click)=\"onSubmit()\" [disabled]=\"!verifiactionForm.valid\">Submit</button>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n        </section>"

/***/ }),

/***/ "../../../../../src/app/header-two-layout/forgot-password/forgot-password.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/header-two-layout/forgot-password/forgot-password.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ForgotPasswordComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__providers_customer_service__ = __webpack_require__("../../../../../src/app/providers/customer.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var ForgotPasswordComponent = (function () {
    function ForgotPasswordComponent(router, fb, saloonServices, vcr, toastr, customerService) {
        this.router = router;
        this.fb = fb;
        this.saloonServices = saloonServices;
        this.toastr = toastr;
        this.customerService = customerService;
        this.loginModel = {};
        this.toastr.setRootViewContainerRef(vcr);
        this.verifiactionForm = fb.group({
            'email': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].pattern(EMAIL_REGEX)])],
            'loginAS': [null, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["i" /* Validators */].maxLength(12)])],
        });
        this.loginModel.loginAS = 'saloon';
    }
    ForgotPasswordComponent.prototype.ngOnInit = function () { };
    ForgotPasswordComponent.prototype.onSubmit = function () {
        var _this = this;
        if (this.loginModel.loginAS == 'saloon') {
            this.saloonServices.SaloonForgotPassword(this.loginModel)
                .subscribe(function (data) {
                console.log(data);
                if (data.response) {
                    _this.toastr.success(data.message, 'Account Verification', { toastLife: 1000, showCloseButton: true });
                    // setTimeout(()=>{
                    _this.router.navigate(['/header-two-layout/login']);
                    // },1000)
                    //    alert(data.message)
                }
                else if (data.message == 'Unable to update Password') {
                    _this.toastr.error('Unable to update Password', 'Authentication Failed ', { toastLife: 1000, showCloseButton: true });
                    // code...
                }
                else {
                    _this.toastr.error('Something went wrong please try again', 'Authentication Failed ', { toastLife: 1000, showCloseButton: true });
                }
            });
        }
        else if (this.loginModel.loginAS == 'customer') {
            this.customerService.CustomerForgotPassword(this.loginModel)
                .subscribe(function (data) {
                console.log(data);
                if (data.response) {
                    _this.toastr.success(data.message, 'Account Verification', { toastLife: 1000, showCloseButton: true });
                    _this.router.navigate(['/header-two-layout/login']);
                }
                else if (data.message == 'Unable to send password') {
                    _this.toastr.error('Unable to send password', 'Authentication Failed ', { toastLife: 1000, showCloseButton: true });
                    // code...
                }
                else {
                    _this.toastr.error('Something went wrong please try again', 'Authentication Failed ', { toastLife: 1000, showCloseButton: true });
                }
            });
        }
        else {
            this.toastr.info('Please Select Login AS');
        }
    };
    ForgotPasswordComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-forgot-password',
            template: __webpack_require__("../../../../../src/app/header-two-layout/forgot-password/forgot-password.component.html"),
            styles: [__webpack_require__("../../../../../src/app/header-two-layout/forgot-password/forgot-password.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* Router */], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["a" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_4__providers_saloon_service__["a" /* SaloonService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_2_ng2_toastr__["ToastsManager"],
            __WEBPACK_IMPORTED_MODULE_5__providers_customer_service__["a" /* CustomerService */]])
    ], ForgotPasswordComponent);
    return ForgotPasswordComponent;
}());



/***/ }),

/***/ "../../../../../src/app/header-two-layout/forgot-password/forgot-password.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordModule", function() { return ForgotPasswordModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_material_select__ = __webpack_require__("../../../material/esm5/select.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__forgot_password_routing_module__ = __webpack_require__("../../../../../src/app/header-two-layout/forgot-password/forgot-password-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__forgot_password_component__ = __webpack_require__("../../../../../src/app/header-two-layout/forgot-password/forgot-password.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__providers_saloon_service__ = __webpack_require__("../../../../../src/app/providers/saloon.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__providers_customer_service__ = __webpack_require__("../../../../../src/app/providers/customer.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var ForgotPasswordModule = (function () {
    function ForgotPasswordModule() {
    }
    ForgotPasswordModule.prototype.ngOnInit = function () {
    };
    ForgotPasswordModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_6__forgot_password_routing_module__["a" /* ForgotPasswordRoutingModule */], __WEBPACK_IMPORTED_MODULE_2__angular_forms__["c" /* FormsModule */], __WEBPACK_IMPORTED_MODULE_2__angular_forms__["h" /* ReactiveFormsModule */], __WEBPACK_IMPORTED_MODULE_3__angular_material_select__["a" /* MatSelectModule */], __WEBPACK_IMPORTED_MODULE_4__angular_common_http__["b" /* HttpClientModule */], __WEBPACK_IMPORTED_MODULE_5_ng2_toastr_ng2_toastr__["ToastModule"].forRoot()],
            declarations: [__WEBPACK_IMPORTED_MODULE_7__forgot_password_component__["a" /* ForgotPasswordComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_8__providers_saloon_service__["a" /* SaloonService */], __WEBPACK_IMPORTED_MODULE_9__providers_customer_service__["a" /* CustomerService */]]
        })
    ], ForgotPasswordModule);
    return ForgotPasswordModule;
}());



/***/ })

});
//# sourceMappingURL=forgot-password.module.chunk.js.map