
export class Current {
    adminData:any;

    constructor() {
    }
}
