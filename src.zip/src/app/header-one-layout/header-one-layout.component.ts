import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-header-one-layout',
    templateUrl: './header-one-layout.component.html',
    styleUrls: ['./header-one-layout.component.scss']
})
export class HeaderOneLayoutComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
