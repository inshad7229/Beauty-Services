import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-header-four-layout',
    templateUrl: './header-four-layout.component.html',
    styleUrls: ['./header-four-layout.component.scss']
})
export class HeaderFourLayoutComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
