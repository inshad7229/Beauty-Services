import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransactionDetailsComponent } from './transaction-details.component';

describe('TransactionDetailsComponent', () => {
    let component: TransactionDetailsComponent;
    let fixture: ComponentFixture<TransactionDetailsComponent>;

    beforeEach(
        async(() => {
            TestBed.configureTestingModule({
                declarations: [TransactionDetailsComponent]
            }).compileComponents();
        })
    );

    beforeEach(() => {
        fixture = TestBed.createComponent(TransactionDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
