export class CustomerSignUpModel {
        first_name:string;
        last_name:string;
        email:string;
        contact_number:string;
        password:string;
        gender:string;
        city:string;
        termCondition:boolean;

}