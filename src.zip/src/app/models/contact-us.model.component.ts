export class ContactUs {
	email:any
	first_name:any
	last_name:any
	message:any
}