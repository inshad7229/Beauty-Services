export class AddServices  {
	    id:any;
	 	saloon_id:number;
	 	category_id:number;
	 	service_id:number;
	 	name_eng:string;
	 	name_arb:string;
	 	cost_eng:string;
	 	cost_arb:string;
	 	description_eng:string;
	 	description_arb:string;
	 	category:string;
	 	time:any;
	 	status:number;
	 	created_at:any;
	 	updated_at:any;
}