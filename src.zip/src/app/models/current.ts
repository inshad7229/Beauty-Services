
export class Current {
    adminData:any;
    waitLoader:boolean=false
    serviceSearched:any;
    aboutUsData:any;
    selectedCity:any;
    constructor() {
    }
}
