import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
    selector: 'app-header-two-layout',
    templateUrl: './header-two-layout.component.html',
    styleUrls: ['./header-two-layout.component.scss']
})
export class HeaderTwoLayoutComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
