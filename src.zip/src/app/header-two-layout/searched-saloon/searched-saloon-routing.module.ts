import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchedSaloonComponent } from './searched-saloon.component';

const routes: Routes = [
    {
        path: '',
        component: SearchedSaloonComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SearchedSaloonRoutingModule {}
